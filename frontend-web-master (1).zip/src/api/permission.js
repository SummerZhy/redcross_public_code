import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
  /**
   * 接口含义：用户管理列表查询
   */
  getUserList: function (param) {
    return get('/user/list', param)
  },
  /**
   * 接口含义：用户管理列表导出选项
   */
  uerExport: function (param) {
    return put('/user/export', param)
  },
  /**
   * 接口含义：用户管理列表导出全部
   */
  uerAllExport: function (param) {
    return get('/user/all/export', param)
  },
  /**
   * 接口含义：用户管理新增
   */
  userInfoPost: function (param) {
    return post('/user/info', param)
  },
  /**
   * 接口含义：用户管理查询
   */
  userInfoGet: function (param) {
    return get('/user/info', param)
  },
  /**
   * 接口含义：用户管理修改
   */
  userInfoPut: function (param) {
    return put('/user/info', param)
  },
  /**
   * 接口含义：用户管理删除
   */
  userInfoDel: function (param) {
    return del('/user/info', param)
  },
  /**
   * 接口含义：用户管理状态维护
   */
  userStatusPut: function (param) {
    return put('/user/status', param)
  },
  /**
   * 接口含义：用户管理密码重置
   */
  userCodeReset: function (param) {
    return put('/user/code/reset', param)
  },
  /**
   * 接口含义：机构管理列表初始
   */
  getMechanismList: function (param) {
    return get('/branch/list', param)
  },
  /**
   * 接口含义：机构管理列表删除
   */
  getMechanismListDelete: function (param) {
    return del('/branch/info', param)
  },
  /**
   * 接口含义：机构管理列表新增
   */
  getMechanismListAdd: function (param) {
    return post('/branch/info', param)
  },
  /**
   * 接口含义：机构管理列表搜索
   */
  getMechanismSearch: function (param) {
    return get('/branch/info', param)
  },
  /**
   * 接口含义：机构管理列表修改
   */
  getMechanismEdit: function (param) {
    return put('/branch/info', param)
  },
  /**
   * 接口含义：操作日志查询
   */
  getLogList: function (param) {
    return get('/log/list', param)
  },
  /**
   * 接口含义：操作日志下载
   */
  getLogExport: function (param) {
    return get('/log/export', param)
  },
  /**
   * 接口含义：机构
   */
  getBranchTree: function (param) {
    return get('/branch-tree/list', param)
  },
  /**
   * 接口含义：操作日志下载部分
   */
  getLogExportPart: function (param) {
    return put('/log/export-part', param)
  },
}
