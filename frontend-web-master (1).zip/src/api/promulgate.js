import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
  /**
   * 接口含义：门户接收公示列表查询
   */
  getInStaList: function (param) {
    return get('/capital/inflow/statistics/open/list', param)
  },
  /**
   * 接口含义：门户捐赠公示列表查询
   */
  getOutStaList: function (param) {
    return get('/capital/outflow/statistics/open/list', param)
  },
  


}
