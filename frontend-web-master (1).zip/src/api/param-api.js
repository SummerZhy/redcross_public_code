import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default{

}
