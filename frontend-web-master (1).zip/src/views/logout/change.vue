<template>
    <div class="main-con">
		<section class="wrap-class">
			<title-style>基础信息填写</title-style>
			<el-form class="com-base-info-wrap" ref="form" :model="formData" label-width="110px" label-position="left" :rules="rules">
				<div style="">
					<section class="com-base-info-left" style="margin-left:50%;transform:translateX(-50%);">
						<el-form-item label="旧密码" prop="oldPassWord">
							<el-input v-model="formData.oldPassWord" size="mini" clearable type="password"></el-input>
						</el-form-item>
						<el-form-item label="新密码" prop="newPassWord">
							<el-input v-model="formData.newPassWord" size="mini" clearable type="password"></el-input>
						</el-form-item>
						<el-form-item label="确认密码" prop="password">
                            <el-input v-model="formData.password" size="mini" clearable type="password"></el-input>
						</el-form-item>
					</section>
				</div>
				
			</el-form>
			<section class="com-btn-wrap-center" style="text-align: center;line-height: 100px;">
				<div>
					<el-button type="danger" @click="toSave" size="mini">保存</el-button>
				</div>
			</section>
		</section>
	</div>
</template>

<script>
	import validator from '@/utils/validator'
    export default {
        name: "mainIndex",
        data(){
            return{
                formData:{
                    oldPassWord:'',
                    newPassWord:'',
                    password:'',
                },
                rules:{
                    oldPassWord:[
                        { required: true, message: '请输入旧密码', trigger: 'blur' },
                    ],
                    newPassWord:[
                        { required: true, message: '请输入新密码', trigger: 'blur' },
						{validator: validator.userCode, trigger: 'blur'}
                    ],
                    password:[
                        { required: true, message: '请输入确认密码', trigger: 'blur' },
						{validator: validator.userCode, trigger: 'blur'}
                    ],
				},
            }
        },
        methods:{
            //保存
            toSave(){
				this.$refs.form.validate(valid => {
					if(valid){
						this.$confirm('确定修改密码, 是否继续?', '提示', {
							confirmButtonText: '确定',
							cancelButtonText: '取消',
							type: 'warning',
						})
							.then(() => {
								if(this.formData.newPassWord!=this.formData.password){
									this.$message.error('新密码与确认密码不同');
								}else{
									if(this.formData.newPassWord==this.formData.oldPassWord){
										this.$message.error('新密码与旧密码不可以相同');
									}else{
										let params={
											oldPassWord:this.formData.oldPassWord,
											newPassWord:this.formData.newPassWord,
										}
										this.$api.myApi.codeModify(params)
											.then( res => {
												if(res.retCode == 0){
													this.$message.success('用户密码修改成功');
													this.$router.push('/home');
												}else{
													this.$message.error(res.retMsg);
												}
											})
											.catch(() => {
												this.$message({
													type: 'info',
													message: '已取消修改',
												})
											})
									}
                                }
							}); 
					}
				})
      		},		
        }
    }
</script>

<style scoped lang="scss">
    .power-wrap{
		margin:10px 0 20px 0;
		.power-con-wrap{
		padding:20px 30px;
		}
	}
	.com-base-info-wrap /deep/ .el-form-item{
		margin-bottom: 30px;
	}
	.com-base-info-wrap{
		display: flex;
    	justify-content: space-around;
	}
	.com-base-info-wrap /deep/ div{
		flex:1;
	}
</style>
