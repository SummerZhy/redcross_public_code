// 工会成员列表
<template>
  	<el-dialog
        title="工会会员列表"
        :visible.sync="showDialog"
        width="80%">
        <el-form class="" ref="form" :model="queryForm" label-width="100px">
            <el-row>
                <el-col :span="7">
                    <el-form-item label="会员名称">
                        <el-input v-model="queryForm.userName"></el-input>
                    </el-form-item>
                    <el-form-item label="联系方式">
                        <el-input v-model="queryForm.phone"></el-input>
                    </el-form-item>                                  
                </el-col>
                <el-col :span="7">  
                    <el-form-item label="所属部门">
                        <el-select v-model="queryForm.deptNo" placeholder="请选择社团类型" class="input-width"> 
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>  
                </el-col>
                <el-col :span="7">  
                    <el-form-item label="会员状态">
                        <el-select v-model="queryForm.status" placeholder="请选择社团类型" class="input-width"> 
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>                                                                                               
                </el-col>
                <el-col :span="3">
                    <div class="query-btn">
                        <el-button @click="queryForm.currentPage = 1; getList()" type="danger">查询</el-button>                       
                    </div>
                    <!-- <div class="query-btn">
                        <el-button @click="reset">重置</el-button>
                    </div> -->
                </el-col>
            </el-row>
        </el-form>
        <el-table
            border
            :header-cell-style="tableHeadColor"
            :data="tableData"
            style="width: 100%"
            :row-key='getRowKey'
            @selection-change="handleSelectionChange">
            <el-table-column
                type="selection"
                reserve-selection
                width="55">
            </el-table-column>
            <el-table-column
                type="index"
                :index="getIndex"
                label="序号"
                width="55">
            </el-table-column>
            <el-table-column
                label="会员名称">
                <template slot-scope="scope">{{ scope.row.userName }}</template>
            </el-table-column>
            <el-table-column
                prop="gender"
                label="性别">
            </el-table-column>   
            <el-table-column
                prop="phone"
                label="联系方式">
            </el-table-column>                 
            <el-table-column
                prop="deptName"
                label="所属部门">
            </el-table-column> 
            <el-table-column
                prop="position"
                label="职位">
            </el-table-column> 
            <el-table-column
                prop="status"
                label="会员状态">
            </el-table-column> 
        </el-table>
        <el-pagination
            background
            :current-page.sync="queryForm.currentPage"
            :page-sizes="[10, 20, 50, 100]"
            :page-size.sync="queryForm.limit"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalNumber"
            @current-change="getList"
            @size-change="getList">
        </el-pagination>  
        <div class="dialog-footer-center">
            <el-button type="danger" @click="sure()">确 定</el-button>
            <el-button @click="showDialog = false">取 消</el-button>
        </div>    
    </el-dialog>
</template>
<script>
export default {
  	data(){
    	return{
            tableHeadColor:{
                backgroundColor:'#f5f7fa'
            },
            options:[
                {label:'111', value:'1'},
                {label:'2', value:'2'},
            ],
            queryForm:{
                userName:'', //会员名称
                deptNo:'', //所属部门 字典值 dept
                status:'', //会员状态 1-启用，2-停用
                phone:'', //联系方式
                currentPage:1, //当前页
                limit:10, //每页条数
            },
            totalNumber:0,
            tableData:[],
            getRowKey:function(row){
                return row.id;
            },
            checkedMember:[],
            showDialog:false,
    	}
    },
    props:{
        value:{
            type:Boolean,
            default:false
        }
    },
    watch:{
        value(newVal, oldVal){
            if(newVal){
                this.showDialog = newVal;
                this.getList();
            }
        },
        showDialog(newVal, oldVal){
            if(!newVal){
                this.$emit('input',newVal);
            }
        }   
    },
    created(){
        
    },
    methods:{
        getIndex(index){
            return((this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1)
        },
        getList(){  
            this.$api.myApi.memberManage.getMemberManageList(this.queryForm).then(res => {
                if (res.resCode == "0") {
                    this.totalNumber = res.result.totalNumber;
                    this.tableData = res.result.list;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        handleSelectionChange(val){
            this.checkedMember = val;
        },
        sure(){
            this.showDialog = false; 
            this.$emit('getMembers', this.checkedMember);
        }
    }
}
</script>
<style scoped>
    .query-btn{
        text-align:right;
        margin-bottom:22px;
        padding-right:10px;
    }
    .dialog-footer-center{
        margin-top:60px;
        text-align:center;
    }
</style>