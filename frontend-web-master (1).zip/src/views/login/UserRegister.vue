<template>
  <div style="padding-top: 6%">
    <el-row>
      <el-col :span="7">&nbsp;</el-col>
      <el-col :span="10">
        <el-tabs>
          <el-tab-pane label="用户注册">
             <el-card type="form">
               <el-form ref="regForm" :rules="validateRules" :model="regForm" label-width="100px">
                <!-- <el-form-item label="身份证号：">
                    <el-input v-model="regForm.id" placeholder="请输入身份证号"></el-input>
                 </el-form-item>-->
                 <el-form-item label="用户昵称：" prop="nickName">
                   <el-input v-model="regForm.nickName" placeholder="请输入用户名"></el-input>
                 </el-form-item>
                 <el-form-item label="手机号：" prop="mobilePhone">
                   <el-input :disabled="phoneDisable" v-model="regForm.mobilePhone" placeholder="请输入手机号"></el-input>
                 </el-form-item>
                 <el-form-item label="验证码：" prop="verifyCode">
                   <el-input v-model="regForm.verifyCode" style="width: 80%" placeholder="请输入验证码"></el-input>
                   <el-button style="width: 19%" @click="getConfirmCode" v-show="show">{{vfCode}}</el-button>
                   <el-button v-show="!show" class="count">{{count}} s</el-button>
                 </el-form-item>
                 <el-form-item label="密码：" prop="userCode">
                   <el-input type="password" :disabled="codeDisable" v-model="regForm.userCode" placeholder="请输入密码"></el-input>
                 </el-form-item>
                 <el-form-item label="密码确认：" prop="reUserCode">
                   <el-input type="password" :disabled="codeDisable" v-model="regForm.reUserCode" placeholder="请确认密码"></el-input>
                 </el-form-item>
                 <div class="btn-container" style="text-align: center">
                   <el-button type="primary" @click.native="userRegister">注册</el-button>
                   <el-button type="primary" @click.native="resetForm">重置</el-button>
                 </div>
               </el-form>
             </el-card>
          </el-tab-pane>
        </el-tabs>
      </el-col>
      <el-col :span="7">&nbsp;</el-col>
    </el-row>
  </div>
</template>

<script>
  import crypto from '@/utils/crypto'
  import validator from '@/utils/validator'
    export default {
      name: "register",
      data () {
        return {
          regForm: {
            id: '',
            nickName: '',
            mobilePhone: '',
            uuid: '',
            type: '0',
            verifyCode: '',
            userCode: '',
            reUserCode: ''
          },
          codeDisable: true,
          salt: '',
          vfCode: '获取验证码',
          show: true,
          count: '',
          isOverTime: false,
          overTimer: null,
          timer: null,
          validateRules: {
            id: [{required: true, trigger: 'blur', message: "请输入身份证"}],
            nickName: [{required: true, trigger: 'blur', message: "请输入用户名"}],
            mobilePhone: [
              {required: true, trigger: 'blur', message: "请输入手机号"},
              {validator: validator.phone, trigger: 'blur'}
            ],
            verifyCode: [{required: true, trigger: 'blur', message: "请输入验证码"}],
            userCode: [{required: true, trigger: 'blur', message: "请输入密码"}],
            reUserCode: [{required: true, trigger: 'blur', message: "请确认密码"}],
          },
        }
      },
      computed: {
        phoneDisable: {
          get() {
            return !this.codeDisable
          }
        }
      },
      methods: {
        userRegister() {
          this.$refs.regForm.validate(valid => {
            if (valid) {
              if (this.regForm.userCode !== this.regForm.reUserCode) {
                this.$message.warning('两次密码不一致！')
                return
              }
              //获取盐值
              /*this.$api.myApi.getSalt()
                .then(res => {
                  if (res.retCode === '0') {
                    //注册
                    //加密
                    const key = 'uswn46hea7p3j8ou38n1sirm'
                    //const salt = res.salt
                    this.regForm.userCode = crypto.encryptByDES((this.regForm.userCode + this.salt), key)
                    this.regForm.reUserCode = crypto.encryptByDES((this.regForm.reUserCode + this.salt), key)
                    this.$api.myApi.register(this.regForm)
                      .then(res => {
                        if (res.retCode === '0') {
                          this.$message({type:'success',message: '注册成功，请登录！'})
                          this.$router.push('/login')
                        }else{
                          this.$message({type:'warning',message: res.retMsg})
                          this.regForm.userCode = ''
                          this.regForm.reUserCode = ''
                        }
                      })
                  //}
                //})*/
            }
          })
        },
        resetForm() {
          this.regForm.id = ''
          this.regForm.uuid = ''
          this.regForm.nickName = ''
          this.regForm.mobilePhone = ''
          this.regForm.verifyCode = ''
          this.regForm.userCode = ''
          this.regForm.reUserCode = ''
          this.codeDisable = true
        },
        getConfirmCode() {
          let pass = /(^(\\+86)?0?[1][3456789][0-9]{9}$)/g.test(this.regForm.mobilePhone)
          if (this.regForm.mobilePhone == '') {
            this.$message.warning('请输入手机号！')
          } else if (!pass){
            this.$message.warning('请输入正确的手机号！')
          }
          /*this.$refs[telephone].validate((valid) => {
            if (valid) {*/
            else {
            // 是否超时设定
            this.overTimer = setTimeout(() => {
              this.isOverTime = true
            }, 120000)
            // 动态倒计时
            const TIME_COUNT = 60
            if (!this.timer) {
              this.count = TIME_COUNT
              this.show = false
              this.timer = setInterval(() => {
                if (this.count > 0 && this.count <= TIME_COUNT) {
                  this.count--
                } else {
                  this.show = true
                  clearInterval(this.timer)
                  this.timer = null
                }
              }, 1000)
            }
            this.vfCode = '重新获取'
            this.isOverTime = false

            //获取验证码接口
            this.$api.myApi.getConfirmCode({type: '0', mobilePhone: this.regForm.mobilePhone})
              .then(res => {
                if (res.retCode === '0') {
                  //获取盐值
                  this.$api.myApi.getSalt()
                    .then(res => {
                      if (res.retCode === '0') {
                        this.salt = res.result.salt
                        this.regForm.uuid = res.result.uuid
                        this.codeDisable = false
                        this.$message({message: '获取验证码成功！'})
                      }
                    })
                } else {
                  this.$message({
                    type: 'error',
                    message: res.retMsg,
                    duration: 3 * 1000
                  });
                }
              })
          }
        }
      }
    }
</script>

<style scoped>

</style>
