<template>
	<div class="navbar">
		<section class="left">
			<img class="logo-img" src="/image/red_cross.png" alt="">
			<p class="logo-title">东营红十字会</p>
			<p class="title">物资及资金管理系统</p>
		</section>
		<section class="right">
			<div class="user-wrap">
            	<svg-icon class="icon-class" icon-class="usericon1"></svg-icon>
				<span>{{userName}}</span>
			</div>
			<div @click="logout">
            	<svg-icon class="icon-class" icon-class="logout2" title="注销" ></svg-icon>
			</div>
		</section>
	</div>
</template>

<script>
import {getToken, removeToken, setToken, setUserInfo, getUserInfo, removeUserInfo} from '@/utils/auth'

export default {
	data(){
		return{
			userName:'',
		}
	},
	created(){
		this.userName = getUserInfo('userName')
	},
	methods:{
		logout(){
			this.$api.myApi.logout().then( res => {
                if(res.retCode == 0){
					removeUserInfo('userName')
					removeToken('token')
                    this.$router.push('/login')

                }else{
                  this.$message.error(res.retMsg);
                }
            })
		}
	}
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
	.navbar {
		display:flex;
		align-items:center;
		justify-content:space-between;
		padding:0 40px 0 26px;
		position: fixed;
		height: 56px;
		width: 100%;
		background: #F4F6F7;
		border-bottom:2px solid #E50617;
	// background-image: linear-gradient(90deg, #35373a 0%, #373333 100%);
	}
	.left{
		height:54px;
		display:flex;
		align-items:center;
		.logo-img{
			width:47px;
		}
		.logo-title{
			padding-left:10px;
			font-size:28px;
			color:#0E131A;
		}
		.title{
			padding-left:15px;
			margin-left:15px;
			border-left:1px solid #DCDFE6;
			font-size: 24px;
			color: #798082;
		}
	}
	.right{
		display:flex;
		align-items:center;
		.user-wrap{
			margin-right:30px;
			.icon-class{
				margin-right:10px;
			}
		}
		.icon-class{
			font-size:16px;
			color:#999;
		}
	}
</style>

