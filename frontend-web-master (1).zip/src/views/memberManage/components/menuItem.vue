<template>
  <div class="menu_content" @click="changeNav(data.url)">
    <div class="icon"></div>
    <div class="tittle">{{data.label}}</div>
  </div>
</template>
<script>
export default {
  props:['data'],
  methods:{
    changeNav(val){
      console.log(val);
      this.$router.push(val);
    }
  }
};
</script>
<style lang="scss" scoped>
  .menu_content{
    display: inline-block;
    min-width: 100px;
    padding: 15px;
    padding-right: 40px;
    .icon{
      width: 70px;
      height: 70px;
      border-radius: 50%;
      background-color: #E5EBFA;
      &:hover{
        box-shadow: 0 0 3px #ccc;
        cursor: pointer;
      }
    }
    .tittle{
      text-align: center;
      font-size: 14px;
      line-height: 30px;
      color:#666;
    }
  }
</style>

