<template>

</template>
<script>
  export default {
    data() {
      return {};
    },
    mounted(){

    },
    methods: {}
  }
</script>
<style scoped>

</style>