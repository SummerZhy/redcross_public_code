import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
    {
        path: '/auditModule',
        component: Layout,
        name: '审核处理',
        meta: {title: '审核处理', icon: 'set'},
        menu: 'auditModule',
        children: [
            {
                path: 'audit-list',
                name: '资金入账审核',
                component: _import('auditModule/Auditlist'),
                meta: {title: '资金入账审核', icon: '', keepAlive:true, isBack:false},
                menu: 'audit-list'
            },
            {
                path: 'audit-edit',
                name: '审核',
                component: _import('auditModule/AuditEdit'),
                meta: {title: '审核', icon: '',keepAlive:true, isBack:false},
                menu: 'audit-edit',
                hidden: true
            },
           {
                path: 'donor-list',
                name: '捐赠人评价审核',
                component: _import('auditModule/DonorEvaluationReview'),
                meta: {title: '捐赠人评价审核', icon: '',keepAlive:true, isBack:false},
                menu: 'donor-list',
            },
            {
                path: "DoneeAppraiseCheck",
                name: "受赠人评价审核",
                component: _import("auditModule/DoneeAppraiseCheck"),
                meta: { title: "受赠人评价审核" },
                menu: "examinationPaper"
              }
        ]
    }
];
