/**
 * Created by lpj on 2020/2/13.
 */

import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
  {
    path: "/memberManage",
    component: Layout,
    name: "会员管理",
    meta: { title: "会员管理" },
    children: [
      {
        path: "memberManage",
        name: "工会会员管理",
        component: _import("memberManage/memberManage"),
        meta: { title: "工会会员管理" },
        // menu: "examinationPaper"
      },
      {
        path: "teamManage",
        name: "工会小组管理",
        component: _import("memberManage/teamManage"),
        meta: { title: "工会小组管理" },
      },
      {
        path: "clubManage",
        name: "社团协会管理",
        component: _import("memberManage/clubManage"),
        meta: { title: "社团协会管理" },
      },
      {
        path: "clubMemberManage",
        name: "社团会员管理",
        component: _import("memberManage/clubMemberManage"),
        meta: { title: "社团会员管理" },
      }
    ]
  }
];
