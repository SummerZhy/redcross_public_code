import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
    {
        path: '/statistics',
        component: Layout,
        name: '统计模块',
        meta: {title: '统计模块', icon: 'statistics'},
        menu: 'statistics',
        children: [
            {
                path: 'capitalInquiry-list',
                name: '资金查询',
                component: _import('statistics/CapitalInquiry'),
                meta: {title: '资金查询', icon: '', keepAlive:true, isBack:false},
                menu: 'capitalInquiry-list'
            },
          {
            path: 'reception',
            name: '接收公示',
            component: _import('statistics/reception'),
            meta: {title: '接收公示', icon: '', keepAlive:true, isBack:false},
            menu: 'reception'
          },
          {
            path: 'donation',
            name: '捐赠公示',
            component: _import('statistics/donation'),
            meta: {title: '捐赠公示', icon: '',keepAlive:true, isBack:false},
            menu: 'donation'
          },
        ]
      },
    ];
