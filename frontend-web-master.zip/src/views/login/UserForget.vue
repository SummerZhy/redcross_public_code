<template>
  <div style="padding-top: 6%">
    <el-row>
      <el-col :span="7">&nbsp;</el-col>
      <el-col :span="10">
        <el-tabs>
          <el-tab-pane label="忘记密码">
            <el-card type="form">
              <el-form ref="userForm" :rules="validateRules" :model="userForm" label-width="100px">
                <!--<el-form-item label="身份证号：" prop="identityNum">
                  <el-input v-model="userForm.identityNum" placeholder="请输入身份证号"></el-input>
                </el-form-item>-->
                <!--<el-form-item label="找回方式：" prop="type">
                  <el-radio-group v-model="userForm.type">
                    <el-radio  label="0">手机</el-radio>
                    <el-radio  label="1">邮箱</el-radio>
                  </el-radio-group>
                </el-form-item>-->
                <el-form-item v-if="isPhone" label="手机号：" prop="mobilePhone">
                  <el-input v-model="userForm.mobilePhone" placeholder="请输入手机号"></el-input>
                </el-form-item>
                <!--<el-form-item v-if="isMail = !isPhone" label="邮箱：" prop="mail">
                  <el-input v-model="userForm.mail" placeholder="请输入邮箱"></el-input>
                </el-form-item>-->
                <el-form-item label="验证码：" prop="verifyCode">
                  <el-input v-model="userForm.verifyCode" style="width: 80%" placeholder="请输入验证码"></el-input>
                  <el-button style="width: 19%" @click="getConfirmCode" v-show="show">{{vfCode}}</el-button>
                  <el-button v-show="!show" class="count">{{count}} s</el-button>
                </el-form-item>
                <el-form-item label="新密码：" prop="userCode">
                  <el-input :disabled="codeDisable" type="password" v-model="userForm.userCode" placeholder="请输入密码"></el-input>
                </el-form-item>
                <el-form-item label="密码确认：" prop="reUserCode">
                  <el-input :disabled="codeDisable" type="password" v-model="userForm.reUserCode" placeholder="请确认密码"></el-input>
                </el-form-item>
                <div class="btn-container" style="text-align: center">
                  <el-button type="primary" @click="userConfirm">确认</el-button>
                  <el-button type="primary" @click="resetForm">重置</el-button>
                </div>
              </el-form>
            </el-card>
          </el-tab-pane>
        </el-tabs>
      </el-col>
      <el-col :span="7">&nbsp;</el-col>
    </el-row>
  </div>
</template>

<script>
  import crypto from '@/utils/crypto'
  import validator from '@/utils/validator'
  export default {
    name: "register",
    data () {
      return {
        userForm: {
          identityNum: '',
          type: '0',
          mobilePhone: '',
          mail: '',
          uuid: '',
          verifyCode: '',
          userCode: '',
          reUserCode: ''
        },
        codeDisable: true,
        salt: '',
        vfCode: '获取验证码',
        show: true,
        count: '',
        isOverTime: false,
        overTimer: null,
        timer: null,
        validateRules: {
          userName: [{required: true, trigger: 'blur', message: "请输入用户名"}],
          /*identityNum: [{required: true, trigger: 'blur', message: "请输入身份证号"}],*/
          mobilePhone: [
            {required: true, trigger: 'blur', message: "请输入手机号"},
            {validator: validator.phone, trigger: 'blur'}
          ],
          mail: [
            {required: true, trigger: 'blur', message: "请输入邮箱号"},
            {validator: validator.email, trigger: 'blur'}
          ],
          verifyCode: [{required: true, trigger: 'blur', message: "请输入验证码"}],
          userCode: [
            {required: true, trigger: 'blur', message: "请输入密码"},
            {validator: validator.userCode, trigger: 'blur'}],
          reUserCode: [
            {required: true, trigger: 'blur', message: "请确认密码"},
            {validator: validator.userCode, trigger: 'blur'}],
        },
      }
    },
    computed: {
      isPhone: {
        get () {
          return this.userForm.type == '0' ? true: false
        },
        set () {}
      },
      isMail: {
        get () {
          return !this.isPhone
        },
        set () {}
      }
    },
    methods: {
      userConfirm () {
        this.$refs.userForm.validate(valid => {
          if (valid) {
            if (this.userForm.userCode !== this.userForm.reUserCode) {
              this.$message.warning('两次密码不一致！')
              return
            }
            //获取盐值
                  //注册
                  //加密
                  const key = 'uswn46hea7p3j8ou38n1sirm'
                  //const salt = res.salt
                  this.userForm.userCode = crypto.encryptByDES((this.userForm.userCode + this.salt), key)
                  this.userForm.reUserCode = crypto.encryptByDES((this.userForm.reUserCode + this.salt), key)
                  /* if(this.userForm.type = '0') {
                    this.userForm.userName = this.userForm.telephone
                  } else if(this.userForm.type = '1') {
                    this.userForm.userName = this.userForm.mail
                  } */
                  this.$api.myApi.codeBack(this.userForm)
                    .then(res => {
                      if (res.retCode === '0') {
                        this.$message({type:'success',message: '密码重置成功！'})
                        this.$router.push('/login')
                      } else {
                        this.$message({
                          type: 'error',
                          message: res.retMsg,
                          duration: 3 * 1000
                        });
                        this.userForm.userCode = ''
                        this.userForm.reUserCode = ''
                      }
                    })
                    .catch(err => {
                      this.userForm.userCode = ''
                      this.userForm.reUserCode = ''
                    })
                //}
              //})
          }
        })
      },
      resetForm () {
        this.userForm.identityNum = ''
        this.userForm.type = '0'
        this.userForm.mobilePhone = ''
        this.userForm.mail = ''
        this.userForm.uuid = ''
        this.userForm.verifyCode = ''
        this.userForm.userCode = ''
        this.userForm.reUserCode = ''
        this.codeDisable =  true
      },
      getConfirmCode () {
        let passPhone = /(^(\\+86)?0?[1][3456789][0-9]{9}$)/g.test(this.userForm.mobilePhone)
        let passMail = /^[a-zA-Z0-9_\.\-]+\@([a-zA-Z0-9\-]+\.)+[a-zA-Z0-9]{2,4}$/g.test(this.userForm.mail)
        if (this.userForm.type == '0' && this.userForm.mobilePhone == '') {
          this.$message.warning('请输入手机号！')
        } else if (this.userForm.type == '0' && !passPhone) {
          this.$message.warning('请输入正确的手机号！')
        } /*else if (this.userForm.type == '1' && this.userForm.mail == '') {
          this.$message.warning('请输入邮箱号！')
        } else if (this.userForm.type == '1' && !passMail) {
          this.$message.warning('请输入正确的邮箱号！')
        }*/else{
          // 是否超时设定
          this.overTimer = setTimeout(() => {
            this.isOverTime = true
          }, 120000)
          // 动态倒计时
          const TIME_COUNT = 60
          if (!this.timer) {
            this.count = TIME_COUNT
            this.show = false
            this.timer = setInterval(() => {
              if (this.count > 0 && this.count <= TIME_COUNT) {
                this.count--
              } else {
                this.show = true
                clearInterval(this.timer)
                this.timer = null
              }
            }, 1000)
          }
          this.vfCode = '重新获取'
          this.isOverTime = false

          let data = {}
          if (this.userForm.type === '0') {
            data = {type: '0', mobilePhone: this.userForm.mobilePhone}
          } else if (this.userForm.type === '1') {
            data = {type: '1', mobilePhone: this.userForm.mail}
          }

          //获取验证码接口
          this.$api.myApi.getConfirmCode(data)
            .then(res => {
              if (res.retCode === '0') {
                this.$api.myApi.getSalt()
                  .then(res => {
                    if (res.retCode === '0') {
                      this.salt = res.result.salt
                      this.userForm.uuid = res.result.uuid
                      this.codeDisable = false
                      this.$message({type:'success',message: '获取验证码成功！'})
                    }
                  })
              }
            })
        }
      },
    }
  }
</script>

<style scoped>

</style>
