<template>
    <div>
        <div class="login-container">
            <el-form :model="loginForm"
                     :rules="loginRules"
                     autoComplete="on"
                     ref="loginForm"
                     class="card-box login-form"
                     label-width="0px"
                     label-position="left">
                <el-tabs v-model="activeTab" @tab-click="handleClick">
                    <el-tab-pane name="first">
                        <div slot="label" class="tipClass"><p class="text">我是捐赠人</p></div>
                    </el-tab-pane>
                    <el-tab-pane name="second">
                        <div slot="label" class="tipClass"><p class="text">我是受赠人</p></div>
                    </el-tab-pane>
                </el-tabs>

                <el-form-item prop="phoneNum">
                    <el-input v-model="loginForm.phoneNum"
                              placeholder="请输入用户名">
                    </el-input>
                </el-form-item>
                <el-form-item prop="verifiCode">
                    <el-input placeholder="请输入短信验证码"
                              v-model="loginForm.verifiCode">
                        <template slot="append">
                            <el-button @click="getVerifyCode()" :disabled="!disableBtn">{{codeText}}</el-button>
                        </template>
                    </el-input>
                </el-form-item>
                <br>
                <el-form-item>
                    <el-button class="login-btn" :loading="loading" :disabled="!disableLogin"
                               @click.native.prevent="phoneLogin">
                        立即追踪
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>
    import {getToken, removeToken, setToken, setUserInfo, getUserInfo, removeUserInfo} from '@/utils/auth'
    import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
    import crypto from '@/utils/crypto'
    import store from '../../store'

    export default {
        name: 'loginPhone',
        data() {
            return {
                loginForm: {
                    phoneNum: '',
                    verifiCode: '',
                    loginRole: '2',
                },
                loginRules: {
                    phoneNum: [{required: true, trigger: 'blur', message: "请输入手机号"}],
                    verifiCode: [{required: true, trigger: 'blur', message: "请输入短信验证码"}]
                },
                loading: false,
                codeText: '获取验证码',
                disableBtn: true,
                activeTab: 'first',
                path: '/examinationPaper',
            }
        },
        computed: {
            disableLogin: function () {
                if (this.loginForm.phoneNum !== '' && this.loginForm.verifiCode.length === 6) {
                    return true;
                } else {
                    return false;
                }
            },
        },
        methods:
            {
                ...mapActions('user', [
                    'GetInfo',
                ]),
                ...mapActions('dictionary', [
                    'getDicList',
                ]),
                getVerifyCode() {
                    this.countDown(60)
                    let param = {mobilePhone: this.loginForm.phoneNum}
                    this.$api.myApi.getCode(param).then((res) => {
                        if (res.retCode === '0') {
                            this.$message('验证码发送成功,您的验证码是：' + res.result.verifyCode)
                        } else {
                            this.$message('验证码发送失败，请重新获取')
                        }
                    }).catch(() => {
                        this.$message('验证码发送失败，请重新获取')
                    })
                },
                countDown(time) {
                    if (time === 0) {
                        this.disableBtn = true;
                        this.codeText = '获取验证码';
                        return
                    } else {
                        this.disableBtn = false;
                        this.codeText = '重新发送(' + time + ')'
                        time = time - 1;
                    }
                    setTimeout(() => {
                        this.countDown(time)
                    }, 1000)
                },
                phoneLogin() {
                    this.$api.myApi.userLogin(this.loginForm).then((res) => {
                            if (res.data.retCode === '0') {
                                this.$router.push({path: this.path})
                                window.localStorage.removeItem('accessedRouters')
                                //存储token 在cookie中
                                setToken(res.headers.authorization)
                                //请求字典项
                                store.dispatch('dictionary/getDicList')
                            } else {
                                this.$message(res.data.retMsg)
                            }
                        }
                    ).catch((e) => {
                        console.log(e)
                    })
                },
                handleClick(tab) {
                    if (tab.name === 'first') {
                        this.loginForm.loginRole === '2'
                        this.path = '/examinationPaper'
                    } else {
                        this.loginForm.loginRole === '3'
                        this.path = '/clubactivity'
                    }
                },
            }
    }
</script>
<style rel="stylesheet/scss" scoped lang="scss">
    @import "../../styles/mixin.scss";

    $bg: #2d3a4b;
    $dark_gray: #889aa4;
    $light_gray: #eee;
    .login-container {
        @include relative;
        /*width: 100vw;*/
        /*height: 100vh;*/
        /*background: url('../../assets/beijing.png') no-repeat;*/
        /*background-size: 100% 100%;*/

        .login-form {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, 50%);
            width: 380px;
            height: 338px;
            padding: 30px 30px 30px 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px 0 rgba(0,0,0,0.10);

            .title-class {
                display: flex;
                margin-bottom: 9px;
            }

            .item-label {
                font-family: PingFangSC-Medium;
                font-size: 28px;
                color: #0E131A;
                letter-spacing: 0;
                line-height: 28px;
                width: 56px;
                margin-right: 10px;
            }

            .english-login {
                font-family: PingFangSC-Regular;
                font-size: 16px;
                color: #798082;
                letter-spacing: 0;
                line-height: 16px;
                width: 42px;
                margin-top: 12px;
            }

            .red-line {
                width: 108px;
                height: 2px;
                background: #EA414E;
                margin-bottom: 39px;
            }

            .tipClass {
                margin-left: 10px;
                height: 28px;
                width: 78px;
                background-image: linear-gradient(135deg, #FFA25C 0%, #FF6834 100%);
                border-radius: 32.5px;
                text-align: center;

                .text {
                    font-family: PingFang-SC-Regular;
                    line-height: 28px;
                    font-size: 12px;
                    color: #FFFFFF;
                    letter-spacing: 0;
                }
            }

            .login-btn {
                background-image: linear-gradient(135deg, #EE5863 0%, #EA414E 100%);
                border-radius: 4px;
                border: none;
                width: 320px;
                height: 40px;
                font-family: PingFangSC-Medium;
                font-size: 14px;
                color: #FFFFFF;
                letter-spacing: 0.24px;
                text-align: center;
                line-height: 14px;
                /*margin-top: 40px;*/
            }
        }

        .el-form-item {
            margin-bottom: 20px;
            background: #FFFFFF;
            border-radius: 4px;
            color: #454545;
        }
    }
</style>
