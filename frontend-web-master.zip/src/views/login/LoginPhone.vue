<template>
    <div>
        <div class="login-container">
            <el-form :model="loginForm"
                     :rules="loginRules"
                     autoComplete="on"
                     ref="loginForm"
                     class="card-box login-form"
                     label-width="0px"
                     label-position="left">
                <el-tabs class="tab-Class" v-model="activeTab" @tab-click="handleClick">
                    <el-tab-pane name="first">
                        <div slot="label"><span>我是捐赠人</span></div>
                    </el-tab-pane>
                    <el-tab-pane name="second">
                        <div slot="label"><span>我是受赠人</span></div>
                    </el-tab-pane>
                </el-tabs>
                <el-form-item prop="phoneNum" style="margin-top: 10px;">
                    <el-input size="mini" v-model="loginForm.phoneNum"
                              placeholder="请输入手机号">
                        <template slot="prepend">
                            <svg-icon icon-class="ID"></svg-icon>
                        </template>
                    </el-input>
                </el-form-item>
                <el-form-item prop="verifiCode">
                    <el-input size="mini" placeholder="请输入验证码"
                              v-model="loginForm.verifiCode">
                        <template slot="prepend">
                            <svg-icon icon-class="password"></svg-icon>
                        </template>
                        <template slot="append">
                            <el-button size="mini" @click="getVerifyCode()" :disabled="!disableBtn">{{codeText}}
                            </el-button>
                        </template>
                    </el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="login-btn" :loading="loading" :disabled="!disableLogin"
                               @click.native.prevent="phoneLogin">
                        立即追踪
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>
    import {getToken, removeToken, setToken, setUserInfo, getUserInfo, removeUserInfo} from '@/utils/auth'
    import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
    import crypto from '@/utils/crypto'
    import store from '../../store'

    export default {
        name: 'loginPhone',
        data() {
            return {
                loginForm: {
                    phoneNum: '',
                    verifiCode: '',
                    loginRole: '2',
                },
                loginRules: {
                    phoneNum: [{required: true, trigger: 'blur', message: "请输入手机号"}],
                    verifiCode: [{required: true, trigger: 'blur', message: "请输入短信验证码"}]
                },
                loading: false,
                codeText: '获取验证码',
                disableBtn: true,
                activeTab: 'first',
                path: '/examinationPaper',
            }
        },
        computed: {
            disableLogin: function () {
                if (this.loginForm.phoneNum !== '' && this.loginForm.verifiCode.length === 6) {
                    return true;
                } else {
                    return false;
                }
            },
        },
        methods:
            {
                ...mapActions('user', [
                    'GetInfo',
                ]),
                ...mapActions('dictionary', [
                    'getDicList',
                ]),
                getVerifyCode() {
                    this.countDown(60)
                    let param = {mobilePhone: this.loginForm.phoneNum}
                    this.$api.myApi.getCode(param).then((res) => {
                        if (res.retCode === '0') {
                            this.$alert('验证码发送成功,您的验证码是：' + res.result.verifyCode, '提示', {
                                confirmButtonText: '确定',
                                type: 'success'
                            })
                        } else {
                            this.$message({
                                type: 'warning',
                                message: res.retMsg
                            });
                        }
                    }).catch(() => {
                        this.$message({
                            type: 'error',
                            message: '验证码获取异常'
                        });
                    })
                },
                countDown(time) {
                    if (time === 0) {
                        this.disableBtn = true;
                        this.codeText = '获取验证码';
                        return
                    } else {
                        this.disableBtn = false;
                        this.codeText = '重新发送(' + time + ')'
                        time = time - 1;
                    }
                    setTimeout(() => {
                        this.countDown(time)
                    }, 1000)
                },
                phoneLogin() {
                    this.$api.myApi.userLogin(this.loginForm).then((res) => {
                            if (res.data.retCode === '0') {
                                window.localStorage.removeItem('accessedRouters')
                                //存储token 在cookie中
                                setToken(res.headers.authorization)
                                //请求字典项
                                store.dispatch('dictionary/getDicList')
                                this.$router.push({path: this.path})
                            } else {
                                this.$message({
                                    type: 'warning',
                                    message: res.data.retMsg
                                });
                            }
                        }
                    ).catch((e) => {
                        console.log(e)
                        this.$message({
                            type: 'warning',
                            message: '登录异常'
                        });
                    })
                },
                handleClick(tab) {

                    if (tab.name === 'first') {
                        this.loginForm.loginRole = '2'
                        this.path = '/examinationPaper'
                    } else {
                        this.loginForm.loginRole = '3'
                        this.path = '/clubactivity'
                    }
                },
            }
    }
</script>
<style rel="stylesheet/scss" scoped lang="scss">
    @import "../../styles/mixin.scss";

    $bg: #2d3a4b;
    $dark_gray: #889aa4;
    $light_gray: #eee;
    .login-container {
        @include relative;
        /*width: 100vw;*/
        /*height: 100vh;*/
        /*background: url('../../assets/beijing.png') no-repeat;*/
        /*background-size: 100% 100%;*/

        .login-form {
            position: absolute;
            left: 50%;
            top: 100px;
            transform: translate(-50%);
            /*width: 380px;*/
            width: 250px;
            /*height: 338px;*/
            height: 220px;
            padding: 10px 20px 20px 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px 0 rgba(0, 0, 0, 0.10);

            .title-class {
                display: flex;
                margin-bottom: 9px;
            }

            .tab-Class {
                /*font-size: 14px !important;*/
                /*color: #798082;*/
                /*letter-spacing: 0px;*/
                /*line-height: 14px;*/
                /*font-family: PingFangSC-Medium;*/
            }

            .tab-Class /deep/ .el-tabs__active-bar {
                background-color: #EA414E !important;
                width: 50% !important;
            }

            .tab-Class /deep/ .el-tabs__bar {
                background-color: #EA414E !important;
                width: 50% !important;
            }

            .tab-Class /deep/ .el-tabs__nav {
                /*color: #EA414E !important;*/
                width: 100% !important;
            }

            .tab-Class /deep/ .el-tabs__item {
                padding: 10px 0px 0px 0px;
                width: 50%;
                text-align: center;
                font-size: 14px !important;
                color: #798082;
                letter-spacing: 0px;
                line-height: 14px;
                font-family: PingFangSC-Medium;
                font-weight: 600 !important;
            }

            .tab-Class /deep/ .el-tabs__item.is-active {
                color: #0e131a !important;
            }

            .tab-Class /deep/ .el-tabs__item:hover {
                color: #0e131a !important;
            }

            .login-btn {
                background-image: linear-gradient(135deg, #EE5863 0%, #EA414E 100%);
                border-radius: 4px;
                border: none;
                width: 100%;
                height: 30px;
                font-family: PingFangSC-Medium;
                color: #FFFFFF;
                letter-spacing: 0.24px;
                /*text-align: center;*/
                padding: 0px;
            }

            .login-btn /deep/  span {
                font-size: 12px !important;
                line-height: 12px !important;
                text-align: center;
                letter-spacing: 0;
                font-family: PingFangSC-Medium;
            }
        }

        .login-form /deep/ .el-form-item {
            margin-bottom: 0px !important;
            background: #FFFFFF;
            border-radius: 4px;
            color: #454545;
        }

        .login-form /deep/ .el-input-group__prepend {
            background-color: #fcfcfc !important;
            padding: 0 10px 0 10px;
        }

        .login-form /deep/ .el-input-group__append {
            background-color: #fcfcfc !important;
            padding: 0 10px 0 10px;

            span {
                color: #303133 !important;
                font-size: 10px;
            }
        }

        .login-form /deep/ .el-form-item__error {
            top:28px;
            padding-top: 0;
            left: 35px;
        }


    }


</style>
