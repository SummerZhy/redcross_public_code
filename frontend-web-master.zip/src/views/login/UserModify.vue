<template>
  <div style="padding-top: 6%">
    <el-row>
      <el-col :span="7">&nbsp;</el-col>
      <el-col :span="10">
        <el-tabs>
          <el-tab-pane label="修改密码">
             <el-card type="form">
               <el-form ref="userForm" :rules="validateRules" :model="userForm" label-width="100px">
                 <el-form-item label="原始密码：" prop="oldUserCode">
                   <el-input type="password" v-model="userForm.oldUserCode" placeholder="请输入密码"></el-input>
                 </el-form-item>
                 <el-form-item label="密码：" prop="newUserCode">
                   <el-input type="password" v-model="userForm.newUserCode" placeholder="请输入密码"></el-input>
                 </el-form-item>
                 <el-form-item label="密码确认：" prop="reNewCode">
                   <el-input type="password" v-model="userForm.reNewCode" placeholder="请确认密码"></el-input>
                 </el-form-item>
                 <div class="btn-container" style="text-align: center">
                   <el-button type="primary" @click.native="userModify">修改</el-button>
                   <el-button type="primary" @click.native="resetForm">重置</el-button>
                 </div>
               </el-form>
             </el-card>
          </el-tab-pane>
        </el-tabs>
      </el-col>
      <el-col :span="7">&nbsp;</el-col>
    </el-row>
  </div>
</template>

<script>
  import crypto from '@/utils/crypto'
  import validator from '@/utils/validator'
    export default {
        name: "modify",
        data () {
          return {
            userForm: {
              uuid: '',
              oldUserCode: '',
              newUserCode: '',
              reNewCode: ''
            },
            validateRules: {
              oldUserCode: [{required: true, trigger: 'blur', message: "请输入原始密码"}],
              newUserCode: [
                {required: true, trigger: 'blur', message: "请输入新密码"},
                {validator: validator.userCode, trigger: 'blur'}],
              reNewCode: [
                {required: true, trigger: 'blur', message: "请确认新密码"},
                {validator: validator.userCode, trigger: 'blur'}],
            },
          }
        },
      computed: {

      },
      methods: {
        userModify() {
          this.$refs.userForm.validate(valid => {
            if (valid) {
              if (this.userForm.newUserCode !== this.userForm.reNewCode) {
                this.$message.warning('两次密码不一致！')
                return
              }
              //获取盐值
              this.$api.myApi.getSalt()
                .then(res => {
                  if (res.retCode === '0') {
                    //注册
                    //加密
                    const key = 'uswn46hea7p3j8ou38n1sirm'
                    const salt = res.result.salt
                    this.userForm.uuid = res.result.uuid
                    this.userForm.oldUserCode = crypto.encryptByDES((this.userForm.oldUserCode + salt), key)
                    this.userForm.newUserCode = crypto.encryptByDES((this.userForm.newUserCode + salt), key)
                    this.userForm.reNewCode = crypto.encryptByDES((this.userForm.reNewCode + salt), key)
                    this.$api.myApi.codeModify(this.userForm)
                      .then(res => {
                        if (res.retCode === '0') {
                          this.$message({type:'success',message: '密码修改成功！'})
                          this.$router.push('/')
                        } else {
                          this.$message({
                            type: 'error',
                            message: res.retMsg,
                            duration: 3 * 1000
                          });
                          this.userForm.newUserCode = ''
                          this.userForm.reNewCode = ''
                        }
                      })
                      .catch(err => {
                        this.userForm.oldUserCode = ''
                        this.userForm.newUserCode = ''
                        this.userForm.reNewCode = ''
                      })
                  }
                })
            }
          })
        },
        resetForm() {
          this.userForm.oldUserCode = ''
          this.userForm.newUserCode = ''
          this.userForm.reNewCode = ''
        },
      }
    }
</script>

<style scoped>

</style>
