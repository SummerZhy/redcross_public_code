<template>
    <div>
        <div class="login-container">
            <el-form :model="loginForm"
                     :rules="loginRules"
                     autoComplete="on"
                     ref="loginForm"
                     class="card-box login-form"
                     label-width="0px"
                     label-position="left">

                <div class="title-class">
                    <div class="item-label">登录</div>
                    <div class="english-login">Login</div>
                </div>
                <div class="red-line"></div>
                <el-form-item prop="userName">
                    <el-input v-model="loginForm.userName"
                              @keyup.enter.native="handleLogin"
                              placeholder="请输入用户名">
                        <template slot="prepend">
                            <i slot="prefix">
                                <svg-icon icon-class="ID"></svg-icon>
                            </i>
                        </template>
                    </el-input>
                </el-form-item>
                <el-form-item prop="userCode">
                    <el-input
                            type="password"
                            @keyup.enter.native="handleLogin"
                            placeholder="请输入密码"
                            v-model="loginForm.userCode">
                        <template slot="prepend">
                            <i slot="prefix">
                                <svg-icon icon-class="password"></svg-icon>
                            </i>
                        </template>
                    </el-input>
                </el-form-item>
                <br>
                <el-form-item>
                    <el-button class="login-btn" :loading="loading" @click.native.prevent="handleLogin">
                        登录
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>
    import {getToken, removeToken, setToken, setUserInfo, getUserInfo, removeUserInfo} from '@/utils/auth'
    import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
    import crypto from '@/utils/crypto'
    import store from '../../store'

    export default {
        name: 'login',
        data() {
            return {
                loginForm: {
                    userName: '',
                    uuid: '',
                    userCode: ''
                },
                salt: '',
                loginRules: {
                    userName: [{required: true, trigger: 'blur', message: "请输入手机号"}],
                    userCode: [{required: true, trigger: 'blur', message: "请输入密码"}]
                },
                loading: false
            }
        },
        methods: {
            ...mapActions('user', [
                'GetInfo',
            ]),
            ...mapActions('dictionary', [
                'getDicList',
            ]),
            handleLogin() {
                this.$refs.loginForm.validate(valid => {
                    if (valid) {
                        this.loading = true
                        //获取盐值
                        this.$api.myApi.getSalt()
                            .then(res => {
                                if (res.retCode === '0') {
                                    //密码加密
                                    this.loginForm.uuid = res.result.uuid;
                                    this.loginForm.userCode = crypto.encryptByRSA(this.loginForm.userCode, res.result.salt)
                                    this.$api.myApi.login(this.loginForm)
                                        .then(res => {
                                            if (res.data.retCode == '0') {
                                                setUserInfo('userId', res.data.result.userId)
                                                setUserInfo('userName', res.data.result.userName)
                                                window.localStorage.removeItem('accessedRouters')
                                                //存储token
                                                //存储在cookie中
                                                setToken(res.headers.authorization)
                                                //请求字典项
                                                store.dispatch('dictionary/getDicList')
                                                //请求用户信息
                                                store.dispatch('GetInfo', {roleId: ''})
                                                    .then(res => {
                                                        if (res.retCode === '0') {
                                                            this.loading = false
                                                            this.$router.push('/')
                                                        } else {
                                                            this.$message({
                                                                type: 'error',
                                                                message: res.retMsg,
                                                                duration: 3 * 1000
                                                            });
                                                            this.loginForm.userCode = ''
                                                            this.loading = false
                                                            removeToken()
                                                            removeUserInfo('userId')
                                                            removeUserInfo('userName')
                                                        }
                                                    })
                                                    .catch(err => {
                                                        this.$message({
                                                            type: 'error',
                                                            message: '查询权限信息失败',
                                                            duration: 3 * 1000
                                                        });
                                                        this.loading = false
                                                        this.loginForm.userCode = ''
                                                        removeToken()
                                                        removeUserInfo('userId')
                                                        removeUserInfo('userName')
                                                    })
                                                this.loading = false
                                                // this.$router.push('/')
                                            } else {
                                                this.$message({
                                                    type: 'error',
                                                    message: res.data.retMsg,
                                                    duration: 3 * 1000
                                                });
                                                this.loginForm.userCode = ''
                                                this.loading = false
                                            }
                                        })
                                        .catch(err => {
                                            this.loading = false
                                            this.loginForm.userCode = ''
                                        })

                                } else {
                                    this.$message({
                                        type: 'error',
                                        message: res.retMsg,
                                        duration: 3 * 1000
                                    });
                                    this.loading = false
                                }
                            })
                    } else {
                        return false
                    }
                })
            },
        }
    }
</script>
<style rel="stylesheet/scss" scoped lang="scss">
    @import "../../styles/mixin.scss";

    $bg: #2d3a4b;
    $dark_gray: #889aa4;
    $light_gray: #eee;
    .login-container {
        @include relative;
        width: 100vw;
        height: 100vh;
        background: url('../../assets/beijing.png') no-repeat;
        background-size: 100% 100%;

        .login-form {
            position: absolute;
            left: 60.4%;
            top: 140px;
            width: 380px;
            height: 338px;
            padding: 30px 30px 30px 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px 0 rgba(0,0,0,0.10);

            .title-class {
                display: flex;
                margin-bottom: 9px;
            }

            .item-label {
                font-family: PingFangSC-Medium;
                font-size: 28px;
                color: #0E131A;
                letter-spacing: 0;
                line-height: 28px;
                width: 56px;
                margin-right: 10px;
            }

            .english-login {
                font-family: PingFangSC-Regular;
                font-size: 16px;
                color: #798082;
                letter-spacing: 0;
                line-height: 16px;
                width: 42px;
                margin-top: 12px;
            }

            .red-line {
                width: 108px;
                height: 2px;
                background: #EA414E;
                margin-bottom: 39px;
            }

            .svg-container {
                background: #FCFCFC;
                /*border: 1px solid #DCDFE6;*/
                border-radius: 4px 0px 0px 4px;
                /*padding: 6px 5px 6px 15px;*/
                padding: 14px 12px 14px 12px;
                vertical-align: middle;
                width: 44px;
                height: 40px;
                display: inline-block;

                &_login {
                    font-size: 20px;
                }
            }

            .login-btn {
                background-image: linear-gradient(135deg, #EE5863 0%, #EA414E 100%);
                border-radius: 4px;
                border: none;
                width: 320px;
                height: 40px;
                font-family: PingFangSC-Medium;
                font-size: 14px;
                color: #FFFFFF;
                letter-spacing: 0.24px;
                text-align: center;
                line-height: 14px;
                /*margin-top: 40px;*/
            }
        }

        .el-form-item {
            margin-bottom: 20px;
            background: #FFFFFF;
            border-radius: 4px;
            color: #454545;
        }
    }
</style>
