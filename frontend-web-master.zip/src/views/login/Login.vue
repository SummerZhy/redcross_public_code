<template>
  <div>
    <div class="header">
      <img class="logoClass" style="opacity:0;" src="../../assets/WechatIMG2.png">
    </div>
    <div class="body" :style="body">
      <div class="container">
        <div class="loginFrame" style="margin-left: 12%">
          <el-form
            :model="loginForm"
            :rules="loginRules"
            ref="loginForm"
            style="width: 550px;height: 550px;margin-left: 9%"
            label-position="left">
            <el-form-item style="margin-top: 5%"></el-form-item>
            <el-form-item></el-form-item>
            <el-form-item style="margin-top: 5%;">
              <span class="title">欢迎登录</span>
              <!-- <span class="title1">人才云</span> -->
            </el-form-item>
            <el-form-item prop="userName" style="width: 88%">
              <div>
                <el-input
                  v-model="loginForm.userName"
                  style="width: 452px;height: 38px;margin-top: 4%"
                  @keyup.enter.native="handleLogin"
                  placeholder="请输入用户名">
                  <i slot="prefix">
                    <svg-icon icon-class="person"></svg-icon>
                  </i>
                </el-input>
              </div>
            </el-form-item>
            <el-form-item prop="userCode" style="width: 88%;">
              <el-input
                type="password"
                @keyup.enter.native="handleLogin"
                style="width: 452px;height: 38px;margin-top: 1%"
                placeholder="请输入密码"
                v-model="loginForm.userCode">
                <i slot="prefix">
                  <svg-icon icon-class="lock1"></svg-icon>
                </i>
              </el-input>
            </el-form-item>
            <br>
            <!--<router-link class="register" to="/user-register">用户注册</router-link>-->
            <!--<router-link to="/userModify" style="margin-left: 19%">修改密码</router-link>-->
            <!--<router-link class="forgetPwd" to="/user-forget">忘记密码</router-link>-->
            <el-form-item style="margin-top: 10px">
              <el-button style="width: 452px;background-color: #E10807;border-radius: 5px;color: white"
                         :loading="loading" @click.native.prevent="handleLogin">
                登录
              </el-button>
              <!--              <button @click="exportSelect">导出</button>-->
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
    <!-- <div class="footer">
       <span class="footerText">© 2017-2019rencaiyun, all rights reserved 国投 京ICP备18245212号-1</span>
     </div>-->
  </div>
</template>
<script>
  import {getToken, removeToken, setToken, setUserInfo, getUserInfo, removeUserInfo} from '@/utils/auth'
  import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
  import crypto from '@/utils/crypto'
  import store from '../../store'

  export default {
    name: 'login',
    data() {
      return {
        loginForm: {
          userName: '',
          uuid: '',
          userCode: ''
        },
        salt: '',
        body: {
          width: '100%',
          backgroundImage: 'url(' + require('../../assets/beijing.png') + ')',
          backgroundSize: '100% 100%',
          //backgroundColor:'black',
          backgroundRepeat: 'no-repeat',
          overflow: 'hidden',
          // height: '500px',
          scroll: 'no'
        },
        loginRules: {
          userName: [{required: true, trigger: 'blur', message: "请输入手机号"}],
          userCode: [{required: true, trigger: 'blur', message: "请输入密码"}]
        },
        loading: false
      }
    },
    methods: {
      ...mapActions('user', [
        'GetInfo',
      ]),
      ...mapActions('dictionary', [
        'getDicList',
      ]),
      handleLogin() {
        this.$refs.loginForm.validate(valid => {
          if (valid) {
            this.loading = true;
            this.$router.push('/');
            //获取盐值
            // this.$api.myApi.getSalt()
            //   .then(res => {
            //     if (res.retCode === '0') {
                  //密码加密
                  this.loginForm.uuid = 'b4261e60927b46e09ca8a410450058fa';
                  // // this.loginForm.userCode = crypto.encryptByRSA(this.loginForm.userCode, res.result.salt)
                  // this.loginForm.userCode = this.loginForm.userCode;
                  this.$api.myApi.login(this.loginForm)
                    .then(res => {
                      if (res.data.retCode == '0') {
                        setUserInfo('userId', res.data.result.userId)
                        setUserInfo('userName', res.data.result.userName)
                        window.localStorage.removeItem('accessedRouters')
                        //存储token
                        //存储在cookie中
                        setToken(res.headers.authorization)
                        //请求字典项
                        store.dispatch('dictionary/getDicList')
                        //请求用户信息
                        store.dispatch('GetInfo', {roleId: ''})
                          .then(res => {
                            if (res.retCode === '0') {
                              this.loading = false
                              this.$router.push('/')
                            } else {
                              this.$message({
                                type: 'error',
                                message: res.retMsg,
                                duration: 3 * 1000
                              });
                              this.loginForm.userCode = ''
                              this.loading = false
                              removeToken()
                              removeUserInfo('userId')
                              removeUserInfo('userName')
                            }
                          })
                          .catch(err => {
                            this.$message({
                              type: 'error',
                              message: '查询权限信息失败',
                              duration: 3 * 1000
                            });
                            this.loading = false
                            this.loginForm.userCode = ''
                            removeToken()
                            removeUserInfo('userId')
                            removeUserInfo('userName')
                          })
                        this.loading = false
                        // this.$router.push('/')
                      } else {
                        this.$message({
                          type: 'error',
                          message: res.data.retMsg,
                          duration: 3 * 1000
                        });
                        this.loginForm.userCode = ''
                        this.loading = false
                      }
                    })
                    .catch(err => {
                      this.loading = false
                      this.loginForm.userCode = ''
                    })

                // } else {
                //   this.$message({
                //     type: 'error',
                //     message: res.retMsg,
                //     duration: 3 * 1000
                //   });
                //   this.loading = false
                // }
              // })
          } else {
            return false
          }
        })
      },
      // handleLogin() {
      //   this.$refs.loginForm.validate(valid => {
      //     if (valid) {
      //       this.loading = true
      //       //获取盐值
      //       this.$api.myApi.getSalt()
      //         .then(res => {
      //           if (res.retCode === '0') {
      //             //密码加密
      //             const key = 'uswn46hea7p3j8ou38n1sirm'
      //             this.loginForm.uuid = res.result.uuid
      //             this.loginForm.userCode = crypto.encryptByDES((this.loginForm.userCode + res.result.salt), key)
      //             this.$api.myApi.login(this.loginForm)
      //               .then(res => {
      //                 if (res.data.retCode === '0') {
      //                   setUserInfo('userId', res.data.result.userId)
      //                   setUserInfo('nickName', res.data.result.nickName)
      //                   window.localStorage.removeItem('accessedRouters')
      //                   //存储token
      //                   //存储在cookie中
      //                   setToken(res.headers.authorization);
      //                   this.initDic();
      //
      //                  /*  store.dispatch('GetInfo')
      //                     .then(res => {
      //                       if(res.retCode === '0') {
      //                         this.loading = false
      //                         this.$router.push('/')
      //                       } else {
      //                         this.$message({
      //                           type: 'error',
      //                           message: res.retMsg,
      //                           duration: 3 * 1000
      //                         });
      //                         this.loginForm.userCode = ''
      //                         this.loading = false
      //                         removeToken()
      //                         removeUserInfo('userId')
      //                         removeUserInfo('nickName')
      //                       }
      //                     })
      //                     .catch(err => {
      //                       this.$message({
      //                         type: 'error',
      //                         message: '查询权限信息失败',
      //                         duration: 3 * 1000
      //                       });
      //                       this.loading = false
      //                       this.loginForm.userCode = ''
      //                       removeToken()
      //                       removeUserInfo('userId')
      //                       removeUserInfo('nickName')
      //                     }) */
      //
      //                   this.loading = false
      //                   this.$router.push('/')
      //
      //                 } else {
      //                   this.$message({
      //                     type: 'error',
      //                     message: res.data.retMsg,
      //                     duration: 3 * 1000
      //                   });
      //                   this.loginForm.userCode = ''
      //                   this.loading = false
      //                 }
      //               })
      //               .catch(err => {
      //                 this.loading = false
      //                 this.loginForm.userCode = ''
      //               })
      //
      //           } else {
      //             this.$message({
      //               type: 'error',
      //               message: res.retMsg,
      //               duration: 3 * 1000
      //             });
      //             this.loading = false
      //           }
      //         })
      //     } else {
      //       return false
      //     }
      //   })
      // },
      //导出选项
      exportSelect() {
        let params = {
          userIds: 'chenf',
        }
        this.$api.myApi.permission.uerExport(params)
          .then(res => {
            if (res.retCode == 0) {
              this.$message.success(res.retMsg);
            } else {
              this.$message.error(res.retMsg);
            }
          })
      },
    }
  }
</script>
<style rel="stylesheet/scss" scoped lang="scss">
  @import "../../styles/mixin.scss";

  $bg: #2d3a4b;
  $dark_gray: #889aa4;
  $light_gray: #eee;
  .header {
    margin-top: 30px;
    margin-left: 40%;
  }

  .renCai {
    width: 141px;
    height: 45px;
    font-size: 36px;
    font-weight: 500;
    color: rgba(51, 51, 51, 1);
    line-height: 80px;
  }

  .svg-container {
    padding: 6px 5px 6px 15px;
    width: 30px;

    &_login {
      font-size: 20px;
    }
  }

  .renCai1 {
    width: 141px;
    height: 14px;
    font-size: 15px;
    font-weight: 400;
    color: rgba(153, 153, 153, 1);
    line-height: 80px;
  }

  .forgetPwd {
    width: 48px;
    height: 12px;
    font-size: 12px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    margin-left: 63%;
    line-height: 30px;
  }

  .register {
    width: 48px;
    height: 12px;
    font-size: 12px;
    font-weight: 400;
    color: rgba(51, 51, 51, 1);
    margin-left: 0%;
    line-height: 30px;
  }

  .container {
    margin-top: 5%;
    margin-left: 50%;
    transform: translateX(-50%);
    width: 731px;
    height: 442px;
    background-image: url("../../assets/white.png");
  }

  .footer {
    margin-left: 36%;
    margin-top: 6%;
  }

  .footerText {
    width: 460px;
    height: 17px;
    font-size: 14px;
    font-weight: 400;
    color: rgba(153, 153, 153, 1);
    line-height: 34px;
  }

  .title {
    width: 160px;
    height: 23px;
    font-size: 24px;
    color: rgba(246, 47, 24, 1);
    line-height: 32px;
    margin-left: 30%;
    justify-content: center;
    align-content: center;
    font-weight: bold;
  }

  .title1 {
    width: 85px;
    height: 12px;
    font-size: 15px;
    color: #999999;
    line-height: 16px;
    margin-left: 10px;
    margin-bottom: 26px;
    text-align: center;
  }
</style>
