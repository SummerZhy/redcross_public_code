<template>
  <div class="main-con">
      <h2>捐赠公示信息</h2>
      <template>
          <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane label="统计图表" name="chart">
                  <div class="one">
                      <h6>公示信息</h6>
                      <div>
                          <div class="one-left">
                              <p>累计捐赠金额</p>
                              <span>{{tab1Date.accumulative}}</span>(万元)
                          </div>
                          <div class="one-right">
                              <p>累计捐赠笔数</p>
                              <span>{{tab1Date.donateFrequency}}</span>
                          </div>
                      </div>
                      <h6>统计图表</h6>
                      <div class="charts">
                          <div id="bar">
                          </div>
                          <div id="pie">
                          </div>
                      </div>
                  </div>
              </el-tab-pane>
              <el-tab-pane label="受赠人信息" name="information">
                  <div class="two">
                      <div class="con-list">
                          <el-table
                              ref="multipleTable"
                              :data="tableData"
                              height="500"
                              border
                              style="width: 100%"
                            >
                            <el-table-column width="70px" align="center" label="序号">
                              <template slot-scope="scope">
                                <span v-text="getIndex(scope.$index)"></span>
                              </template>
                            </el-table-column>
                            <el-table-column
                              prop="date"
                              label="受赠日期">
                            </el-table-column>
                            <el-table-column
                              prop="beneficiaL"
                              label="受赠人">
                            </el-table-column>
                            <el-table-column
                              prop="type"
                              label="受赠形式">
                            </el-table-column>
                            <el-table-column
                              prop="amount"
                              label="金额(元)">
                            </el-table-column>
                            <el-table-column
                              prop="remark"
                              label="备注">
                            </el-table-column>
                          </el-table>
                          <p style="line-height: 30px;font-size: 12px;">注：以上信息若有误，请及时联系我们查证，爱心电话：<a href="#" style="color: blue;">0546-8313089</a></p>
                          <el-pagination
                              @size-change="getOutStaList"
                              @current-change="getOutStaList"
                              :current-page="currentPage4"
                              :page-sizes="[10,20]"
                              :page-size="10"
                              layout="total, sizes, prev, pager, next, jumper"
                              :total="totalNum">
                          </el-pagination>
                      </div>
                  </div>
              </el-tab-pane>
          </el-tabs>
      </template>
  </div>
</template>
<script>
  export default {
      name:"reception",
      data() {
          return {
              activeName: 'chart',
              tab1Date:[],
              dataZiJin:[],
              useList:[],
              queryForm:{
                  currentPage:1,
                  limit:10
              },
              currentPage4:2,
              totalNum:'',
              tableData:[],
          };
      },
      created(){
         this.getOutStaInfo();
         this.getOutStaList();
          
      },
      mounted(){
         this.drawChart()
      },
      methods: {
          //tab
          handleClick(tab, event) {
              console.log(tab, event);
          },
          // tab1
          getOutStaInfo(){
              this.$api.myApi.statistics.getOutStaInfo()
                  .then(res => {
                      if (res.retCode == 0) {
                        this.tab1Date=res.result;
                        this.dataZiJin=res.result.monthList;
                        this.useList=res.result.useList;
                        console.log('1',res.result)
                      } else {
                          this.$message.error(res.retMsg);
                      }
                  })
          },
          // tab2
          //表格序号
          getIndex($index) {
           return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
          },
          getOutStaList(){
              let param=this.queryForm
              this.$api.myApi.statistics.getOutStaList(param)
              .then(res => {
                  if (res.retCode == 0) {
                          console.log('2',res)
                          this.totalNum = res.result.totalNum;
                          this.tableData = res.result.list;
                      } else {
                          this.$message.error(res.retMsg);
                      }
                  })
          },
          //画图
          drawChart() {
              let myBarChart = this.$echarts.init(document.getElementById("bar"));
              let myPieChart = this.$echarts.init(document.getElementById("pie"));
              let option1 = {
                  title: {
                      text: '月度捐赠善款',
                      left: 'center'
                  },
                  // legend: {
                  //     data: ['资金', '物资价值']
                  // },
                  xAxis: [
                      {
                          type: 'category',
                          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                          axisPointer: {
                              type: 'shadow'
                          }
                      }
                  ],
                  yAxis: [
                      {
                          type: 'value',
                          name: '资金',
                          min: 0,
                          max: 250,
                          interval: 50,
                          axisLabel: {
                              formatter: '{value}万'
                          }
                      },
                      // {
                      //     type: 'value',
                      //     name: '物资价值',
                      //     min: 0,
                      //     max: 25,
                      //     interval: 5,
                      //     axisLabel: {
                      //         formatter: '{value}万'
                      //     }
                      // }
                  ],
                  series: [
                      {
                          name: '资金',
                          type: 'bar',
                          data: this.dataZiJin
                      },
                      // {
                      //     name: '物资价值',
                      //     type: 'line',
                      //     yAxisIndex: 1,
                      //     data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2]
                      // }
                  ]
              };

              let option2 = {
                  title: {
                      text: '捐赠善款用途统计',
                      left: 'center'
                  },
                  series: [
                      {
                          type: 'pie',
                          radius: '65%',
                          center: ['50%', '50%'],
                          data: this.useList
                      }
                  ]
              };
              myBarChart.setOption(option1);
              myPieChart.setOption(option2);
          }

      },
  };
</script>
<style lang="scss" scoped>
      h2{
          width:100%;
          padding-left:1%;
          line-height:30px;
          background-color:rgba(242, 242, 242, 1);
          margin-bottom: 10px;
      }
      .main-con /deep/ .el-tabs__item{
          font-size: 14px;
      }
      .one,.two{
          width: 90%;
          height: 600px;
          margin: 30px auto 0;
      }
      h6{
          border: 1px solid #F2F2F2;
          background:#FCFCFC;
          width: 90%;
          line-height: 26px;
          font-size: 12px;
          padding-left: 10px;
      }
      .one>div{
          display: flex;
          flex: row wrap;
          justify-content: start;
          align-items: center;
          width: 50%;
          margin-bottom: 20px;
      }
      .one-left,.one-right{
          border: 1px solid #F2F2F2;
          width: 40%;
          height: 80px;
          p{
              font-size: 12px;
              margin-left:24px;
              line-height:30px;
          }
          span{
              margin-left: 50%;
              transform: translateX(-50%);
              font-weight: 600;
              font-size: 16px;
          }
      }
      /* 图表 */
      .one>.charts{
          width: 100%;
      }
      #bar{
          display: inline-block;
          width: 50%;
          height: 300px;
          background-color: #FCFCFC;
          margin: 20px;
      }
      #pie{
          display: inline-block;
          width: 50%;
          height: 300px;
          background-color: #FCFCFC;
          margin: 20px;
      }
</style>    