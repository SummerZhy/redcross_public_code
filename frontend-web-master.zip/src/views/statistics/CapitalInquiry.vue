<template>
    
</template>

<script>
    export default {
        name: "CapitalInquiry"
    }
</script>

<style scoped>

</style>