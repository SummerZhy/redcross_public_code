<template>
    <div class="main-con">
		<section class="wrap-class">
			<title-style>基础信息填写</title-style>
			<el-form class="com-base-info-wrap" ref="form" :model="formData" label-width="110px" label-position="left" :rules="rules">
				<div>
					<section class="com-base-info-left" style="width: 60%;">
						<el-form-item label="用户编码" prop="userId">
							<span>{{formData.userId}}</span>
						</el-form-item>
						<el-form-item label="用户姓名" prop="userName">
							<span>{{formData.userName}}</span>
						</el-form-item>
						<el-form-item label="电话" prop="mobilePhone">
                            <el-input v-model="formData.mobilePhone" size="mini" clearable ></el-input>
						</el-form-item>
						<el-form-item label="用户角色" prop="roleId">
							<el-select v-model="formData.roleId" filterable placeholder="请选择" size="mini" style="width:100%">
								<el-option
								v-for="item in roles"
								:label="item.roleName"
								:key="item.roleId"
								:value="item.roleId">
								</el-option>
							</el-select>
						</el-form-item>
					</section>
				</div>
				<div>
					<section class="com-base-info-right" style="width: 60%;">
						<el-form-item label="所属机构" prop="branchName">
							<span>{{formData.branchName}}</span>
						</el-form-item>
						<el-form-item label="所属部门" prop="departmentName">
							<span>{{formData.departmentName}}</span>
						</el-form-item>
						<el-form-item label="E-mail" prop="mail" >
							<el-input v-model="formData.mail" size="mini" clearable></el-input>
						</el-form-item>
					</section>
				</div>
			</el-form>
			<section class="com-btn-wrap-center" style="text-align: center;line-height: 100px;">
				<div>
					<el-button type="danger" @click="toSave" size="mini">保存</el-button>
				</div>
			</section>
		</section>
	</div>
</template>

<script>
	import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
	import validator from '@/utils/validator'
    export default {
        name: "mainIndex",
        data(){
            return{
				roles:[],
                formData:{},
                rules:{
                    mail:[
						{ required: true, message: '请输入E-mail', trigger: 'blur' },
						{validator: validator.mail, trigger: 'blur'}
                    ],
                    mobilePhone:[
						{ required: true, message: '请输入电话', trigger: 'blur' },
						{validator: validator.telphone, trigger: 'blur'}
                    ],
                    roleId:[
						{ required: true, message: '请输入用户角色', trigger: 'blur' },
                    ],
				},
            }
        },
        computed:{
			...mapGetters('dictionary', [
			  'department'
			]),
		},
		watch:{
			roles(val,oldVal){
				return val;
			}
		},
        created(){
			this.getUserList();
			
            this.departmentName=this.formData.departmentName;
        },
        methods:{
            // 页面加载
            getUserList(){      
                this.$api.myApi.getUserList()
                    .then( res => {
                        if(res.retCode == '0'){
							this.formData = res.result;
							console.log(res)
							this.queryDetail();
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
			},
			//获取用户角色
			queryDetail(){
				let params = {
				userId:this.formData.userId
				}
				console.log(params)
				this.$api.myApi.permission.userInfoGet(params)
				.then( res => {
					if(res.retCode == 0){
					this.roles = res.result.roles;
					console.log(res.result);
					}else{
					this.$message.error(res.retMsg);
					}
				})
			},
            //保存
            toSave(){
				this.$refs.form.validate(valid => {
					if(valid){
						this.$confirm('确定保存该修改, 是否继续?', '提示', {
							confirmButtonText: '确定',
							cancelButtonText: '取消',
							type: 'warning',
						})
							.then(() => {
								if(this.formData.departmentName==this.departmentName){
									this.formData.departmentName=this.formData.departmentId
								}
                                let params={
                                    userId:this.formData.userId,
                                    mobilePhone:this.formData.mobilePhone,
                                    mail:this.formData.mail,
                                    roleId:this.formData.roleId,

                                }
								this.$api.myApi.changeUser(params)
                                    .then( res => {
                                        if(res.retCode == 0){
											this.$message.success('用户信息修改成功！');
											this.$router.push('/home');
                                        }else{
                                            this.$message.error(res.retMsg);
                                        }
                                    })
                                    .catch(() => {
                                        this.$message({
                                            type: 'info',
                                            message: '已取消修改',
                                        })
                                    })
							}); 
					}
				})
      		},		
        }
    }
</script>

<style scoped lang="scss">
    .power-wrap{
		margin:10px 0 20px 0;
		.power-con-wrap{
		padding:20px 30px;
		}
	}
	.com-base-info-wrap /deep/ .el-form-item{
		margin-bottom: 30px;
	}
	.com-base-info-wrap{
		display: flex;
    	justify-content: space-around;
	}
	.com-base-info-wrap /deep/ div{
		flex:1;
	}
</style>
