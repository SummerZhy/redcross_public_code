<template>
  <div class="app-wrapper" :class="{hideSidebar:!sidebar.opened}">
    <navbar class="app-hearder"></navbar>
    <div class="main-container">
      <sidebar class="sidebar-container"></sidebar>
      <head-bar></head-bar>
      <app-main></app-main>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, HeadBar } from "@/views/layout/components";
import {mapGetters,mapActions} from 'vuex'

export default {
  name: "layout",
  components: {
    Navbar,
    Sidebar,
    AppMain,
    HeadBar
  },
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar;
    }
  },
  mounted(){
    this.GetInfo()
  },
  methods:{
        ...mapActions(['GetInfo']),
  },
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "src/styles/mixin.scss";
.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
}
.app-hearder {
  position: fixed;
  height: 50px;
  width: 100%;
  background-image: linear-gradient(90deg, #35373a 0%, #373333 100%);
}
.main-container {
  background: #f3f3f3;
  height: 100%;
}
</style>
