<template>
  <el-menu class="navbar" mode="horizontal">
    <hamburger class="hamburger-container" :toggleClick="toggleSideBar" :isActive="sidebar.opened"></hamburger>
    <breadcrumb></breadcrumb>
  </el-menu>
</template>

<script>
import { mapGetters } from 'vuex'
import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import {getToken, removeToken, setToken, getUserInfo, removeUserInfo} from '@/utils/auth'

export default {
  components: {
    Breadcrumb,
    Hamburger
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ]),
    userName: {
      get () {
        return window.sessionStorage.getItem('userName')
      }
    }
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('ToggleSideBar')
      if(this.sidebar.opened){
        //展开

      }else{
        //收起

      }
    },
    logout() {
      this.$confirm('是否注销登录？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$api.myApi.logout(this.loginForm)
          .then((res) => {
            if(res.retCode == '0') {
              removeToken()
              removeUserInfo('userId')
              removeUserInfo('nickName')
              window.localStorage.removeItem('accessedRouters')
              //this.$store.commit('RESET_USER')
              this.$message({
                type: 'success',
                message: '登出成功！'
              })
              this.$router.push('/')
              location.reload()
            } else {
              this.$message({
                type: 'error',
                message: res.retMsg
              })
            }
          })
      }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消登出！'
          })
        }
      )
      /*this.$store.dispatch('LogOut').then(() => {
        location.reload() // 为了重新实例化vue-router对象 避免bug
      })*/
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  height: 44px;
  line-height: 44px;
  border-radius: 0px !important;
  box-shadow:12px 0 6px 1px rgba(200,200,200,0.2);
  .hamburger-container {
    line-height: 50px;
    height: 44px;
    float: left;
    padding: 0 10px;
    /*position:absolute;*/
  }
 /* .screenfull {
    position: absolute;
    right: 90px;
    top: 16px;
    color: red;
  }*/
 /* .avatar-container {
    height: 50px;
    display: inline-block;
    position: absolute;
    right: 35px;
    .avatar-wrapper {
      cursor: pointer;
      margin-top: 5px;
      position: relative;
      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 10px;
      }
      .el-icon-caret-bottom {
        position: absolute;
        right: -20px;
        top: 25px;
        font-size: 12px;
      }
    }
  }*/
}
</style>

