 <template>
  <div class="navbar">
    <hamburger class="hamburger-container" :toggleClick="toggleSideBar" :isActive="sidebar.opened"></hamburger>
    <breadcrumb></breadcrumb>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Breadcrumb from "@/components/Breadcrumb";
import Hamburger from "@/components/Hamburger";
import { getToken, removeToken, setToken } from "@/utils/auth";
export default {
  name: "HeadBar",
  computed: {
    ...mapGetters(["sidebar"])
  },
  components: {
    Breadcrumb,
    Hamburger
  },
  mounted() {
    /* let element = document.getElementById("navBar");
    if (this.sidebar.opened) {
      element.style.cssText = "width:calc(100% - 200px)";
    } else {
      element.style.cssText = "width:calc(100% - 26px)";
    } */
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch("ToggleSideBar");
      /* let element = document.getElementById("navBar");
      if (this.sidebar.opened) {
        //左侧菜单展开
        element.style.cssText = "width:calc(100% - 200px)";
      } else {
        element.style.cssText = "width:calc(100% - 26px)";
      } */
    }
  }
};
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  position: fixed;
  top: 56px;
  z-index: 999;
  height: 40px;
  width: 100%;
  line-height: 50px;
  border-radius: 0px !important;
  background-color: #ffffff;
  .hamburger-container {
    line-height: 48px;
    height: 40px;
    float: left;
    padding: 0 10px;
  }
  .screenfull {
    position: absolute;
    right: 90px;
    top: 13px;
    color: red;
  }
  .avatar-container {
    height: 50px;
    display: inline-block;
    position: absolute;
    right: 35px;
    .avatar-wrapper {
      cursor: pointer;
      margin-top: 3px;
      position: relative;
      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 10px;
      }
      .el-icon-caret-bottom {
        position: absolute;
        right: -20px;
        top: 15px;
        font-size: 12px;
      }
    }
  }
}
</style>
