<template>
  <section class="app-main">
    <transition name="fade" mode="out-in">
      <el-card class="box-card">
        <!-- <router-view :key="key"></router-view> -->
        <router-view></router-view>
      </el-card>
    </transition>
  </section>
</template>

<script>
export default {
  name: "AppMain",
  computed: {
    // key() {
    //   return this.$route.name !== undefined ? this.$route.name + +new Date() : this.$route + +new Date()
    // }
  }
};
</script>

<style>
.app-main{
  margin-top:100px;
}
.box-card {
  height: calc(100vh - 110px) !important;
  overflow: auto;
  margin: 60px 10px 10px 10px;
  border-radius: 8px;
  padding-bottom: 10px;
  box-sizing: border-box;
}
</style>
