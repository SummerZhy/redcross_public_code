<template>
  <scroll-bar>
    <el-menu mode="vertical"
             unique-opened
             :collapse="isCollapse"
             background-color="#d9dee0"
             text-color="#798082"
             active-text-color="#fff">
      <sidebar-item :routes="permission_routers"></sidebar-item>
    </el-menu>
  </scroll-bar>
</template>
<script>
  import {mapGetters} from 'vuex'
  import SidebarItem from './SidebarItem'
  import ScrollBar from '@/components/ScrollBar'

  export default {
    components: {SidebarItem, ScrollBar},
    computed: {
      ...mapGetters([
        'permission_routers',
        'sidebar'
      ]),
      isCollapse() {
        return !this.sidebar.opened
      }
    },
    mounted(){
    console.log('-------');
    console.log(this.sidebar);
  },
  watch:{
    'permission_routers'(val){
      if(val){
        console.log(this.permission_routers);

      }
    }
  }
  }
</script>
