<template>
    <!-- 资金追溯-捐赠人追溯 -->
    <div>
    <el-table
        :data="tableData"
        style="width: 100%">
        <el-table-column
            type="index"
            width="50"
            :index="getIndex"
            label="序号">
        </el-table-column>
        <el-table-column
            prop="cFundCode"
            label="资金编码">
        </el-table-column>
        <el-table-column
            prop="cDonerName"
            label="捐赠人">
        </el-table-column>
        <el-table-column
            prop="nTotalAmount"
            label="捐赠金额">
        </el-table-column>
        <el-table-column
            prop="cIsDirect"
            label="是否定向">
        </el-table-column>
        <el-table-column
            prop="cDonateDirection"
            label="捐赠方向">
        </el-table-column>
        <el-table-column
            prop="dEntryDate"
            label="捐赠日期">
        </el-table-column>
        <el-table-column
            prop="cFundStateName"
            label="资金状态">
        </el-table-column>
        <el-table-column
            prop="cRemark1"
            label="备注">
        </el-table-column>
        <el-table-column
            width="200"
            label="操作">
            <template slot-scope="scope">
                <el-button type="danger" size="mini" :disabled="scope.row.cFundState == '00' ? true : false" @click="getDetailList(scope.row.cFundCode)">捐赠详情</el-button> 
                <el-button type="danger" size="mini" @click="evaluateDialog=true; evaluateModel.cfundCode = scope.row.cFundCode">评价</el-button> 
            </template>    
        </el-table-column>
    </el-table>
    <el-pagination
        @size-change="getList"
        @current-change="getList"
        :current-page.sync="currentPage"
        :page-sizes="[10, 20,]"
        :page-size.sync="limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalNum">
    </el-pagination>
    <!-- 捐赠详情 -->
    <el-dialog title="捐赠详情" :visible.sync="dialogTableVisible" width="50%">
        <el-table :data="detailData">
            <el-table-column type="index" width="50" :index="getDetailIndex" label="序号"></el-table-column>
            <el-table-column property="cProjectCodeChild" label="子资金编码" ></el-table-column>
            <el-table-column property="cDonateAmount" label="捐出金额" ></el-table-column>
            <el-table-column property="cIsDirect" label="是否定向"></el-table-column>
            <el-table-column property="cDirectont" label="捐赠方向"></el-table-column>
            <el-table-column property="dDate" label="捐出日期"></el-table-column>
            <el-table-column property="cdDoneeName" label="收款方"></el-table-column>
            <el-table-column property="benefEvaluation" label="受捐人评价"></el-table-column>
        </el-table>
        <el-pagination
            @size-change="getDetailList"
            @current-change="getDetailList"
            :current-page.sync="detailDataParam.currentPage"
            :page-sizes="[10, 20,]"
            :page-size.sync="detailDataParam.limit"
            layout="total, sizes, prev, pager, next, jumper"
            :total="detailDataTotalNum">
        </el-pagination>
        <div class="btn-wrap">
            <el-button type="danger" @click="evaluateDialog=true">评价</el-button>
            <el-button @click="dialogTableVisible=false">返回</el-button>
        </div>
    </el-dialog>
    <!-- 评价弹窗 -->
    <el-dialog title="评价" :visible.sync="evaluateDialog" width="50%" @closed="closedEvaluateDialog">
        <el-form :model="evaluateModel">
            <el-form-item label="请您对我们的工作进行评价：">
                <el-rate allow-half v-model="evaluateModel.cScore"> </el-rate>
            </el-form-item>
            <el-form-item label="请留下您最宝贵的意见：">
                <el-input
                    type="textarea"
                    :rows="3"
                    placeholder="请输入内容"
                    v-model="evaluateModel.cevaluation">
                </el-input>
            </el-form-item>
        </el-form>
        <div class="btn-wrap">
            <el-button type="danger" @click="commitEvaluate">提交</el-button>
            <el-button @click="evaluateDialog=false">返回</el-button>
        </div>
    </el-dialog>
    </div>
</template>

<script>
//   import {mapGetters} from 'vuex'

export default {
    data(){
        return{
            tableData:[],
            totalNum:0,
            currentPage:1,
            limit:10,
            cdonorPhone:'12345678909',
            dialogTableVisible:false,
            detailData:[],
            detailDataTotalNum:0,
            detailDataParam:{
                currentPage:1,
                limit:10,
                cfundCode:'', //母资金编号
            },
            evaluateDialog:false,
            evaluateModel:{
                cfundCode:'',
                cscore:0,
                cevaluation:'',
                cdonorPhone:''
            }
        }
    },
    // computed: {
    //   ...mapGetters('dictionary', [
    //     'fundsSources',
    //   ])
    // },
    created(){
        this.getList();
    },
    methods:{
        getIndex(index){
            return (this.currentPage - 1) * this.limit + index + 1 
        },
        getList(){
            let params = {
                currentPage: this.currentPage,
                limit: this.limit,
                cdonorPhone: this.cdonorPhone
            }
            this.$api.myApi.fundRetrospect.getDonorList(params).then( res => {
                if(res.retCode == 0){
                    this.tableData = res.result.list;
                    this.totalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        getDetailIndex(index){
            return (this.detailDataParam.currentPage - 1) * this.detailDataParam.limit + index + 1 
        },
        //捐赠详情列表查询
        getDetailList(cFundCode){
            this.dialogTableVisible = true;
            this.detailDataParam.cfundCode = cFundCode;
            this.evaluateModel.cfundCode = cFundCode;
            this.$api.myApi.fundRetrospect.getDonorDetailList(this.detailDataParam).then( res => {
                if(res.retCode == 0){
                    this.detailData = res.result.list;
                    this.detailDataTotalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //提交评价
        commitEvaluate(){
            this.evaluateModel.cdonorPhone = this.cdonorPhone;
            this.$api.myApi.fundRetrospect.putEvaluate(this.evaluateModel).then( res => {
                if(res.retCode == 0){
                    this.$message.success(res.retMsg);
                    this.evaluateDialog = false;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //关闭评价弹窗 重置数据
        closedEvaluateDialog(){
            this.evaluateModel = {
                cfundCode:'',
                cscore:0,
                cevaluation:'',
                cdonorPhone:''
            }
        },
    }
}
</script>

<style lang="scss" scoped>
    .flag-text-blue{
        cursor:pointer;
        color:#5688CB;
    }
    .flag-text-gray{
        color:#ccc;
    }
    .btn-wrap{
        text-align:center;
    }
    .el-rate{
        line-height:50px;
    }
    .el-textarea{
        width:70% !important;
    }
</style>

