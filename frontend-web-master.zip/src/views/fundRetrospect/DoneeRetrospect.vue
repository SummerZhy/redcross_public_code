<template>
    <!-- 资金追溯-受赠人追溯 -->
    <div>
        <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
                type="index"
                width="50"
                :index="getIndex"
                label="序号">
            </el-table-column>
            <el-table-column
                prop="projectCode"
                label="项目编码">
            </el-table-column>
            <el-table-column
                prop="amount"
                label="受捐金额">
            </el-table-column>
            <el-table-column
                prop="isDirect"
                label="是否定向">
            </el-table-column>
            <el-table-column
                prop="direction"
                label="受捐方向">
            </el-table-column>
            <el-table-column
                prop="beneficialDate"
                label="受赠日期">
            </el-table-column>
            <el-table-column
                prop="moneyStatus"
                label="资金状态">
            </el-table-column>
            <el-table-column
                prop="remark"
                label="备注">
            </el-table-column>
            <el-table-column
                width="200"
                label="操作">
                <template slot-scope="scope">
                    <el-button type="danger" size="mini" :disabled="scope.row.moneyStatus=='已收款'? true : false" @click="confirmReceipt(scope.row.projectCode, scope.row.amount)">确认收款</el-button>
                    <el-button type="danger" size="mini" @click="evaluateDialog=true; evaluateModel.projectCode=scope.row.projectCode">评价</el-button>
                </template>    
            </el-table-column>
        </el-table>
        <el-pagination
            @size-change="getList"
            @current-change="getList"
            :current-page.sync="currentPage"
            :page-sizes="[10, 20,]"
            :page-size.sync="limit"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalNum">
        </el-pagination>
        <!-- 评价弹窗 -->
        <el-dialog title="评价" :visible.sync="evaluateDialog" width="50%" @closed="closedEvaluateDialog">
            <el-form :model="evaluateModel">
                <el-form-item label="请您对我们的工作进行评价：">
                    <el-rate allow-half v-model="evaluateModel.star"> </el-rate>
                </el-form-item>
                <el-form-item label="请留下您最宝贵的意见：">
                    <el-input
                        type="textarea"
                        :rows="3"
                        placeholder="请输入内容"
                        v-model="evaluateModel.comment">
                    </el-input>
                </el-form-item>
            </el-form>
            <div class="btn-wrap">
                <el-button type="danger" @click="commitEvaluate">提交</el-button>
                <el-button @click="evaluateDialog=false">返回</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data(){
        return{
            tableData:[],
            totalNum:0,
            currentPage:1,
            limit:10,
            phone:'12345678909',
            evaluateDialog:false,
            evaluateModel:{
                star:0,
                comment:'',
                projectCode:'',
                phone:'',
            }
        }
    },
    created(){
        this.getList();
    },
    methods:{
        getIndex(index){
            return (this.currentPage - 1) * this.limit + index + 1 
        },
        getList(){
            let params = {
                currentPage: this.currentPage,
                limit: this.limit,
                phone: this.phone
            }
            this.$api.myApi.fundRetrospect.getOutflowList(params).then( res => {
                if(res.retCode == 0){
                    this.tableData = res.result.list;
                    this.totalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //确认收款
        confirmReceipt(projectCode, amount){
            this.$confirm(`是否确认收取捐赠资金${amount}元`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'info'
                }).then(() => {
                    let params = {
                        projectCode: projectCode,
                        phone: this.phone
                    }
                    this.$api.myApi.fundRetrospect.outflowAffirminfo(params).then( res => {
                        if(res.retCode == 0){
                            this.$message.success(res.retMsg);
                        }else{
                        this.$message.error(res.retMsg);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消确认收款'
                    });          
                });         
        },
        //提交评价
        commitEvaluate(){
            this.evaluateModel.phone = this.phone;
            this.$api.myApi.fundRetrospect.outflowEvaluate(this.evaluateModel).then( res => {
                if(res.retCode == 0){
                    this.$message.success(res.retMsg);
                    this.evaluateDialog = false;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //关闭评价弹窗 重置数据
        closedEvaluateDialog(){
            this.evaluateModel = {
                star:0,
                comment:'',
                projectCode:'',
                phone:''
            }
        },
    }
}
</script>

<style lang="scss" scoped>
    .btn-wrap{
        text-align:center;
    }
    .el-rate{
        line-height:50px;
    }
    .el-textarea{
        width:70% !important;
    }
</style>

