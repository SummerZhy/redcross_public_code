<template>
    <div></div>
</template>

<script>
    export default {
        name: "EmptyPage",
      beforeRouteEnter(to,from,next){
          // console.log('to',to);
          // console.log('from',from);
          next(vm => {
            vm.$router.replace({
              path:from.path,
              query:from.query,
            });
          });
      }
    }
</script>

<style scoped>

</style>
