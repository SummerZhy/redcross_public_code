<!--  -->
<template>
  <div>功能建设中</div>
</template>
<script>
import Vue from 'vue';

export default {
  data() {
    return {};
  },
};
</script>
<style scoped>
</style>