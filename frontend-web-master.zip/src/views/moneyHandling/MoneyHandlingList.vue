<template>
    <div class="main-con">
        <el-form label-width="100px" size="small" label-position="left" class="wrap-class search-wrap">
            <el-row style="margin-bottom:10px">
                <el-col :span="7">
                    <el-form-item label="时间选择：" >
                        <el-date-picker type="date" placeholder="日期" v-model="queryForm.dEntryDate" value-format="yyyy-MM-dd" style="width: 100%;"></el-date-picker>
                        <!--<span>&nbsp;—&nbsp;</span>
                        <el-date-picker type="date" placeholder="结束日期" v-model="endTime"  value-format="yyyy-MM-dd" style="width: 40%"></el-date-picker>-->
                    </el-form-item>
                </el-col>
                <el-col :span="7">
                    <el-form-item label="处理状态：">
                          <el-select v-model="queryForm.chandleStatus" placeholder="请选择">
                            <el-option
                              v-for="item in manageState"
                              :key="item.paramId"
                              :label="item.paramName"
                              :value="item.paramId">
                            </el-option>
                          </el-select>
                       <!-- <el-input v-model="operId" clearable></el-input>-->
                    </el-form-item>
                </el-col>
                <el-col :span="7">
                    <el-form-item label="善款来源：">
                        <el-select v-model="queryForm.cdonateSource" placeholder="请选择">
                            <el-option
                                    v-for="item in fundsSources"
                                    :key="item.paramId"
                                    :label="item.paramName"
                                    :value="item.paramId">
                            </el-option>
                        </el-select>
                        <!-- <el-input v-model="operId" clearable></el-input>-->
                    </el-form-item>
                </el-col>
                <el-col :span="3" style="text-align:right;">
                    <el-button-group size="small">
                        <el-button type="danger" size="small" @click="refresh">查询</el-button>
                  <!--      <el-button size="small" v-show="!fold" @click="fold = !fold">展开</el-button>
                        <el-button size="small" v-show="fold" @click="fold = !fold">收起</el-button>-->
                    </el-button-group>
                </el-col>
            </el-row>
            <el-row v-show="fold">
                <el-col :span="7" >
                     <el-form-item label="捐赠意向：">
                       <el-select v-model="queryForm.cisDirect" placeholder="请选择">
                         <el-option
                           v-for="item in donateAspiration"
                           :key="item.paramId"
                           :label="item.paramName"
                           :value="item.paramId">
                         </el-option>
                       </el-select>
                      <!-- <el-input v-model="operId" style="width: 50%"></el-input>-->
                     </el-form-item>
                </el-col>
                <el-col :span="7" >
                    <el-form-item label="物资分配：">
                        <el-select v-model="queryForm.cdonateDirection" placeholder="请选择">
                            <el-option
                                    v-for="item in donationPurpose"
                                    :key="item.paramId"
                                    :label="item.paramName"
                                    :value="item.paramId">
                            </el-option>
                        </el-select>
                        <!-- <el-input v-model="operId" style="width: 50%"></el-input>-->
                    </el-form-item>
                </el-col>
                <el-col :span="7" >
                    <el-form-item label="字段检索：">
                        <el-input v-model="queryForm.entryInfo"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <section class="wrap-class">
            <div class="con-list">
                <el-table
                        ref="multipleTable"
                        :data="tableData"
                        style="width: 100%"
                >
                    <el-table-column width="70px" align="center" label="序号">
                        <template slot-scope="scope">
                            <span v-text="getIndex(scope.$index)"></span>
                        </template>
                    </el-table-column>
                   <!-- <el-table-column
                            label="用户编码"
                            width="180">
                        <template slot-scope="scope"><span class="com-click-class" @click="toDetail(scope.row.userId)">{{scope.row.userId}}</span></template>
                    </el-table-column>-->
                    <el-table-column
                            prop="cfundCode"
                            label="款项编码"
                           >
                    </el-table-column>
                    <el-table-column
                            prop="dEntryDate"
                            label="到账日期">
                    </el-table-column>
                    <el-table-column
                            width="100"
                            prop="cdonerName"
                            label="捐款人姓名">
                    </el-table-column>
                    <el-table-column
                            prop="ntotalAmount"
                            label="捐款金额">
                    </el-table-column>
                    <el-table-column
                            prop="nremainAmount"
                            label="剩余金额">
                       <!-- <template slot-scope="scope">
                            <span>{{ scope.row.status == 2 ? "已冻结" : "正常" }}</span>
                        </template>-->
                    </el-table-column>
                    <el-table-column
                            prop="cdonorPhone"
                            label="联系方式">
                    </el-table-column>
                    <el-table-column
                            prop="cdonateSource"
                            label="善款来源">
                    </el-table-column>
                    <el-table-column
                            prop="cisDirect"
                            label="捐赠意向">
                    </el-table-column>
                    <el-table-column
                            prop="cdonateDirection"
                            label="资金分配">
                    </el-table-column>
                    <el-table-column
                            prop="cremark"
                            label="备注">
                    </el-table-column>
                    <el-table-column
                            prop="chandleStatus"
                            label="处理状态">
                    </el-table-column>
                    <el-table-column
                            fixed="right"
                            width="100"
                            label="操作">
                        <template slot-scope="scope">
                            <span class="com-click-class" @click="toEdit(scope.row.cFundCode)">补录</span>
                            <span class="com-click-class" style="margin-left: 5px" @click="toDetail(scope.row.cFundCode)">详情</span>
                         <!--   <span class="com-click-class"  @click="resetPassword(scope.row.userId)">详情</span>-->
                        </template>
                    </el-table-column>
                </el-table>
                <el-pagination
                        @size-change="getMoneyList"
                        @current-change="getMoneyList"
                        :current-page.sync="queryForm.currentPage"
                        :page-sizes="[10, 20,]"
                        :page-size.sync="queryForm.limit"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalNum">
                </el-pagination>
            </div>
        </section>
        <el-dialog
                title="提示"
                :visible.sync="centerDialogVisible"
                width="30%"
                :show-close="false"
                center>
            <span style="text-align: center">请至少选择一条记录，谢谢。</span>
            <span slot="footer" class="dialog-footer">
          <el-button type="danger" @click="centerDialogVisible = false" class="dialogButton">取消</el-button>
        </span>
        </el-dialog>

    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    export default {
        name: "MoneyhandlingList",
        data(){
            return{
                fold:true,
                centerDialogVisible:false,
                inline:true,
                queryForm:{
                    currentPage:1,
                    limit:10,
                    dEntryDate:'',//时间
                    chandleStatus:'',//处理状态
                    cdonateSource:'',//善款来源
                    cisDirect:'',//捐款意向
                    cdonateDirection:'',//物资分配
                    entryInfo:'',//搜索框
                },
                totalNum:0,
                tableData:[],
                checkList:[],
                departmentNameList:[],
                exportList:[]
            }
        },
        computed:{
            ...mapGetters('dictionary', [
                'manageState',
                'fundsSources',
                'donateAspiration',
                'donationPurpose'
            ]),
        },
        created(){
            this.getMoneyList();
        },

        methods:{
            //详情
            toDetail(moneyId){
                this.$router.push({
                    path:'/moneyHandling/moneyHandling-details',
                    query:{
                        id:moneyId
                    }
                });
            },
            //补录
            toEdit(moneyId){
                this.$router.push({
                    path:'/moneyHandling/moneyHandling-supplement',
                    query:{
                        id:moneyId
                    }
                })
            },

            //请求列表
            getMoneyList(){
                this.$api.myApi.moneyHandling.getMoneyList(this.queryForm)
                    .then( res => {
                        if(res.retCode == 0){
                            this.totalNum = res.result.totalNum;
                            this.tableData = res.result.list;
                            //this.$message.success(res.retMsg)
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },

            //表格序号
            getIndex($index) {
                return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
            },
            //查询
            refresh(){
                this.queryForm.currentPage = 1;
                this.getMoneyList();
            },
        }
    }
</script>

<style scoped lang="scss">
    .search-wrap{
        padding:20px 30px;
        margin-bottom:10px;
        .el-form--inline .el-form-item{
            margin-right:30px;
        }
        .el-form-item{
            margin-bottom:0;
        }
    }

    .select{
        width: 224px;
    }
    .button{
        width:52px;
        height: 32px;
        padding: 9px 12px;
    }
    .downBtn{
        width: 96px;
        height: 32px;
    }
    .el-dialog__footer{
        width: 77px;
        height: 28px;
        padding: 24px 28px;
    }
    .el-dialog{
        border-radius: 4px;
    }
    .el-dialog__wrapper .el-dialog__body{
        font-family: PingFangSC-Medium;
        font-size: 14px;
        color: #606266;
        letter-spacing: 0;
        text-align: center!important;
        line-height: 14px;
    }
    .el-dialog__header{
        padding: 30px 20px 20px!important;
    }
</style>
