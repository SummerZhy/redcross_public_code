<template>
    <div class="main-con">
        <div class="com-operation-div">
            <section class="com-operation-left">
                <div>款项公示退回详情</div>
            </section>
            <section class="com-operation-right">
                <div></div>
            </section>
        </div>
        <el-card class="susp-query-list">
            <el-form size="small">
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">审核操作</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <el-col :span="7">
                                <span>{{review.reviewStatusName}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核建议：">
                            <el-col :span="7">
                                <span>{{review.reviewSuggest}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">入账信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="款项编码：">
                            <el-col :span="7">
                                <span>{{roleListData.cfundCode}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="日期：">
                            <el-col :span="9">
                                <span>{{roleListData.dentryDate}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人姓名：">
                            <el-col :span="9">
                                <span>{{roleListData.cdonerName}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="联系方式：">
                            <span>{{roleListData.cdonorPhone}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="邮箱：">
                            <span>{{roleListData.cemail}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人银行：">
                            <span>{{roleListData.cbankName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款人银行账户：">
                            <span>{{roleListData.cbankAcco}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款金额：">
                            <span>{{roleListData.ntotalAmount | money }}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="已捐出：">
                            <span>{{roleListData.nusedAmount | money }}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="剩余：">
                            <span>{{roleListData.nremainAmount | money }}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" v-if="roleListData.type != 2">
                        <el-form-item label="捐款方式：">
                            <span>{{roleListData.cdonateSourceName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐赠意向">
                            <span>{{roleListData.cisDirectName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="物资分配：">
                            <span>{{roleListData.cdonateDirectionName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="处理状态">
                            <span>{{roleListData.chandleStatusName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <span>{{roleListData.cexamineStatusName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{roleListData.cremark1}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">补录信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="捐款人姓名：">
                            <span>{{supplement.cdonerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份证号：">
                            <span>{{supplement.cidNo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="性别：">
                            <span>{{supplement.csexName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="年龄：">
                            <span>{{supplement.cage}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="职业：">
                            <span>{{supplement.cidentityInfoName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="公示模式：">
                            <span>{{supplement.ceffectModeName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{supplement.cremark2}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
            </el-form>
        </el-card>
        <section class="com-btn-wrap-center">
            <el-button @click="cancel" size="small">关闭</el-button>
        </section>
    </div>
</template>

<script>
    export default{
        name: "AuditReturnDetails",
        data(){
            return{
                id:this.$route.query.id,
                roleListData:[],
                supplement:[],
                review:[],
            }
        },
        created(){
            this.getDetails();
        },
        methods:{
            //获取详情
            getDetails(){
                let params = {
                    cfundCode:this.id
                }
                this.$api.myApi.moneyHandling.getMoneyDetail(params)
                    .then( res => {
                        if(res.retCode == 0){
                            this.roleListData = res.result.info; //入账信息
                            this.supplement = res.result.supplement;//补录信息
                            this.review = res.result.review;//审核操作
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //关闭
            cancel(){
                this.$router.push('/moneyHandling/audit-return');
            },
        }
    }
</script>

<style lang="scss" scoped>
    .power-wrap{
        margin:10px 0 20px 0;
        .power-con-wrap{
            padding:20px 30px;
        }
    }
</style>
