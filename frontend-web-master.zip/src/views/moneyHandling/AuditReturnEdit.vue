<template>
    <div class="main-con">
        <div class="com-operation-div">
            <section class="com-operation-left">
                <div>款项公示退回处理</div>
            </section>
            <section class="com-operation-right">
                <div></div>
            </section>
        </div>
        <el-card class="susp-query-list">
            <el-form label-position="left"
                     label-width="130px"
                     size="mini">
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">审核操作</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <el-col :span="7">
                                <span>{{review.reviewStatus}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核建议：">
                            <el-col :span="7">
                                <span>{{review.reviewSuggest}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">入账信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="款项编码：">
                            <el-col :span="7">
                                <span>{{roleListData.cFundCode}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="日期：">
                            <el-col :span="9">
                                <span>{{roleListData.dEntryDate}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人姓名：">
                            <el-col :span="9">
                                <span>{{roleListData.cDonerName}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="联系方式：">
                            <el-input v-model="roleListData.cDonorPhone"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人银行：">
                            <span>{{roleListData.cBankName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款人银行账户：">
                            <span>{{roleListData.cBankAcco}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款金额：">
                            <span>{{roleListData.nTotalAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="已捐出：">
                            <span>{{roleListData.nUsedAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="剩余：">
                            <span>{{roleListData.nRemainAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款方式：">
                            <el-select v-model="roleListData.cDonateType" placeholder="请选择">
                                <el-option
                                        v-for="item in fundsSources"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐赠意向">
                            <el-select v-model="roleListData.cIsDirect" placeholder="请选择">
                                <el-option
                                        v-for="item in donateAspiration"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="物资分配：">
                            <el-select v-model="roleListData.cDonateDirection" placeholder="请选择">
                                <el-option
                                        v-for="item in donationPurpose"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="处理状态">
                            <span>{{roleListData.cHandleStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <span>{{roleListData.cExamineStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24" >
                        <el-form-item label="备注：">
                            <span>{{roleListData.cRemark1}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">补录信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="捐款人姓名：">
                            <el-input v-model="supplement.cDonerName"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份证号：">
                            <el-input v-model="supplement.cIdNo"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="性别：">
                            <el-select v-model="supplement.cSex" placeholder="请选择">
                                <el-option
                                        v-for="item in sex"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="年龄：">
                            <!--<el-input v-model="supplement.cAge"></el-input>-->
                            <span>{{supplement.cAge}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份信息：">
                            <!-- <span>{{supplement.cIdentityInfo}}</span>-->
                            <el-select v-model="supplement.cStatus" placeholder="请选择">
                                <el-option
                                        v-for="item in identityInfo"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份信息详情：">
                            <!-- <span>{{supplement.cIdentityInfo}}</span>-->
                            <el-select v-model="supplement.cIdentityInfo" placeholder="请选择">
                                <el-option
                                        v-for="item in identityInfoDetail"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="公示模式：">
                            <!-- <span>{{supplement.cEffectMode}}</span>-->
                            <el-select v-model="supplement.cIdentityInfo" placeholder="请选择">
                                <el-option
                                        v-for="item in checkItem"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="18" >
                        <el-form-item label="备注：">
                            <el-input v-model="supplement.cRemark2" type="textarea"
                                      :rows="2"
                                      placeholder="请输入内容"
                            ></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
            </el-form>
        </el-card>
        <section class="com-btn-wrap-center">
            <el-button @click="cancel" size="small">关闭</el-button>
            <el-button @click="changePut" size="small" type="danger">修改</el-button>
        </section>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    export default{
        name: "AuditReturnEdit",
        data(){
            return{
                id:this.$route.query.moneyId,
                roleListData:[],
                supplement:[],
                review:[],
            }
        },
        created(){
            this.getDetails();
        },
        computed:{
            ...mapGetters('dictionary', [
                'manageState',
                'fundsSources',
                'donateAspiration',
                'donationPurpose',
                'sex',
                'identityInfo',
                'identityInfoDetail',
                'checkItem'
            ]),
        },
        methods:{
            //机构详情
            getDetails(){
                let params = {
                    /*id:this.id*/
                    id:'this.id'
                }
                this.$api.myApi.moneyHandling.getMoneyDetail(params)
                    .then( res => {
                        if(res.retCode == 0){
                            this.roleListData = res.result.info; //入账信息
                            this.supplement = res.result.supplement;//补录信息
                            this.review = res.result.review;//审核操作
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //关闭
            cancel(){
                this.$router.push('/moneyHandling/moneyHandling-list');
            },
            //修改事件
            changePut() {
                debugger;
                let params = {
                    cFundCode: this.roleListData.cFundCode,//资金编号
                    cDonorPhone:this.roleListData.cDonorPhone,//手机号码
                    cDonateSource:this.roleListData.cDonateType,//捐款方式
                    // cDonateSource:this.roleListData.cDonateSource,//捐款方式
                    cIsDirect:this.roleListData.cIsDirect,//捐款意向
                    cDonateDirection:this.roleListData.cDonateDirection,//物资分配
                    cDonerName:this.supplement.cDonerName,//捐款人姓名
                    cIdNo:this.supplement.cIdNo,//身份证号码
                    cSex:this.supplement.cSex,//性别
                    cAge:this.supplement.cAge,//年龄
                    cStatus:this.supplement.cStatus,//身份信息
                    cIdentityInfo:this.supplement.cIdentityInfo,//身份详情
                    cEffectMode:this.supplement.cEffectMode,//公示模式
                    cRemark:this.supplement.cRemark2,//备注
                }
                this.$confirm('确定修改？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$api.myApi.moneyHandling.inflowPut(params)
                        .then((res) => {
                            if (res.retCode == '0') {
                                this.$message({
                                    type: 'success',
                                    message: '修改成功!',
                                    duration: 3 * 1000
                                });
                                this.$router.push('/moneyHandling/audit-return');
                            } else {
                                this.$message({
                                    type: 'warning',
                                    message: res.retMsg,
                                    duration: 3 * 1000
                                });
                            }
                        })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消修改'
                    });
                });
            },
        }
    }
</script>

<style lang="scss" scoped>
    .power-wrap{
        margin:10px 0 20px 0;
        .power-con-wrap{
            padding:20px 30px;
        }
    }
</style>
