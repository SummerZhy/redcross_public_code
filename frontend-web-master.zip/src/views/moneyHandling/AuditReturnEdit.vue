<template>
    <div class="main-con">
        <div class="com-operation-div">
            <section class="com-operation-left">
                <div>款项公示退回处理</div>
            </section>
            <section class="com-operation-right">
                <div></div>
            </section>
        </div>
        <el-card class="susp-query-list">
            <el-form label-position="left"
                     label-width="130px"
                     size="mini">
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">审核操作</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <el-col :span="7">
                                <span>{{review.reviewStatus}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核建议：">
                            <el-col :span="7">
                                <span>{{review.reviewSuggest}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">入账信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="款项编码：">
                            <el-col :span="7">
                                <span>{{roleListData.cfundCode}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="日期：">
                            <el-col :span="9">
                                <span>{{roleListData.dEntryDate}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人姓名：">
                            <el-col :span="9">
                                <span>{{roleListData.cdonerName}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="联系方式：">
                            <el-input v-model="roleListData.cdonorPhone"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人银行：">
                            <span>{{roleListData.cbankName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款人银行账户：">
                            <span>{{roleListData.cbankAcco}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款金额：">
                            <span>{{roleListData.ntotalAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="已捐出：">
                            <span>{{roleListData.nusedAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="剩余：">
                            <span>{{roleListData.nremainAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款方式：">
                            <el-select v-model="roleListData.cdonateType" placeholder="请选择">
                                <el-option
                                        v-for="item in fundsSources"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐赠意向">
                            <el-select v-model="roleListData.cisDirect" placeholder="请选择">
                                <el-option
                                        v-for="item in donateAspiration"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="物资分配：">
                            <el-select v-model="roleListData.cdonateDirection" placeholder="请选择">
                                <el-option
                                        v-for="item in donationPurpose"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="处理状态">
                            <span>{{roleListData.chandleStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <span>{{roleListData.cexamineStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="24" >
                        <el-form-item label="备注：">
                            <span>{{roleListData.cremark1}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">补录信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="捐款人姓名：">
                            <el-input v-model="supplement.cdonerName"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份证号：">
                            <el-input v-model="supplement.cidNo"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="性别：">
                            <el-select v-model="supplement.csex" placeholder="请选择">
                                <el-option
                                        v-for="item in sex"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="年龄：">
                            <!--<el-input v-model="supplement.cAge"></el-input>-->
                            <span>{{supplement.cage}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份信息：">
                            <!-- <span>{{supplement.cIdentityInfo}}</span>-->
                            <el-select v-model="supplement.cstatus" placeholder="请选择" @change="showHide">
                                <el-option
                                        v-for="item in identityInfo"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份信息详情：">
                            <!-- <span>{{supplement.cIdentityInfo}}</span>-->
                            <el-select v-model="supplement.cidentityInfo" placeholder="请选择">
                                <el-option
                                        v-for="item in identityInfoDetail"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="公示模式：">
                            <!-- <span>{{supplement.cEffectMode}}</span>-->
                            <el-select v-model="supplement.cidentityInfo" placeholder="请选择">
                                <el-option
                                        v-for="item in checkItem"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="18" >
                        <el-form-item label="备注：">
                            <el-input v-model="supplement.cremark2" type="textarea"
                                      :rows="2"
                                      placeholder="请输入内容"
                            ></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
            </el-form>
        </el-card>
        <section class="com-btn-wrap-center">
            <el-button @click="cancel" size="small">关闭</el-button>
            <el-button @click="changePut" size="small" type="danger">修改</el-button>
        </section>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    export default{
        name: "AuditReturnEdit",
        data(){
            return{
                id:this.$route.query.moneyId,
                roleListData:[],
                supplement:[],
                review:[],
                trueFalse:false
            }
        },
        created(){
            this.getDetails();
        },
        computed:{
            ...mapGetters('dictionary', [
                'manageState',
                'fundsSources',
                'donateAspiration',
                'donationPurpose',
                'sex',
                'identityInfo',
                'identityInfoDetail',
                'checkItem'
            ]),
        },
        methods:{
            //机构详情
            getDetails(){
                let params = {
                    cFundCode:this.id
                    /*cFundCode:'this.id'*/
                }
                this.$api.myApi.moneyHandling.getMoneyDetail(params)
                    .then( res => {
                        if(res.retCode == 0){
                            this.roleListData = res.result.info; //入账信息
                            this.supplement = res.result.supplement;//补录信息
                            this.review = res.result.review;//审核操作
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //关闭
            cancel(){
                this.$router.push('/moneyHandling/moneyHandling-list');
            },
            //修改事件
            changePut() {
                let params = {
                    cfundCode: this.roleListData.cfundCode,//资金编号
                    cdonorPhone:this.roleListData.cdonorPhone,//手机号码
                    cdonateSource:this.roleListData.cdonateType,//捐款方式
                    // cDonateSource:this.roleListData.cDonateSource,//捐款方式
                    cisDirect:this.roleListData.cisDirect,//捐款意向
                    cdonateDirection:this.roleListData.cdonateDirection,//物资分配
                    cdonerName:this.supplement.cdonerName,//捐款人姓名
                    cidNo:this.supplement.cidNo,//身份证号码
                    csex:this.supplement.csex,//性别
                    cage:this.supplement.cage,//年龄
                    cstatus:this.supplement.cstatus,//身份信息
                    cidentityInfo:this.supplement.cidentityInfo,//身份详情
                    ceffectMode:this.supplement.ceffectMode,//公示模式
                    cremark:this.supplement.cremark2,//备注
                }
                this.$confirm('确定修改？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$api.myApi.moneyHandling.inflowPut(params)
                        .then((res) => {
                            if (res.retCode == '0') {
                                this.$message({
                                    type: 'success',
                                    message: '修改成功!',
                                    duration: 3 * 1000
                                });
                                this.$router.push('/moneyHandling/audit-return');
                            } else {
                                this.$message({
                                    type: 'warning',
                                    message: res.retMsg,
                                    duration: 3 * 1000
                                });
                            }
                        })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消修改'
                    });
                });
            },
            //选中个人事件
            showHide(e){
                if(e == 302){
                    this.trueFalse = true
                }else{
                    this.trueFalse = false
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
    .power-wrap{
        margin:10px 0 20px 0;
        .power-con-wrap{
            padding:20px 30px;
        }
    }
</style>
