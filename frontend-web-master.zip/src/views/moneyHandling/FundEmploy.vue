<template>
    <!-- 善款处理-资金使用 -->
    <div>
        <!-- <el-steps :active="active" finish-status="success">
            <el-step title="步骤 1"></el-step>
            <el-step title="步骤 2"></el-step>
            <el-step title="步骤 3"></el-step>
        </el-steps> -->
        <div class="cont-wrap">
            <section class="step0" v-show="active==0">
                <el-form ref="baseForm" :model="formData" :label-width="labelWidth" :rules="rules">
                    <el-form-item label="项目名称" prop="projectName">
                        <el-input v-model="formData.projectName" @change="formValidate"></el-input>
                    </el-form-item>
                    <el-form-item label="目标金额" prop="targetAmount">
                        <el-input v-model="formData.targetAmount" @change="formValidate"></el-input>
                    </el-form-item>
                    <el-form-item label="捐赠方向" prop="donateDirection">
                        <el-select v-model="formData.donateDirection" placeholder="请选择捐赠方向" @change="formValidate">
                            <el-option v-for="item in donationPurpose" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <el-form :label-width="labelWidth">
                    <el-form-item label="捐赠方案">
                        <el-upload
                            ref="upload" 
                            class="upload-demo"
                            action="https://jsonplaceholder.typicode.com/posts/"
                            :before-upload="beforeUpload1"
                            :limit="1"
                            :file-list="fileList1">
                            <el-button size="small" type="primary">点击上传</el-button>
                            <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
                        </el-upload>
                    </el-form-item>
                </el-form>
                <el-form :label-width="labelWidth">
                    <el-form-item label="受捐名单">
                        <a href="/doneeList.xlsx" download="受捐名单.xlsx">模版下载</a>
                        <el-upload
                            ref="import"
                            class="upload-demo"
                            action="qq"
                            :before-upload="beforeUpload2"
                            :limit="1"
                            :file-list="fileList2">
                            <el-button size="small" type="primary">点击上传</el-button>
                            <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
                        </el-upload>
                    </el-form-item>
                </el-form>
                <div class="btn-wrap">
                    <el-button type="danger" @click="next(); countCurrAmount()" :disabled="disabled1">确定</el-button>
                </div>
            </section>
            <section class="step1" v-show="active==1">
                <el-form :label-width="labelWidth">
                    <el-row>
                        <el-col :span="7">
                            <el-form-item label="捐款金额">
                                <el-col :span="11">
                                    <el-input v-model="queryForm.donateAmountMin"></el-input>
                                </el-col>
                                <el-col :span="2" style="text-align:center;">-</el-col>
                                <el-col :span="11">
                                    <el-input v-model="queryForm.donateAmountMax"></el-input>
                                </el-col>
                            </el-form-item>
                            <el-form-item label="入账时间">
                                <el-col :span="11">
                                    <el-date-picker
                                        style="width:100%;"
                                        v-model="queryForm.inAccountTimeStart"
                                        type="date"
                                        placeholder="选择日期">
                                    </el-date-picker>
                                </el-col>
                                <el-col :span="2" style="text-align:center;">-</el-col>
                                <el-col :span="11">
                                    <el-date-picker
                                        style="width:100%;"
                                        v-model="queryForm.inAccountTimeEnd"
                                        type="date"
                                        placeholder="选择日期">
                                    </el-date-picker>
                                </el-col>
                            </el-form-item>
                        </el-col>
                        <el-col :span="7">
                            <el-form-item label="是否定向">
                                <el-select v-model="queryForm.isDirect" placeholder="">
                                    <el-option v-for="item in donateAspiration" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="7">
                            <el-form-item label="捐赠方向">
                                <el-select v-model="queryForm.donateDirection" placeholder="">
                                    <el-option v-for="item in donationPurpose" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="3">
                            <el-button type="danger" @click="getList">搜索</el-button>
                        </el-col>
                    </el-row>
                </el-form>
                <div class="top-flag">
                    <span>目标金额：{{formData.targetAmount}}</span>
                    <span>当前金额：{{currAmount}}</span>
                </div>
                <el-table
                    ref="tableList"
                    :data="tableData"
                    :row-key="getRowKey"
                    @selection-change="handelSelectChange"
                    style="width: 100%">
                    <el-table-column
                        type="selection"
                        reserve-selection
                        width="50">
                    </el-table-column>
                    <el-table-column
                        type="index"
                        width="50"
                        :index="getIndex"
                        label="序号">
                    </el-table-column>
                    <el-table-column
                        prop="MoneyCoding"
                        label="资金编码">
                    </el-table-column>
                    <el-table-column
                        prop="donors"
                        label="捐赠人">
                    </el-table-column>
                    <el-table-column
                        label="捐赠金额">
                        <template slot-scope="scope">
                            <input type="text" 
                            v-model="scope.row.donationAmount" 
                            style="width:100%;border:none;" 
                            @focus="focusGetVal(scope.row.donationAmount)"
                            @blur="blurValidate(scope.row)">
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="idDirect"
                        label="是否定向">
                    </el-table-column>
                    <el-table-column
                        prop="donateDirection"
                        label="捐赠方向">
                    </el-table-column>
                    <el-table-column
                        prop="inAccountTime"
                        label="入账时间">
                    </el-table-column>
                    <el-table-column
                        prop="remark"
                        label="备注">
                    </el-table-column>
                </el-table>
                <el-pagination
                    @size-change="getList"
                    @current-change="getList"
                    :current-page.sync="queryForm.currentPage"
                    :page-sizes="[10, 20,]"
                    :page-size.sync="queryForm.limit"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalNum">
                </el-pagination>
                <div class="btn-wrap">
                    <el-button type="danger" :disabled = "disabled2">确定</el-button>
                    <el-button @click="previous">返回</el-button>
                </div>
            </section>
            <section class="step2" v-show="active==2">
                <el-form :label-width="labelWidth">
                    <el-form-item label="捐款总代码">
                        <p>{{detailData.donateCode}}</p>
                    </el-form-item>
                    <el-form-item label="捐款总金额">
                        <p>{{detailData.donateAmount}}</p>
                    </el-form-item>
                    <el-form-item label="捐赠方向">
                        <p>{{detailData.donateDirection}}</p>
                    </el-form-item>
                    <el-form-item label="捐赠资金详情">
                        <el-table
                            :data="detailData.list"
                            style="width: 100%">
                            <!-- <el-table-column
                                type="index"
                                width="50"
                                :index="getIndex"
                                label="序号">
                            </el-table-column> -->
                            <el-table-column
                                prop="moneyCode"
                                label="资金编码">
                            </el-table-column>
                            <el-table-column
                                prop="donors"
                                label="捐赠人">
                            </el-table-column>
                            <el-table-column
                                prop="money"
                                label="捐赠金额">
                            </el-table-column>
                            <el-table-column
                                prop="isDirection"
                                label="是否定向">
                            </el-table-column>
                            <el-table-column
                                prop="donateDirection"
                                label="捐赠方向">
                            </el-table-column>
                            <el-table-column
                                prop="inAccountTime"
                                label="入账时间">
                            </el-table-column>
                            <el-table-column
                                prop="remark"
                                label="备注">
                            </el-table-column>
                        </el-table>
                    </el-form-item>
                </el-form>
            </section>
        </div>
        

        <!-- <el-button style="margin-top: 12px;" @click="importUpload">下一步</el-button> -->
    </div>
</template>

<script>
import {mapGetters} from 'vuex'
import validator from '@/utils/validator'


export default {
    data(){
        return{
            active: 0,
            labelWidth:'100px',
            formData:{
                projectName:'', //项目名称
                targetAmount:'', //目标金额
                donateDirection:'' //捐赠方向
            },
            rules:{
                projectName: [
                    { required: true, message: '请输入项目名称', trigger: 'blur' },
                ],
                targetAmount:[
                    { required: true, message: '请输入目标金额', trigger: 'blur' },
                    {validator: validator.isNumber, trigger: 'blur'}
                ],
                donateDirection:[
                    { required: true, message: '请选择捐赠方向', trigger: 'blur' },
                ]
            },
            disabled1:true,
            fileList1:[],
            file1:null,
            file1Url:'',
            fileList2:[],
            file2:null,
            doneeList:[],
            queryForm:{
                currentPage:1,
                limit:10,
                donateAmountMin:'', //捐款金额最小值
                donateAmountMax:'', //捐款金额最大值
                isDirect:'', //是否定向code
                donateDirection:'', //捐赠方向code
                inAccountTimeStart:'', //入账时间-开始
                inAccountTimeEnd:'', //入账时间-结束
            },
            tableData:[],
            totalNum:0,
            getRowKey:function(row){
                return row.MoneyCoding
            },
            primaryval:null, //原有的捐赠金额
            currAmount:0, //当前金额
            disabled2:true,
            checkedItem:[], //选中的
            list:[],
            id:'', //新增的项目id
            detailData:{}, //详情
        }
    },
    computed: {
      ...mapGetters('dictionary', [
        'donationPurpose', //善款用途 捐赠方向
        'donateAspiration', //捐赠意愿 是否定向
      ])
    },
    created(){
        this.getList();
        // let w = new Promise()
        // console.log('w', w)
        let a  = function(){
            console.log('a')
            return 'aa'
            // return new Promise ((resolve, reject)=>{
            //     let time = setTimeout(() => {
            //         console.log('a')
                    
            //     }, 100);
            // })
            
        }
        let b  = function(){
            console.log('b')

            return 'bb'
            // return new Promise ((resolve, reject)=>{
            //     let time = setTimeout(() => {
            //         console.log('b')
                    
            //     }, 100);
            // })
        }
        let c = function(n){
            console.log('c', n)
        }
        async function d(){
            let n = await Promise.all([a(), b()])
            c(n)
            // c()
            // console.log('n', n)
            // if(n.length > 0){
            //     c()
            // }
        }
        d();
        
    },
    methods: {
        //下一页
        next() {
            if (this.active++ > 2) this.active = 0;
        },
        //上一页
        previous(){
            this.active--;
        },
        //第一页基本信息表单验证
        formValidate(){
            this.$refs.baseForm.validate( (vali) => {
                console.log(vali);
                this.disabled1 = !vali
            })
        },
        getIndex(index){
            return (this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1 
        },
        //出账列表查询
        getList(){
            this.$api.myApi.moneyHandling.outflowListGet(this.queryForm).then( res => {
                if(res.retCode == 0){
                    this.tableData = res.result.list;
                    this.totalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //获取焦点时 获取原有捐赠金额
        focusGetVal(val){
            this.primaryval = val;
        },
        //失去焦点时 验证
        blurValidate(row){
            if(isNaN(row.donationAmount)){
                this.$alert('捐赠资金只能为数字', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = this.primaryval;
                return false
            }
            
            if(row.donationAmount < 0 || row.donationAmount > this.primaryval){
                this.$alert('捐赠资金只能为正整数且小于原有资金', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = this.primaryval;
                return false
            }
            this.countCurrAmount();
        },
        handelSelectChange(val){
            this.checkedItem = val;
            this.countCurrAmount();
        },
        //计算当前金额 获取新增时需要的参数list 并比较
        countCurrAmount(){
            this.currAmount = 0;
            this.checkedItem.forEach((item, index) => {
                this.currAmount = this.currAmount + Number(item.donationAmount)
            })

            this.list = this.checkedItem.map((item, index) => {
                let org = {
                    moneyCode: item.MoneyCoding,
                    donateAmount: item.donationAmount
                }
                return org;
            })

            if(this.currAmount == this.formData.targetAmount){
                this.disabled2 = false;
            }else{
                this.disabled2 = true;

            }
        },
        //捐赠方案上传
        upload(){
            this.$refs.upload.submit();
            console.log(this.file1);
            if(this.file1){
                //执行上传
                let params = {
                    beneficialsFile: this.file1
                }
                this.$api.myApi.moneyHandling.outflowUploadPost(params).then( res => {
                    if(res.retCode == 0){
                       this.file1Url = res.result.fileUrl;
                    }else{
                        this.$message.error(res.retMsg);
                    }
                })
            }
        },
        //捐赠方案上传之前
        beforeUpload1(file){
            this.file1 = file
        },
        //受捐名单导入
        importUpload(){
            this.$refs.import.submit();
            console.log(this.file2);
            if(this.file2){
                //执行上传
                let params = {
                    beneficialsFile: this.file2
                }
                this.$api.myApi.moneyHandling.outflowImportPost(params).then( res => {
                    if(res.retCode == 0){
                        this.doneeList = res.result.list;
                    }else{
                        this.$message.error(res.retMsg);
                    }
                })
            }
        },
         //受捐名单上传之前
        beforeUpload2(file){
            this.file2 = file
        },
        //资金出账增加
        add(){
            let params = {
                projectName: this.formData.projectName,
                targetAmount: this.formData.targetAmount,
                donateDirection: this.formData.donateDirection,
                donationScheme: this.file1Url,
                list: this.list,
                doneeList: this.doneeList
            }
            this.$api.myApi.moneyHandling.outflowInfoPost(params).then( res => {
                if(res.retCode == 0){
                    this.id = res.result.id;
                    this.$message.success(res.retMsg);
                    this.getDetail();
                    this.next();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //点击第二页的确定 确定新增
        clickAdd(){},
        //资金出账详情
        getDetail(){
            let params = {
                id: this.id
            }
            this.$api.myApi.moneyHandling.outflowInfoGet(params).then( res => {
                if(res.retCode == 0){
                    this.detailData = res.result;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
    .cont-wrap{
        // width:80%;
        // margin:20px auto 0;
    }
    .el-form-item{
        margin-bottom:22px;
    }
    .step0{
        width:80%;
        margin:auto;
    }
    .btn-wrap{
        margin-top:20px;
        text-align:center;
    }
    .top-flag{
        display:flex;
        justify-content: flex-end;
        align-items:center;
        height:40px;
        border-bottom:1px solid #eee;
        span{
            padding:0 10px;
        }
    }
</style>

