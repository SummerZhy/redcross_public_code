<template>
    <!-- 善款处理-资金使用 -->
    <div>
        <div class="cont-wrap">
            <section class="step0" v-show="active==0">
                <el-form ref="baseForm" :model="formData" :label-width="labelWidth" :rules="rules">
                    <el-form-item label="项目名称" prop="projectName">
                        <el-input v-model="formData.projectName" @change="formValidate"></el-input>
                    </el-form-item>
                    <el-form-item label="目标金额" prop="targetAmount">
                        <el-input v-model="formData.targetAmount" @change="formValidate"></el-input>
                    </el-form-item>
                    <el-form-item label="捐赠方向" prop="donateDirection">
                        <el-select v-model="formData.donateDirection" placeholder="请选择捐赠方向" @change="formValidate">
                            <el-option v-for="item in donationPurpose" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <!-- action="https://jsonplaceholder.typicode.com/posts/" -->
                <el-form :label-width="labelWidth">
                    <el-form-item label="捐赠方案">
                        <el-upload
                            ref="upload" 
                            class="upload-demo"
                            action="qq"
                            :auto-upload="false"
                            :before-upload="beforeUpload1"
                            :on-remove="handelRemove1"
                            :limit="1"
                            :file-list="fileList1">
                            <el-button size="small" type="primary">点击上传</el-button>
                            <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
                        </el-upload>
                    </el-form-item>
                </el-form>
                <el-form :label-width="labelWidth">
                    <el-form-item label="受捐名单">
                        <a href="/doneeList.xlsx" download="受捐名单.xlsx">模版下载</a>
                        <el-upload
                            ref="import"
                            class="upload-demo"
                            action="/api/capital/outflow/import"
                            :before-upload="beforeUpload2"
                            :on-success="handelSuccess"
                            :on-remove="handelRemove2"
                            :limit="1"
                            :file-list="fileList2">
                            <el-button size="small" type="primary">点击上传</el-button>
                            <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
                        </el-upload>
                    </el-form-item>
                </el-form>
                <div class="btn-wrap">
                    <el-button type="danger" @click="clickSure" :disabled="disabled1">确定</el-button>
                </div>
            </section>
            <section class="step1" v-show="active==1">
                <el-tabs v-model="activeName" >
                    <el-tab-pane label="手工添加" name="first">
                        <fund-employ-query @searchList="getQueryForm"></fund-employ-query>
                        <div class="top-flag">
                            <span>目标金额：{{formData.targetAmount | money}}</span>
                            <span>当前金额：{{currAmount | money}}</span>
                        </div>
                        <el-table
                            ref="tableList"
                            :data="tableData"
                            :row-key="getRowKey"
                            @selection-change="handelSelectChange"
                            style="width: 100%">
                            <el-table-column
                                type="selection"
                                reserve-selection
                                width="50">
                            </el-table-column>
                            <el-table-column
                                type="index"
                                width="50"
                                :index="getIndex"
                                label="序号">
                            </el-table-column>
                            <el-table-column
                                prop="MoneyCoding"
                                label="资金编码">
                            </el-table-column>
                            <el-table-column
                                prop="donors"
                                label="捐赠人">
                            </el-table-column>
                            <el-table-column
                                label="捐赠金额">
                                <template slot-scope="scope">
                                    <input type="text" 
                                    :value = "scope.row.donationAmount | money"
                                    style="width:100%;border:none;" 
                                    @blur="blurValidate($event, scope.row)">
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="idDirect"
                                label="是否定向">
                            </el-table-column>
                            <el-table-column
                                prop="donateDirection"
                                label="捐赠方向">
                            </el-table-column>
                            <el-table-column
                                prop="inAccountTime"
                                label="入账时间">
                            </el-table-column>
                            <el-table-column
                                prop="remark"
                                label="备注">
                            </el-table-column>
                        </el-table>
                        <el-pagination
                            @size-change="getList"
                            @current-change="getList"
                            :current-page.sync="queryForm.currentPage"
                            :page-sizes="[10, 20,]"
                            :page-size.sync="queryForm.limit"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="totalNum">
                        </el-pagination>
                        <div class="btn-wrap">
                            <el-button type="danger" :disabled = "disabled2" @click="upload">确定</el-button>
                            <el-button @click="previous">返回</el-button>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="智能匹配" name="second">
                        <fund-employ-query @searchList="getQueryFormInte"></fund-employ-query>
                        <div class="top-flag">
                            <span>目标金额：{{formData.targetAmount | money}}</span>
                            <span>当前金额：{{currAmountInte | money}}</span>
                        </div>
                        <el-table
                            ref="tableListInte"
                            :data="tableDataInte"
                            :row-key="getRowKeyInte"
                            style="width: 100%">
                            <!-- <el-table-column
                                type="selection"
                                reserve-selection
                                :checked="true"
                                width="50">
                            </el-table-column> -->
                            <el-table-column
                                width="50"
                                label="选择">
                                <template slot-scope="scope">
                                    <!-- <input name="inteCheckbox" type="checkbox" :value="scope.row.MoneyCoding"> -->
                                    <el-checkbox 
                                        :value="scope.row.MoneyCoding" 
                                        name="inteCheckbox" 
                                        :checked="scope.row.isChecked == 1"
                                        @change="checkedOr($event,scope.row.MoneyCoding)">
                                    </el-checkbox>
                                </template>
                            </el-table-column>
                            <el-table-column
                                type="index"
                                width="50"
                                :index="getIndexInte"
                                label="序号">
                            </el-table-column>
                            <el-table-column
                                prop="MoneyCoding"
                                label="资金编码">
                            </el-table-column>
                            <el-table-column
                                prop="donors"
                                label="捐赠人">
                            </el-table-column>
                            <el-table-column
                                label="捐赠金额">
                                <template slot-scope="scope">
                                    <input type="text" 
                                    :value = "scope.row.donationAmount | money"
                                    style="width:100%;border:none;" 
                                    @blur="blurValidateInte($event, scope.row)">
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="idDirect"
                                label="是否定向">
                            </el-table-column>
                            <el-table-column
                                prop="donateDirection"
                                label="捐赠方向">
                            </el-table-column>
                            <el-table-column
                                prop="inAccountTime"
                                label="入账时间">
                            </el-table-column>
                            <el-table-column
                                prop="remark"
                                label="备注">
                            </el-table-column>
                        </el-table>
                        <el-pagination
                            @size-change="pageInte"
                            @current-change="pageInte"
                            :current-page.sync="pageDataInte.currentPage"
                            :page-sizes="[10, 20,]"
                            :page-size.sync="pageDataInte.limit"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="totalNumInte">
                        </el-pagination>
                        <div class="btn-wrap">
                            <el-button type="danger" :disabled = "disabledInte" @click="upload">确定</el-button>
                            <el-button @click="previous">返回</el-button>
                        </div>
                    </el-tab-pane>
                </el-tabs>
                
            </section>
            <section class="step2" v-show="active==2">
                <el-form :label-width="labelWidth">
                    <el-form-item label="捐款总代码">
                        <p>{{detailData.donateCode}}</p>
                    </el-form-item>
                    <el-form-item label="捐款总金额">
                        <p>{{detailData.donateAmount | money}}</p>
                    </el-form-item>
                    <el-form-item label="捐赠方向">
                        <p>{{detailData.donateDirection}}</p>
                    </el-form-item>
                    <el-form-item label="捐赠资金详情">
                        <el-table
                            :data="detailData.list"
                            style="width: 100%">
                            <el-table-column
                                type="index"
                                width="50"
                                label="序号">
                            </el-table-column>
                            <el-table-column
                                prop="moneyCode"
                                label="资金编码">
                            </el-table-column>
                            <el-table-column
                                prop="donors"
                                label="捐赠人">
                            </el-table-column>
                            <el-table-column
                                label="捐赠金额">
                                <template slot-scope="scope">
                                    <span>{{scope.row.money | money}}</span>
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="isDirection"
                                label="是否定向">
                            </el-table-column>
                            <el-table-column
                                prop="donateDirection"
                                label="捐赠方向">
                            </el-table-column>
                            <el-table-column
                                prop="inAccountTime"
                                label="入账时间">
                            </el-table-column>
                            <el-table-column
                                prop="remark"
                                label="备注">
                            </el-table-column>
                        </el-table>
                    </el-form-item>
                </el-form>
                <div class="btn-wrap">
                    <el-button type='danger' @click="refresh">继续创建</el-button>
                </div>
            </section>
        </div>
        

        <!-- <el-button style="margin-top: 12px;" @click="next">下一步</el-button> -->
    </div>
</template>

<script>
import {mapGetters} from 'vuex'
import validator from '@/utils/validator'
import FundEmployQuery from'@/views/moneyHandling/components/FundEmployQuery.vue'

export default {
    components:{
        FundEmployQuery
    },
    data(){
        return{
            active: 0,
            labelWidth:'100px',
            formData:{
                projectName:'', //项目名称
                targetAmount:'', //目标金额
                donateDirection:'' //捐赠方向
            },
            rules:{
                projectName: [
                    { required: true, message: '请输入项目名称', trigger: 'blur' },
                ],
                targetAmount:[
                    { required: true, message: '请输入目标金额', trigger: 'blur' },
                    {validator: validator.isNumber, trigger: 'blur'}
                ],
                donateDirection:[
                    { required: true, message: '请选择捐赠方向', trigger: 'blur' },
                ]
            },
            disabled1:true,
            fileList1:[],
            file1:null,
            file1Url:'',
            fileList2:[],
            file2:null,
            doneeList:[],
            queryForm:{}, //手工添加中的-搜索条件
            tableData:[], //手工添加中的-列表数据
            totalNum:0, //手工添加中的-数据总量
            getRowKey:function(row){
                return row.MoneyCoding
            },
            currAmount:0, //手工添加中的-当前选中金额
            disabled2:true,
            checkedItem:[], //手工添加中的-选中的
            list:[],
            id:'', //新增的项目id
            detailData:{}, //详情
            editMoney:{}, //手工添加中 用来存放修改过金额的数据 的变量
            activeName:'first', //tab初始化

            queryFormInte:{}, //智能匹配中的-搜索条件
            pageDataInte:{
                currentPage:1,
                limit:10
            }, //分页
            tableDataInte:[], //智能匹配中的-列表数据
            totalNumInte:0, //智能匹配中的-数据总量
            currAmountInte:0, //智能匹配中的-当前选中金额
            getRowKeyInte:function(row){
                return row.MoneyCoding
            },
            disabledInte:true,
        }
    },
    computed: {
      ...mapGetters('dictionary', [
        'donationPurpose', //善款用途 捐赠方向
        'donateAspiration', //捐赠意愿 是否定向
      ])
    },
    created(){
        // this.getList();
    },
    methods: {
        //下一页
        next() {
            if (this.active++ > 2) this.active = 0;
        },
        //上一页
        previous(){
            this.active--;
        },

        /*step1*/
        //第一页基本信息表单验证
        formValidate(){
            this.$refs.baseForm.validate( (vali) => {
                // this.disabled1 = !vali
                if(vali && this.doneeList.length > 0){
                    this.disabled1 = false;
                }else{
                    this.disabled1 = true;
                }
            })
        },
        //第一页点击确定
        clickSure(){
            let doneeTotleMoney = 0;
            this.doneeList.forEach(item => {
                doneeTotleMoney = doneeTotleMoney + Number(item.amount)
            })
            if(doneeTotleMoney == this.formData.targetAmount){
                this.next(); 
                this.countCurrAmount();
            }else{
                this.$alert('目标金额需与受捐名单中的总金额相等', '提示', {
                    confirmButtonText: '确定',
                });
            }
        },
        //捐赠方案上传
        upload(){
            this.$refs.upload.submit();
            if(this.file1){
                //执行上传
                let formdata = new FormData();
                formdata.append('beneficialsFile', this.file1)
                this.$api.myApi.moneyHandling.outflowUploadPost(formdata).then( res => {
                    if(res.retCode == 0){
                       this.file1Url = res.result.fileUrl;
                       if(this.activeName == 'first'){
                           //手工添加
                            this.add();
                       }else{
                           //智能匹配
                           this.addInte();
                       }
                    }else{
                        this.$message.error(res.retMsg);
                    }
                })
            }else{
                if(this.activeName == 'first'){
                 //手工添加
                    this.add();
                }else{
                    //智能匹配
                    this.addInte();
                }          
            }
        },
        //捐赠方案上传之前
        beforeUpload1(file){
            this.file1 = file
        },
        //移除捐赠方案
        handelRemove1(){
            this.file1 = null;
        },
         //受捐名单上传之前
        beforeUpload2(file){
            this.file2 = file
        },
        //受赠名单导入成功
        handelSuccess(res){
            if(res.result.list && res.result.list.length > 0){
                this.doneeList = res.result.list;
            }else{
                this.doneeList = [];
            }
            this.formValidate();
        },
        //移除受赠名单时
        handelRemove2(){
            this.file2 = null;
            this.doneeList = [];
            this.formValidate();
        },
        
        
        /*step2-手工新增*/
        getQueryForm(val){
            // console.log('val', val);
            this.queryForm = val;
            this.getList();
        },
        getIndex(index){
            return (this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1 
        },
        //出账列表查询
        getList(){
            this.$api.myApi.moneyHandling.outflowListGet(this.queryForm).then( res => {
                if(res.retCode == 0){
                    this.tableData = res.result.list;
                    if(this.editMoney){
                        this.tableData.forEach((item) => {
                            for (var k in this.editMoney){
                                if(item.MoneyCoding = k){
                                    item.donationAmount = this.editMoney[k].split(',').join('');
                                }
                            }
                        })
                    }
                    this.totalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //失去焦点时 验证
        blurValidate(e, row){
            // console.log(e);
            row.donationAmount = e.target.value.split(',').join('');
            if(row.donationAmount == ''){
                this.$alert('捐赠资金不能为空', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }

            if(isNaN(row.donationAmount)){
                this.$alert('捐赠资金只能为数字', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }
            
            if(row.donationAmount < 0 || row.donationAmount == 0 || row.donationAmount > row.donationAmountCopy){
                this.$alert('捐赠资金只能为正整数且小于原有资金', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }
            this.setEditMoney(row);
            this.countCurrAmount();
        },
        handelSelectChange(val){
            this.checkedItem = val;
            this.countCurrAmount();
        },
        //修改金额后 把修改过的项放到sessionStora里
        setEditMoney(row){
            if(!this.editMoney[row.MoneyCoding]){
                this.editMoney[row.MoneyCoding] = row.donationAmount
            }
            console.log(this.editMoney[row.MoneyCoding])
            console.log(this.editMoney)
            
            // sessionStorage.setItem('editMoney', this.editMoney.toString());
        },
        //计算当前金额 获取新增时需要的参数list 并比较
        countCurrAmount(){
            this.currAmount = 0;
            this.checkedItem.forEach((item, index) => {
                this.currAmount = this.currAmount + Number(item.donationAmount)
            })

            this.list = this.checkedItem.map((item, index) => {
                let org = {
                    moneyCode: item.MoneyCoding,
                    donateAmount: item.donationAmount
                }
                return org;
            })

            if(this.currAmount == this.formData.targetAmount){
                this.disabled2 = false;
            }else{
                this.disabled2 = true;

            }
        },
        //资金出账增加
        add(){
            let params = {
                projectName: this.formData.projectName,
                targetAmount: this.formData.targetAmount,
                donateDirection: this.formData.donateDirection,
                donationScheme: this.file1Url,
                list: this.list,
                doneeList: this.doneeList
            }
            this.$api.myApi.moneyHandling.outflowInfoPost(params).then( res => {
                if(res.retCode == 0){
                    this.id = res.result.id;
                    this.$message.success(res.retMsg);
                    this.getDetail();
                    this.next();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },

        /*step2-智能匹配*/
        getQueryFormInte(val){
            this.queryFormInte = val;
            this.getListInte();
        },
        getIndexInte(index){
            return (this.pageDataInte.currentPage - 1) * this.pageDataInte.limit + index + 1 
        },
        //出账列表查询-智能匹配（清空临时表-插入数据）
        getListInte(){
            this.queryFormInte.targetAmount = this.formData.targetAmount
            this.$api.myApi.moneyHandling.intelligentListGet(this.queryFormInte).then( res => {
                if(res.retCode == 0){
                    this.pageDataInte.currentPage = 1;
                    this.pageInte();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //资金出账列表_智能匹配_分页（单纯对临时表分页）
        pageInte(){
            this.$api.myApi.moneyHandling.intelligentListPageGet(this.pageDataInte).then( res => {
                if(res.retCode == 0){
                    this.tableDataInte = res.result.list;
                    this.totalNumInte = res.result.totalNum;
                    this.currAmountInte = res.result.currCheckedMoney;
                    this.vsAmount();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //失去焦点时 验证
        blurValidateInte(e, row){
            // console.log(e);
            row.donationAmount = e.target.value.split(',').join('');
            if(row.donationAmount == ''){
                this.$alert('捐赠资金不能为空', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }

            if(isNaN(row.donationAmount)){
                this.$alert('捐赠资金只能为数字', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }
            
            if(row.donationAmount < 0 || row.donationAmount == 0 || row.donationAmount > row.donationAmountCopy){
                this.$alert('捐赠资金只能为正整数且小于原有资金', '提示', {
                    confirmButtonText: '确定',
                });
                row.donationAmount = row.donationAmountCopy;
                return false
            }

            this.putEditMoney(row);
            // this.setEditMoney(row);
            // this.countCurrAmount();
        },
        //失去焦点时 调取修改金额接口
        putEditMoney(row){
            console.log('money',row.donationAmount)
            let params = {
                MoneyCoding:row.MoneyCoding,
                money:row.donationAmount
            }
            this.$api.myApi.moneyHandling.moneyPut(params).then( res => {
                if(res.retCode == 0){
                    console.log('金额修改成功');
                    this.pageInte();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //选中和取消选中
        checkedOr(val, MoneyCoding){
            console.log('val', val, MoneyCoding)
            let isChecked = '';
            if(val){
                //选中
                isChecked = '1'
            }else{
                //未选中
                isChecked = '0'
            }
            let params = {
                MoneyCoding: MoneyCoding,
                isChecked: isChecked
            }
            this.$api.myApi.moneyHandling.statusPut(params).then( res => {
                if(res.retCode == 0){
                    console.log('选中修改成功');
                    this.pageInte();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //比较当前金额与目标金额
        vsAmount(){
            if(this.formData.targetAmount == this.currAmountInte){
                this.disabledInte = false;
            }else{
                this.disabledInte = true;
            }
        },
        //资金出账-智能匹配-增加
        addInte(){
            let params = {
                projectName: this.formData.projectName,
                targetAmount: this.formData.targetAmount,
                donateDirection: this.formData.donateDirection,
                donationScheme: this.file1Url,
                doneeList: this.doneeList
            }
            this.$api.myApi.moneyHandling.intelligentInfoPost(params).then( res => {
                if(res.retCode == 0){
                    this.id = res.result.id;
                    this.$message.success(res.retMsg);
                    this.getDetail();
                    this.next();
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },

        /*step3*/
        //资金出账详情
        getDetail(){
            let params = {
                id: this.id
            }
            this.$api.myApi.moneyHandling.outflowInfoGet(params).then( res => {
                if(res.retCode == 0){
                    this.detailData = res.result;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //刷新页面
        refresh(){
            location.reload()
        }
    }
}
</script>

<style lang="scss" scoped>
    .cont-wrap{
        // width:80%;
        // margin:20px auto 0;
    }
    .el-form-item{
        margin-bottom:22px;
    }
    .step0{
        width:80%;
        margin:auto;
    }
    .btn-wrap{
        margin-top:20px;
        text-align:center;
    }
    .top-flag{
        display:flex;
        justify-content: flex-end;
        align-items:center;
        height:40px;
        border-bottom:1px solid #eee;
        span{
            padding:0 10px;
        }
    }
</style>

