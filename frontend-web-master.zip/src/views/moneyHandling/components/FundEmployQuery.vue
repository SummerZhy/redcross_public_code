<template>
	<!-- 资金使用-出账列表-搜索条件 -->
	<el-form :label-width="labelWidth">
		<el-row>
			<el-col :span="10">
				<el-form-item label="捐款金额">
					<el-col :span="11">
						<el-input type="number" v-model="queryForm.donateAmountMin" clearable @blur="moneyValid('min')"></el-input>
					</el-col>
					<el-col :span="2" style="text-align:center;">-</el-col>
					<el-col :span="11">
						<el-input type="number" v-model="queryForm.donateAmountMax" clearable @blur="moneyValid('max')"></el-input>
					</el-col>
				</el-form-item>  
			</el-col>
			<el-col :span="10">
				<el-form-item label="入账时间">
					<el-col :span="11">
						<el-date-picker
							clearable
							style="width:100%;"
							v-model="queryForm.inAccountTimeStart"
							@blur="timeValid('start')"
							type="date"
							value-format="yyyy-MM-dd"
							placeholder="选择日期">
						</el-date-picker>
					</el-col>
					<el-col :span="2" style="text-align:center;">-</el-col>
					<el-col :span="11">
						<el-date-picker
							clearable
							style="width:100%;"
							v-model="queryForm.inAccountTimeEnd"
							@blur="timeValid('end')"
							type="date"
							value-format="yyyy-MM-dd"
							placeholder="选择日期">
						</el-date-picker>
					</el-col>
				</el-form-item>    
			</el-col>
			<el-col :span="4" style="text-align:right;">
				<el-button type="danger" @click="clickSearch">搜索</el-button>
			</el-col>
		</el-row>
		<el-row>
			<el-col :span="10">
				<!-- 定向：00  非定向：01 -->
				<el-form-item label="是否定向">
					<el-select v-model="queryForm.isDirect" 
						@change="chageIsDirect" 
						placeholder="" 
						clearable 
						style="width:100%;">
						<el-option v-for="item in donateAspiration" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
					</el-select>
				</el-form-item>
			</el-col>
			<el-col :span="10" v-show="queryForm.isDirect == '00'">
				<el-form-item label="捐赠方向">
					<el-select v-model="queryForm.donateDirection" 
						multiple 
						placeholder="" 
						clearable 
						style="width:100%;">
						<el-option v-for="item in donationPurpose" :key="item.paramId" :label="item.paramName" :value="item.paramId"></el-option>
					</el-select>
				</el-form-item>
			</el-col>
		</el-row>
	</el-form>
</template>

<script>
import {mapGetters} from 'vuex'

export default {
	data(){
		return{
			labelWidth:'100px',
			queryForm:{
                currentPage:1,
                limit:10,
                donateAmountMin:'', //捐款金额最小值
                donateAmountMax:'', //捐款金额最大值
                isDirect:'', //是否定向code
                donateDirection:[], //捐赠方向code
                inAccountTimeStart:'', //入账时间-开始
                inAccountTimeEnd:'', //入账时间-结束
            },
		}
	},
	computed: {
      ...mapGetters('dictionary', [
        'donationPurpose', //善款用途 捐赠方向
        'donateAspiration', //捐赠意愿 是否定向
      ])
	},
	methods:{
		//验证搜索条件 金额 
        moneyValid(param){
            if(this.queryForm.donateAmountMin && this.queryForm.donateAmountMax && this.queryForm.donateAmountMin > this.queryForm.donateAmountMax){
                this.$alert('捐款金额最小值不能大于捐款金额最大值', '提示', {
                    confirmButtonText: '确定',
                });
                if(param == 'min'){
                    this.queryForm.donateAmountMin = '';
                }else{
                    this.queryForm.donateAmountMax = '';
                }
            }
        },
        //验证搜索条件 时间
        timeValid(param){
            let start = new Date(this.queryForm.inAccountTimeStart).getTime();
            let end = new Date(this.queryForm.inAccountTimeEnd).getTime();
            if(start && end && start > end){
                this.$alert('入账时间开始值必须小于入账时间结束值', '提示', {
                    confirmButtonText: '确定',
                });
                if(param == 'start'){
                    this.queryForm.inAccountTimeStart = '';
                }else{
                    this.queryForm.inAccountTimeEnd = '';
                }
            }
        },
		chageIsDirect(){
			if(this.queryForm.isDirect == '01'){
				this.queryForm.donateDirection = [];
			}
		},
		clickSearch(){
			this.queryForm.donateDirection = this.queryForm.donateDirection.toString();
			this.$emit('searchList', this.queryForm)
		}
	}
}
</script>

<style lang="scss">

</style>