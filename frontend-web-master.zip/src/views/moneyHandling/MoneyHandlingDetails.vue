<template>
    <div class="main-con">
        <div class="com-operation-div">
            <section class="com-operation-left">
                <div>入账详情</div>
            </section>
            <section class="com-operation-right">
                <div></div>
            </section>
        </div>
        <el-card class="susp-query-list">
            <el-form size="small">
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">入账信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="款项编码：">
                            <el-col :span="7">
                                <span>{{roleListData.cFundCode}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="日期：">
                            <el-col :span="9">
                                <span>{{roleListData.dEntryDate}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人姓名：">
                            <el-col :span="9">
                                <span>{{roleListData.cDonerName}}</span>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="联系方式：">
                            <span>{{roleListData.cDonorPhone}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人银行：">
                            <span>{{roleListData.cBankName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款人银行账户：">
                            <span>{{roleListData.cBankAcco}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款金额：">
                            <span>{{roleListData.nTotalAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="已捐出：">
                            <span>{{roleListData.nUsedAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="剩余：">
                            <span>{{roleListData.nRemainAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" v-if="roleListData.type != 2">
                        <el-form-item label="捐款方式：">
                            <span>{{roleListData.cDonateType}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                      <el-form-item label="捐赠意向">
                        <span>{{roleListData.cIsDirect}}</span>
                      </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="物资分配：">
                            <span>{{roleListData.cDonateDirection}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="处理状态">
                            <span>{{roleListData.cHandleStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <span>{{roleListData.cExamineStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{roleListData.cRemark1}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">补录信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="捐款人姓名：">
                            <span>{{supplement.cDonerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份证号：">
                            <span>{{supplement.cIdNo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="性别：">
                            <span>{{supplement.cSex}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="年龄：">
                            <span>{{supplement.cAge}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="职业：">
                            <span>{{supplement.cIdentityInfo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="公示模式：">
                            <span>{{supplement.cEffectMode}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{supplement.cRemark2}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 15px">使用情况</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="16" >
                        <el-form-item label="捐给项目：" v-for="(i,index) in Situation">
                            <p>{{i.cOutDate}}{{i.cAmount}}{{i.cIsDirect}}</p>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">流程跟踪</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="16" >
                        <div class="block" v-for="(i,index) in activiti.activitiList">
                            <div>
                                <div style="margin: 15px 0 15px 0">{{i.cdDoneeName}}</div>
                                <el-timeline>
                                    <el-timeline-item
                                            v-for="(activity, index) in i.donerStatus"
                                            :key="index"
                                            :icon="icon"
                                            :type="type"
                                            >
                                        {{activity.planDoner}}
                                    </el-timeline-item>
                                </el-timeline>
                            </div>
                        </div>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">捐款人评价</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="16" >
                        <div class="block">
                            <el-rate
                                    v-model="donerEvaluation.cScore"
                                    disabled
                                    show-score
                                    text-color="#ff9900"
                                    score-template="{value}">
                            </el-rate>
                            <span class="demonstration">{{donerEvaluation.cEvaluation}}</span>
                        </div>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">受捐人感谢</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="16" >
                        <div class="block">
                            <ul v-for="(i,index) in doneeEvaluation.doneeList">
                                <li style="margin: 15px">
                                    <p>
                                        <i>{{index+1}}.</i>
                                        <span class="demonstration">{{i.cEvaluation}}</span>
                                        <el-rate
                                            v-model="i.cScore"
                                            disabled
                                            show-score
                                            text-color="#ff9900"
                                            score-template="{value}">
                                    </el-rate></p>
                                </li>
                            </ul>
                        </div>
                    </el-col>
                </el-row>
            </el-form>
        </el-card>
        <section class="com-btn-wrap-center">
            <el-button @click="cancel" size="small">关闭</el-button>
        </section>
    </div>
</template>

<script>
    export default{
        name: "MoneyHandlingDetails",
        data(){
            return{
                id:this.$route.query.moneyId,
                roleListData:[],
                supplement:[],
                Situation:[],
                donerEvaluation:[],
                doneeEvaluation:[],
                activiti:[],
                review:[],
                icon: 'el-icon-more',
                type:'primary'
            }
        },
        created(){
            this.getDetails();
        },
        methods:{
            //详情
            getDetails(){
                let params = {
                    /*id:this.id*/
                    id:'this.id'
                }
                this.$api.myApi.moneyHandling.getMoneyDetail(params)
                    .then( res => {
                        if(res.retCode == 0){
                            this.roleListData = res.result.info; //入账信息
                            this.supplement = res.result.supplement;//补录信息
                            this.Situation = res.result.Situation.list;//使用情况
                            this.donerEvaluation = res.result.donerEvaluation;//捐款人评价
                            this.doneeEvaluation = res.result.doneeEvaluation;//受捐人评价
                            this.activiti = res.result.activiti;//流程跟踪
                            this.review = res.result.review;//审核操作
                            /*this.value = this.donerEvaluation.cEvaluation*/
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //关闭
            cancel(){
                this.$router.push('/moneyHandling/moneyHandling-list');
            },
        }
    }
</script>

<style lang="scss" scoped>
    .power-wrap{
        margin:10px 0 20px 0;
        .power-con-wrap{
            padding:20px 30px;
        }
    }
</style>
