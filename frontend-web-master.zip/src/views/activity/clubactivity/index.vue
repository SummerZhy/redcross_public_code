<template>
    <div>
        <el-form class="query-form" ref="form" :model="queryForm" label-width="100px">
            <el-row>
                <el-col :span="7">
                    <el-form-item label="社团活动名称">
                        <el-input v-model="queryForm.activityName"></el-input>
                    </el-form-item>
                    <el-form-item label="活动状态">
                        <el-select v-model="queryForm.status" placeholder="请选择活动状态" class="input-width">
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>
                    <!-- <el-form-item label="报名结束时间">
                        <el-date-picker
                            class="input-width"
                            v-model="queryForm.signUpEndTime"
                            type="datetime"
                            placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item> -->
                    <el-form-item label="报名结束时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.signUpEndTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                </el-col>
                <el-col :span="7">  
                    <el-form-item label="所属社团">
                        <el-input v-model="queryForm.leagueName"></el-input>
                    </el-form-item>
                    <el-form-item label="活动负责人">
                        <el-input v-model="queryForm.responsibilityName"></el-input>
                    </el-form-item>
                    <!-- <el-form-item label="活动开始时间">
                        <el-date-picker
                            class="input-width"
                            v-model="queryForm.activityStartTime"
                            type="datetime"
                            placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item> -->
                    <el-form-item label="活动开始时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityStartTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                </el-col>
                <el-col :span="7">  
                    <el-form-item label="社团类型">
                        <el-select v-model="queryForm.leagueType" placeholder="请选择社团类型" class="input-width"> 
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>
                    <!-- <el-form-item label="报名开始时间">
                        <el-date-picker
                            class="input-width"
                            v-model="queryForm.signUpStartTime"
                            type="datetime"
                            placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item> -->
                    <el-form-item label="报名开始时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.signUpStartTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item>                   
                    <!-- <el-form-item label="活动结束时间">
                        <el-date-picker
                            class="input-width"
                            v-model="queryForm.activityEndTime"
                            type="datetime"
                            placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item> -->
                    <el-form-item label="活动结束时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityEndTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                </el-col>
                <el-col :span="3">
                    <div class="query-btn">
                        <el-button @click="queryForm.currentPage = 1; getList()" type="danger">查询</el-button>                       
                    </div>
                    <div class="query-btn">
                        <el-button @click="reset">重置</el-button>
                    </div>
                </el-col>
            </el-row>
        </el-form>
        <div class="main-con">
            <title-operation title="社团活动列表">
                <el-button type="danger" @click=" isEdit=false;dialogVisible=true">新增</el-button>
                <el-button @click="clickEdit">修改</el-button>
                <el-button @click="onekeyRelease">一键发布</el-button>
                <el-button @click="delClubActivity">删除</el-button>
            </title-operation>
            <div class="content">
                <el-table
                    border
                    :header-cell-style="tableHeadColor"
                    :data="tableData"
                    style="width: 100%"
                    :row-key='getRowKey' 
                    @selection-change="handleSelectionChange">
                    <el-table-column
                        type="selection"
                        reserve-selection
                        width="55">
                    </el-table-column>
                    <el-table-column
                        type="index"
                        :index="getIndex"
                        label="序号"
                        width="55">
                        <!-- <template >{{ getIndex() }}</template> -->
                    </el-table-column>
                    <el-table-column
                        label="社团活动名称">
                        <el-button slot-scope="scope" @click="detailClubActivity(scope.row)" type="text" size="small">{{ scope.row.activityName }}</el-button>
                    </el-table-column>
                    <el-table-column
                        label="报名人数">
                       <el-button slot-scope="scope" @click="SignUpClubActivity(scope.row)" type="text" size="small">{{ scope.row.signUpCount }}</el-button>
                    </el-table-column>
                    <el-table-column
                        label="参加人数">
                       <el-button slot-scope="scope" @click="participantsClubActivity(scope.row)" type="text" size="small">{{ scope.row.signUpCount }}</el-button>                     
                    </el-table-column>
                    <el-table-column
                        prop="leagueName"
                        label="所属社团">
                    </el-table-column>
                    <el-table-column
                        prop="leagueType"
                        label="社团类型">
                    </el-table-column>
                    <el-table-column
                        label="活动负责人">
                        <template slot-scope="scope">{{ scope.row.signUpCount }}</template>
                    </el-table-column>
                    <el-table-column
                        prop="status"
                        label="活动状态">
                    </el-table-column>
                    <el-table-column
                        label="活动二维码">
                         <el-button slot-scope="scope"  @click="codeDialog = true;"  type="text" size="small">活动二维码</el-button>
                        <!-- <template><span @click="codeDialog = true;">活动二维码</span></template> -->
                    </el-table-column>
                    <el-table-column
                        prop="signUpStartTimeStr"
                        label="报名开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="signUpEndTimeStr"
                        label="报名结束时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityStartTimeStr"
                        label="活动开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityEndTimeStr"
                        label="活动结束时间">
                    </el-table-column>
                    <el-table-column
                        prop="signInStartTimeStr"
                        label="签到开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="signInEndTimeStr"
                        label="签到结束时间">
                    </el-table-column>
                    <el-table-column
                        label="操作人">
                        <template slot-scope="scope">{{ scope.row.operateUserName +  scope.row.operateUserCheckNo}}</template>
                    </el-table-column>
                    <el-table-column
                        prop="operateTimeStr"
                        label="操作时间">
                    </el-table-column>
                </el-table>
            </div>
            <div class="paginator">
                <el-pagination
                    background
                    :current-page.sync="queryForm.currentPage"
                    :page-sizes="[10, 20, 50, 100]"
                    :page-size.sync="queryForm.limit"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalNumber"
                    @current-change="getList"
                    @size-change="getList">
                </el-pagination>
            </div>
        </div>
        <!-- 新增弹窗 -->
        <el-dialog
            :title="isTitle"
            :visible.sync="dialogVisible"
            width="80%"
            :before-close="handleClose">
            <el-form  :model="dialogForm" :rules="rules" ref="ruleForm"  label-width="120px">
                    <el-row>
                    <el-col :span="11">
                        <el-form-item label="社团活动名称" prop="activityName">
                            <el-input v-model="dialogForm.activityName"></el-input>
                        </el-form-item>
                        <el-form-item label="社团类型" prop="leagueType">
                            <el-select v-model="dialogForm.leagueType" placeholder="请选择社团类型" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item>                       
                        <el-form-item label="活动时间" prop="activityTimeStr">
                            <el-date-picker
                                class="input-width"
                                v-model="dialogForm.activityTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        <el-form-item label="活动负责人" prop="checkNosText">
                            <el-input v-model="dialogForm.checkNosText" suffix-icon="el-icon-s-custom" @focus="showMember=true"></el-input>
                        </el-form-item>
                        <el-form-item label="活动地址" prop="activityAdress">
                            <el-input v-model="dialogForm.activityAdress"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span='11'>
                        <el-form-item label="所属社团" prop="leagueId">
                            <el-select v-model="dialogForm.leagueId" placeholder="请选择所属社团" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item>
                        
                        <el-form-item label="报名时间" prop="signUpTimeStr">
                            <el-date-picker
                            class="input-width"
                                v-model="dialogForm.signUpTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        
                        <el-form-item label="签到时间" prop="signInTimeStr">
                            <el-date-picker
                            class="input-width"
                                v-model="dialogForm.signInTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item label="负责人联系方式" prop="responsibilityUserPhone">
                            <el-input v-model="dialogForm.responsibilityUserPhone"></el-input>
                        </el-form-item>
                        <el-form-item label="活动人数要求" prop="minPerson">
                            <el-col :span="11">
                                <el-input v-model="dialogForm.minPerson"></el-input>
                            </el-col>
                            <el-col class="line" :span="2" style='text-align:center;'>-</el-col>
                            <el-col :span="11">
                                <el-input ref="maxPerson" v-model="dialogForm.maxPerson"></el-input>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <div class="flex-wrap">
                            <label for="">活动封面图</label>
                            <el-upload
                                class="upload-demo"
                                action="https://jsonplaceholder.typicode.com/posts/"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                :before-remove="beforeRemove"
                                :limit="1"
                                :on-exceed="handleExceed"
                                :file-list="fileList">
                                <el-button size="small" type="primary">点击上传</el-button>
                                <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过1M</div>
                            </el-upload>
                        </div>
                        <div class="flex-wrap">
                            <label for="">活动介绍</label>
                            <editor 
                            class="editor-wrap"
                            ref="editor"
                            :initCont="dialogForm.activityIntroduction"
                            @getHtml="getHtml"></editor>
                        </div>
                    </el-col>
                </el-row>                
            </el-form>
            <div class="dialog-footer-center">
                <el-button type="danger" @click="handleRelease('ruleForm',1)">发 布</el-button>
                <el-button @click="handleRelease('ruleForm',2)">保 存</el-button>
                <el-button @click="calcel">取 消</el-button>
            </div>
        </el-dialog>
        <!-- 活动详情 -->
         <el-dialog
            title="活动详情"
            :visible.sync="detailVisible"
            width="80%"
            >
            <el-form :model="detailForm" label-width="120px"  :disabled="true">
                <el-row>
                    <el-col :span="11">
                        <el-form-item label="社团活动名称">
                            <el-input v-model="detailForm.activityName"></el-input>
                        </el-form-item>
                        <el-form-item label="社团类型">
                            <el-select v-model="detailForm.leagueType" placeholder="请选择社团类型" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item>                       
                        <el-form-item label="活动时间">
                            <el-date-picker
                                class="input-width"
                                v-model="detailForm.activityTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        <el-form-item label="活动负责人">
                            <el-input v-model="detailForm.responsibilityText" suffix-icon="el-icon-s-custom" ></el-input>
                        </el-form-item>
                        <el-form-item label="活动地址">
                            <el-input v-model="detailForm.activityAdress"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span='11'>
                        <el-form-item label="所属社团">
                            <el-select v-model="detailForm.leagueId" placeholder="请选择所属社团" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item>
                        
                        <el-form-item label="报名时间">
                            <el-date-picker
                            class="input-width"
                                v-model="detailForm.signUpTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        
                        <el-form-item label="签到时间">
                            <el-date-picker
                            class="input-width"
                                v-model="detailForm.signInTimeStr"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item label="负责人联系方式">
                            <el-input v-model="detailForm.responsibilityUserPhone"></el-input>
                        </el-form-item>
                        <el-form-item label="活动人数要求">
                            <el-col :span="11">
                                <el-input v-model="detailForm.minPerson"></el-input>
                            </el-col>
                            <el-col class="line" :span="2" style='text-align:center;'>-</el-col>
                            <el-col :span="11">
                                <el-input v-model="detailForm.maxPerson"></el-input>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <div class="flex-wrap">
                            <label for="">活动封面图</label>
                             <!-- <el-upload
                                class="upload-demo"
                                action="https://jsonplaceholder.typicode.com/posts/"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                :before-remove="beforeRemove"
                                :limit="1"
                                :on-exceed="handleExceed"
                                :file-list="fileList">
                                <el-button size="small" type="primary">点击上传</el-button>
                                <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过1M</div>
                            </el-upload> -->
                            <el-image
                                style="width: 300px; height: 200px"
                                :src="detailForm.activityPiciture"
                                fit="cover">
                            </el-image>
                        </div>
                    </el-col>
                </el-row>  
                 <el-row>
                      <el-col :span="24" >
                        <div class="flex-wrap">
                            <!-- <label for="" >活动介绍</label> -->
                                <!-- <editor 
                                class="editor-wrap"
                                :initCont="detailForm.activityIntroduction"
                            ></editor> -->
                           <el-form-item label="活动介绍" style="width:92%">
                                <el-input
                                    type="textarea"
                                    v-model="detailForm.activityIntroduction"
                                    rows="6"
                                    show-word-limit
                                    resize="none"
                                    >
                                </el-input>
                           </el-form-item >
                        </div>
                    </el-col>
                </el-row>                
            </el-form>
            <div class="dialog-footer-center">
                <el-button @click="detailVisible = false">关 闭</el-button>
            </div>
        </el-dialog>
        <!-- 二维码弹窗 -->
        <el-dialog 
            title="活动二维码"
            :visible.sync="codeDialog"
            width="300px"
            @opened="checkCode">
            <div id="qrcode">
                <canvas id="codeCanvas"></canvas>
                <a :href="codeImgUrl" :download="codeImgName">下载</a>
            </div>
        </el-dialog>
        <!-- 工会会员 -->
        <member-list v-model="showMember" @getMembers="getCheckNos"></member-list>
         <!-- 报名人员 -->
        <sign-up v-model="showSignUp" :queryid="queryid" ></sign-up>
         <!-- 参加人员 -->
         <participants  v-model="showParticipants" :queryid="queryid" ></participants>
    </div>
</template>



<script>

import QRCode from 'qrcode' 
import Editor from '@/views/activity/components/Editor.vue'
import MemberList from '@/views/activity/components/MemberList.vue'
import SignUp from '@/views/activity/components/SignUp.vue'
import Participants from '@/views/activity/components/Participants.vue'



export default {
    data(){
        // 验证规则
        var checkOvertime = (rule, value, callback) => {
        let maxPerson = this.$refs.maxPerson.value;
        if (value && maxPerson) {
            callback()
        } else {
            if (!value) {
            callback(new Error('请输入最小人数'))
            }
            if (!maxPerson) {
            callback(new Error('请输入最大人数'))
            }
        }
        }

        return{
            // checkOvertime,
            tableHeadColor:{
                backgroundColor:'#f5f7fa'
            },
            publicPath: process.env.BASE_URL,
            isEdit:false,//点击的是否是修改
            detailForm:{
                activityName: "",//社团活动名称
                minPerson: 1,//活动人数要求最小值
                activityAdress: "",//活动地址
                responsibilityUserPhone: "",//负责人联系方式
                activityEndTimeStr: "",//活动结束时间
                activityStartTimeStr: "",//活动开始时间
                signUpEndTimeStr: "",//报名结束时间
                signUpStartTimeStr: "",//报名开始时间
                activityPiciture: "",//活动封面图url
                maxPerson: 2,//活动人数要求最大值
                activityIntroduction: "",//
                leagueId: "",//所属社团id
                leagueType: "",//社团类型code
                id: "",//id
                signInEndTimeStr: "",//签到结束时间
                signInStartTimeStr: "",//签到开始时间
                responsibility:[],//活动负责人
                responsibilityText:"",
                leagueTypeValue: "",//社团类型中文值
            },
            queryForm:{
                activityName:'', //社团活动名称
                leagueName:'', //所属社团
                leagueType:'', //社团类型code
                status:'', //活动状态code
                responsibilityName:'', //活动负责人
                signUpStartTime:[], //报名开始时间
                signUpStartMinTime:'', //报名开始时间（最小值）
                signUpStartMaxTime:'', //报名开始时间（最大值）
                signUpEndTime:[], //报名结束时间
                signUpEndMinTime:'', //报名结束时间（最小值）
                signUpEndMaxTime:'', //报名结束时间（最大值）
                activityStartTime:[], //活动开始时间
                activityStartMinTime:'', //活动开始时间（最小值）
                activityStartMaxTime:'', //活动开始时间（最大值）
                activityEndTime:[], //活动结束时间
                activityEndMinTime:'', //活动结束时间（最小值）
                activityEndMaxTime:'', //活动结束时间（最大值）
                currentPage:1, //当前页
                limit:10, //每夜条数
            },
            options:[
                {label:'111', value:'1'},
                {label:'2', value:'2'},
            ],
            tableData:[],
            totalNumber:0,
            getRowKey:function(row){
                return row.id;
            },
            codeDialog:false,
            dialogVisible:false,
            detailVisible:false,
            dialogForm:{
                activityName:'', //社团活动名称
                leagueId:'', //所属社团id
                leagueType:'', //社团类型code
                signUpTimeStr:'', //报名时间
                signUpStartTimeStr:'', //报名开始时间
                signUpEndTimeStr:'', //报名结束时间
                activityTimeStr:'', //活动时间
                activityStartTimeStr:'', //活动开始时间
                activityEndTimeStr:'', //活动结束时间
                signInTimeStr:'', //签到时间
                signInStartTimeStr:'', //签到开始时间
                signInEndTimeStr:'', //签到结束时间
                checkNos:[], //活动负责人(需要提交的数据)
                checkNosText:'', //活动负责人(需要展示的数据)
                responsibilityUserPhone:'', //负责人联系方式
                activityAdress:'', //活动地址
                minPerson:'', //活动人数要求最小值
                maxPerson:'', //活动人数要求最大值
                activityPiciture:'', //活动封面图url
                activityIntroduction:'', //活动介绍
                saveStatus:'', //1发2保存布状态
            },
            rules:{
                activityName: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
                leagueId:[ { required: true, message: '请选择所属社团', trigger: 'change' }],
                leagueType:[ { required: true, message: '请选择社团类型', trigger: 'change' }], //社团类型code
                signUpTimeStr:[ { required: true, message: '请选择报名时间', trigger: 'blur' }], //报名时间
                activityTimeStr:[{ required: true, message: '请输入活动时间', trigger: 'blur' }], //活动时间
                signInTimeStr:[{ required: true, message: '请输入签到时间', trigger: 'blur' }], //签到时间
                checkNosText:[{ required: true, message: '请输入活动负责人', trigger: 'blur' }], //活动负责人(需要展示的数据)
                responsibilityUserPhone:[{ required: true, message: '请输入负责人联系方式', trigger: 'blur' }], //负责人联系方式
                activityAdress:[{ required: true, message: '请输入活动地址', trigger: 'blur' }], //活动地址
                minPerson:[{ required: true, validator: checkOvertime, trigger: 'blur' }], //活动人数要求最小值
            },
            codeImgUrl:'',
            codeImgName:'活动二维码',
            showMember:false,//工会工人弹框
            queryid:'',//工会活动id
            showSignUp:false,//报名人数弹框
            showParticipants:false,//参加人员名单弹框
            fileList:[],
            checkedActivity:[],
            editId:'', //要修改的活动
        }
    },
    components:{
        Editor,
        MemberList,
        SignUp,
        Participants
    },
    created(){
        this.getList();
    },
    methods:{
        //参会人数
        SignUpClubActivity(row){
            this.queryid=row.id;
            this.showSignUp=true;
        },
        //报名人数
        participantsClubActivity(row){
            this.queryid=row.id;
            this.showParticipants=true;
        },
        //取消后恢复状态
        calcel(){          
            this.dialogForm.maxPerson='';
            this.$refs.editor.clear();
            this.dialogVisible=false;
           
            this.$nextTick(() =>{
                this. dialogForm={
                activityName:'', //社团活动名称
                leagueId:'', //所属社团id
                leagueType:'', //社团类型code
                signUpTimeStr:'', //报名时间
                signUpStartTimeStr:'', //报名开始时间
                signUpEndTimeStr:'', //报名结束时间
                activityTimeStr:'', //活动时间
                activityStartTimeStr:'', //活动开始时间
                activityEndTimeStr:'', //活动结束时间
                signInTimeStr:'', //签到时间
                signInStartTimeStr:'', //签到开始时间
                signInEndTimeStr:'', //签到结束时间
                checkNos:[], //活动负责人(需要提交的数据)
                checkNosText:'', //活动负责人(需要展示的数据)
                responsibilityUserPhone:'', //负责人联系方式
                activityAdress:'', //活动地址
                minPerson:'', //活动人数要求最小值
                maxPerson:'', //活动人数要求最大值
                activityPiciture:'', //活动封面图url
                activityIntroduction:'', //活动介绍
                saveStatus:'', //新增状态
            };
                this.resetForm('ruleForm');
            })
        },
        //弹框关闭确认按钮
        handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
              this.calcel();
               done();
          })
          .catch(_ => {});
        },
        handleSelectionChange(val){
            this.checkedActivity = val;
        },
        getIndex(index){
            return((this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1)
        },
        getList(){
            let params = this.queryForm;
            if(this.queryForm.signUpStartTime.length > 0){
                params.signUpStartMinTime = this.queryForm.signUpStartTime[0];
                params.signUpStartMaxTime = this.queryForm.signUpStartTime[1];
            }
            if(this.queryForm.signUpEndTime.length > 0){
                params.signUpEndMinTime = this.queryForm.signUpEndTime[0];
                params.signUpEndMaxTime = this.queryForm.signUpEndTime[1];
            }
            if(this.queryForm.activityStartTime.length > 0){
                params.activityStartMinTime = this.queryForm.activityStartTime[0];
                params.activityStartMaxTime = this.queryForm.activityStartTime[1];
            }
            if(this.queryForm.activityEndTime.length > 0){
                params.activityEndMinTime = this.queryForm.activityEndTime[0];
                params.activityEndMaxTime = this.queryForm.activityEndTime[1];
            }
            
            this.$api.myApi.activityManage.getClubActivityList(params).then(res => {
                if (res.retCode == "0") {
                    this.totalNumber = res.result.totalNumber;
                    this.tableData = res.result.list;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        reset(){
            this.queryForm = {
                activityName:'', //社团活动名称
                leagueName:'', //所属社团
                leagueType:'', //社团类型code
                status:'', //活动状态code
                responsibilityName:'', //活动负责人
                signUpStartTime:[], //报名开始时间
                signUpStartMinTime:'', //报名开始时间（最小值）
                signUpStartMaxTime:'', //报名开始时间（最大值）
                signUpEndTime:[], //报名结束时间
                signUpEndMinTime:'', //报名结束时间（最小值）
                signUpEndMaxTime:'', //报名结束时间（最大值）
                activityStartTime:[], //活动开始时间
                activityStartMinTime:'', //活动开始时间（最小值）
                activityStartMaxTime:'', //活动开始时间（最大值）
                activityEndTime:[], //活动结束时间
                activityEndMinTime:'', //活动结束时间（最小值）
                activityEndMaxTime:'', //活动结束时间（最大值）
                currentPage:1, //当前页
                limit:10, //每夜条数
            }
            this.getList();
        },
        //查看二维码
        checkCode(){
            let canvas = document.getElementById('codeCanvas')
            if(canvas){
                QRCode.toCanvas(canvas, 'http://www.baidu.com', function (error) {
                    console.log(error)
                })
                this.codeImgUrl = canvas.toDataURL("image/png");
            }
        },
        //获取负责人
        getCheckNos(val){
            // console.log('val', val)
            let checkNosTextArr = [], responsibilityUserPhoneArr = [];
            val.forEach((item, index) => {
                let checkNosItem = {
                        checkNo:item.checkNo,
                        phone: item.phone
                    }
                this.dialogForm.checkNos.push(checkNosItem);
                
                let checkNosTextArrItem = `${item.userName}(${item.checkNo})`;
                checkNosTextArr.push(checkNosTextArrItem);

                responsibilityUserPhoneArr.push(item.phone);
            })
            this.dialogForm.checkNosText = checkNosTextArr.toString();
            this.dialogForm.responsibilityUserPhone = responsibilityUserPhoneArr.toString();
        },
         //解析负责人
        getUsers(val){
            // console.log('val', val)
            let users= [];
            val.forEach((item, index) => {
                users.push(`${item.userName}(${item.checkNo})`);
            })
           return users.join();
        },
        handlePreview(){},
        handleRemove(){},
        beforeRemove(){},
        handleExceed(){},
        //获取富文本内容
        getHtml(html){
            console.log(html);
            this.dialogForm.activityIntroduction = html;
        },
        //上传图片
        uploadImg(){

        },
        //新增或修改
        operationClubActivity(saveStatus){
            //1发布2保存
             this.dialogForm.saveStatus = saveStatus;
            if(this.dialogForm.signUpTimeStr.length > 0){
                this.dialogForm.signUpStartTimeStr = this.dialogForm.signUpTimeStr[0];
                this.dialogForm.signUpEndTimeStr = this.dialogForm.signUpTimeStr[1];
            }
            if(this.dialogForm.activityTimeStr.length > 0){
                this.dialogForm.activityStartTimeStr = this.dialogForm.activityTimeStr[0];
                this.dialogForm.activityEndTimeStr = this.dialogForm.activityTimeStr[1];
            }
            if(this.dialogForm.signInTimeStr.length > 0){
                this.dialogForm.signInStartTimeStr = this.dialogForm.signInTimeStr[0];
                this.dialogForm.signInEndTimeStr = this.dialogForm.signInTimeStr[1];
            }
            if(saveStatus=='1'){
                //发布
                 if(!this.isEdit){
                //新增
                this.$api.myApi.activityManage.addClubActivity(this.dialogForm).then(res => {
                    if (res.retCode == "0") {
                        this.$message.success(res.retMsg);
                        this.dialogVisible = false;
                        this.calcel();
                        this.getList();
                    } else {
                        this.$message.error(res.retMsg)
                    }
                        });
                    }else{
                        //修改
                        this.$api.myApi.activityManage.editClubActivity(this.dialogForm).then(res => {
                            if (res.retCode == "0") {
                                this.$message.success(res.retMsg);
                                this.dialogVisible = false;
                                this.calcel();
                            } else {
                                this.$message.error(res.retMsg)
                            }
                        });
                    }
            }else{
                // 保存
            }
           
            
        },
        //查看活动详情
        detailClubActivity(row){
             this.$api.myApi.activityManage.getClubActivityDetail(row.id).then(res => {
                if (res.retcode == "0") {      
                    this.detailForm = res.result;
                     res=res.result;
                    // 活动时间
                    console.log(res);
                    this.detailForm.activityTimeStr=[res.activityStartTimeStr,res.activityEndTimeStr];
                    //报名时间
                    this.detailForm.signUpTimeStr=[res.signUpStartTimeStr,res.signUpEndTimeStr];
                    //签到时间
                    this.detailForm.signInTimeStr=[res.signInStartTimeStr,res.signInEndTimeStr];
                    this.detailForm.responsibilityText=this.getUsers(res.responsibility);
                    this.detailVisible=true;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        //点击修改
        clickEdit(){
            if(this.checkedActivity.length == 0){
                this.$alert('请先选择活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else if(this.checkedActivity.length > 1){
                this.$alert('请选择一条活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else{
                this.editId = this.checkedActivity[0].id;
                this.isEdit=true;
                //查询详情
                 this.$api.myApi.activityManage.getClubActivityDetail(this.editId).then(res => {
                if (res.retcode == "0") {      
                    this.dialogForm = res.result;
                    res=res.result;
                    // 活动时间
                    this.$set(this.dialogForm, "activityTimeStr", [res.activityStartTimeStr,res.activityEndTimeStr]);
                    //报名时间
                     this.$set(this.dialogForm, "signUpTimeStr", [res.signUpStartTimeStr,res.signUpEndTimeStr]);
                  
                    //签到时间
                      this.$set(this.dialogForm, "signInTimeStr", [res.signInStartTimeStr,res.signInEndTimeStr]);

                    this.dialogForm.checkNosText=this.getUsers(res.responsibility);
                    this.dialogVisible=true;
                    this.$nextTick(()=>{
                        this.$refs.editor.changeHtml(res.activityIntroduction);
                    })
                } else {
                    this.$message.error(res.retMsg)
                }
            });
            }
        },
        //一键发布
        onekeyRelease(){
            if(this.checkedActivity.length == 0){
                this.$alert('请先选择要发布的活动', '提示', {
                    confirmButtonText: '确定',
                });
                return;
            }
             let preReleases=this.checkedActivity;
             preReleases=preReleases.filter(item=>item.status==='未发布').map(item=>item.id);
            if(preReleases.length<1){
                 this.$alert('请先选择未发布的活动', '提示', {
                    confirmButtonText: '确定',
                });
                return;
            }
            //一键发布
        },
        //发布// 保存
        handleRelease(formName,saveState){
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.operationClubActivity(saveState);
                } else {
                    console.log('error submit!!');
                    return false;
                }
             });
        },
        
        // handleSave(formName){
        //      this.$refs[formName].validate((valid) => {
        //         if (valid) {
        //             this.operationClubActivity(2);
        //         } else {
        //             console.log('error submit!!');
        //             return false;
        //         }
        //      });
        // },
        //重置方法
        resetForm(formName){
             this.$refs[formName].resetFields();
        },
        //删除活动
        delClubActivity(){
            if(this.checkedActivity.length == 0){
                this.$alert('请先选择活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else{
                this.$alert('确定删除该活动吗', '提示', {
                    confirmButtonText: '确定',
                    callback: () => {
                        let idsArr = this.checkedActivity.map((item, index) => {
                            return item.id;
                        })
                        let params = {
                            ids: idsArr.toString()
                        }
                        this.$api.myApi.activityManage.delClubActivity(params).then(res => {
                            if (res.retCode == "0") {
                                this.$message.success(res.retMsg);
                                this.getList();
                            } else {
                                this.$message.error(res.retMsg)
                            }
                        });
                    }
                });
            }
        }
    },
    computed:{
        isTitle:function(){
             return this.isEdit?"修改活动":"新增活动";
        }
    }
}
</script>
<style scoped lang="scss">
    .container /deep/ .el-dialog__body{
        padding:0px 20px 30px 20px;
    }
    .input-width{
        width:100%;
    }
    #qrcode{
        text-align:center;
    }
    #codeCanvas{
        width:250px !important;
        height:250px !important;
    }
    .flex-wrap{
        display:flex;
        margin-bottom:22px;
        label{
            width:120px;
            padding-right:12px;
            text-align:right;
        }
    }
    .editor-wrap{
        flex:1;
    }
    .dialog-footer-center{
        // margin-top:20px;
        text-align:center;
    }
</style>