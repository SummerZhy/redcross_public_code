// 报名人员列表
<template>
  	<el-dialog
        title="报名人员名单"
        :visible.sync="showDialog"
        width="80%">
        <el-form class="" ref="form" :model="queryForm" label-width="100px">
            <el-row>
                <el-col :span="8">
                    <el-form-item label="会员名称">
                        <el-input v-model="queryForm.userName"></el-input>
                    </el-form-item>                       
                </el-col>
                <el-col :span="8">  
                    <el-form-item label="所属部门">
                        <el-select v-model="queryForm.deptNo" placeholder="全部" class="input-width"> 
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>   
                </el-col>
                <el-col :span="4">  
                    <div class="query-btn">
                        <el-button @click="queryForm.currentPage = 1; getList()" type="danger">查询</el-button>                       
                    </div>                                                                                           
                </el-col>
                <el-col :span="2">
                    <div class="query-btn">
                        <el-button  @click="exportApplicants" >导出</el-button>                       
                    </div>
                </el-col>
            </el-row>
        </el-form>
        <el-table
            border
            :header-cell-style="tableHeadColor"
            :data="tableData"
            style="width: 100%"
          >
            <el-table-column
                type="index"
                :index="getIndex"
                label="序号"
                width="55">
            </el-table-column>
            <el-table-column
                label="会员名称">
                <template slot-scope="scope">{{ scope.row.userName }}</template>
            </el-table-column>
            <el-table-column
                prop="genderValue"
                label="性别">
            </el-table-column>   
            <el-table-column
                prop="phone"
                label="联系方式">
            </el-table-column>                 
            <el-table-column
                prop="department"
                label="所属部门">
            </el-table-column> 
            <el-table-column
                prop="positionValue"
                label="职位">
            </el-table-column> 
            <!-- <el-table-column
                prop="status"
                label="会员状态">
            </el-table-column>  -->
        </el-table>
        <el-pagination
            background
            :current-page.sync="queryForm.currentPage"
            :page-sizes="[10, 20, 50, 100]"
            :page-size.sync="queryForm.limit"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalNumber"
            @current-change="getList"
            @size-change="getList">
        </el-pagination>  
        <div class="dialog-footer-center">
            
            <el-button @click="showDialog = false">关 闭</el-button>
        </div>    
    </el-dialog>
</template>
<script>
export default {

  	data(){
    	return{
            tableHeadColor:{
                backgroundColor:'#f5f7fa'
            },
            options:[
                {label:'111', value:'1'},
                {label:'2', value:'2'},
            ],
            queryForm:{
                userName:'', //会员名称
                deptNo:'', //所属部门 字典值 dept
                currentPage:1, //当前页
                limit:10 //每页条数
               
            },
            totalNumber:0,
            tableData:[],
            getRowKey:function(row){
                return row.id;
            },
            showDialog:false,
    	}
    },
    props:{
        value:{
            type:Boolean,
            default:false
        },
        queryid:{
            type:[Number,String]
        }
    },
    watch:{
        value(newVal, oldVal){
            if(newVal){
                this.showDialog = newVal;
                this.queryForm.id=this.queryid;
                this.$nextTick(function(){
                    this.getList();
                })
            }
        },
        showDialog(newVal, oldVal){
            if(!newVal){
                this.$emit('input',newVal);
            }
        } 
    },
    created(){
        
    },
    methods:{
        getIndex(index){
            return((this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1)
        },
        //获取报名人员列表
        getList(){  
            this.$api.myApi.signUp.getSignUpList(this.queryForm).then(res => {
                if (res.retCode == "0") {
                    this.totalNumber = res.result.totalNumber;
                    this.tableData = res.result.list;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        // 导出报名人员列表
        exportApplicants(){
             this.$api.myApi.signUp.exportApplicants(this.queryForm).then(res => {
                if (res.retCode == "0") {
                      const blob = new Blob([res.list], { type: 'application/vnd.ms-excel;' })
                        const a = document.createElement('a')
                        // 生成文件路径
                        let href = window.URL.createObjectURL(blob)
                        a.href = href
                        let _fileName = res.headers['content-disposition'].split(';')[1].split('=')[1].split('.')[0]
                        // 文件名中有中文 则对文件名进行转码
                        a.download = decodeURIComponent(_fileName)
                        // 利用a标签做下载
                        document.body.appendChild(a)
                        a.click()
                        document.body.removeChild(a)
                        window.URL.revokeObjectURL(href)
                } else {
                    this.$message.error(res.retMsg)
                }
            })
        }
    }
}
</script>
<style scoped>
    .query-btn{
        text-align:right;
        margin-bottom:22px;
        padding-right:10px;
    }
    .dialog-footer-center{
        margin-top:60px;
        text-align:center;
    }
</style>