<template>
    <div class="container">
        <el-form class="query-form" ref="form" :model="queryForm" label-width="100px">
            <el-row>
                <el-col :span="7">
                    <el-form-item label="工会活动名称">
                        <el-input v-model="queryForm.activityName"></el-input>
                    </el-form-item>
                    <el-form-item label="报名开始时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.registrationStartTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                    <el-form-item label="报名结束时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.registrationEndTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                </el-col>
                <el-col :span="7">  
                   <el-form-item label="活动状态">
                        <el-select v-model="queryForm.activityStatus" placeholder="请选择活动状态" class="input-width">
                            <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="活动开始时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityStartTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                     <el-form-item label="活动结束时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityEndTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item> 
                </el-col>
                <el-col :span="7">  
                     <el-form-item label="活动负责人">
                          <el-input v-model="queryForm.responsibilityName" suffix-icon="el-icon-s-custom" @focus="forSearch=true;showMember=true"></el-input>
                    </el-form-item>
               
                    <el-form-item label="签到开始时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityStartSignTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item>   
                     <el-form-item label="签到结束时间">
                        <el-date-picker
                        class="input-width"
                            v-model="queryForm.activityEndSignTime"
                            value-format="yyyy-MM-dd hh:mm:ss"
                            type="datetimerange"
                            range-separator="-"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期">
                        </el-date-picker>
                    </el-form-item>                   
                </el-col>
                <el-col :span="3">
                    <div class="query-btn">
                        <el-button @click="queryForm.currentPage = 1; getList()" type="danger">查询</el-button>                       
                    </div>
                    <div class="query-btn">
                        <el-button @click="reset">重置</el-button>
                    </div>
                </el-col>
            </el-row>
        </el-form>
        <div class="main-con">
            <title-operation title="工会活动列表">
                <el-button type="danger" @click=" isEdit=false;dialogVisible=true">新增</el-button>
                <el-button @click="clickEdit">修改</el-button>
                <el-button @click="onekeyRelease">一键发布</el-button>
                <el-button @click="delClubActivity">删除</el-button>
            </title-operation>
            <div class="content">
                <el-table
                    border
                    :header-cell-style="tableHeadColor"
                    :data="tableData"
                    style="width: 100%"
                    :row-key='getRowKey' 
                    @selection-change="handleSelectionChange">
                    <el-table-column
                        type="selection"
                        reserve-selection
                        width="55">
                    </el-table-column>
                    <el-table-column
                        type="index"
                        :index="getIndex"
                        label="序号"
                        width="55">
                        <!-- <template >{{ getIndex() }}</template> -->
                    </el-table-column>
                    <el-table-column
                        label="工会活动名称">
                        <el-button slot-scope="scope" @click="detailClubActivity(scope.row)" type="text" size="small">{{ scope.row.activityName }}</el-button>
                    </el-table-column>
                    <el-table-column
                        label="报名人数">
                       <el-button slot-scope="scope" @click="SignUpClubActivity(scope.row)" type="text" size="small">{{ scope.row.registrationCount }}</el-button>
                    </el-table-column>
                     <el-table-column
                        label="活动负责人" >
                        <template slot-scope="scope" >{{scope.row.principals.reduce((value,item)=>{ if(value!='') value+=','; return value+`${item.principalName}(${item.principalId})`},"")}}</template>
                    </el-table-column>
                     <el-table-column
                        prop="activiyStatus"
                        label="活动状态">
                         <!-- <template slot-scope="scope">{{ scope.row.activiyStatus }}</template> -->
                    </el-table-column>
                    <el-table-column
                        label="活动二维码">
                         <el-button slot-scope="scope"  @click="showQRCode(scope.row.activityQrcodeUrl)"  type="text" size="small">活动二维码</el-button>
                    </el-table-column>
                    <el-table-column
                        prop="registrationStartTime"
                        label="报名开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="registrationEndTime"
                        label="报名结束时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityStartTime"
                        label="活动开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityEndTime"
                        label="活动结束时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityStartSignTime"
                        label="签到开始时间">
                    </el-table-column>
                    <el-table-column
                        prop="activityEndSignTime"
                        label="签到结束时间">
                    </el-table-column>
                    <el-table-column
                        label="操作人">
                        <template slot-scope="scope">{{ scope.row.createUserName +  scope.row.createUserId}}</template>
                    </el-table-column>
                    <el-table-column
                        prop="createTime"
                        label="操作时间">
                    </el-table-column>
                </el-table>
            </div>
            <div class="paginator">
                <el-pagination
                    background
                    :current-page.sync="queryForm.currentPage"
                    :page-sizes="[10, 20, 50, 100]"
                    :page-size.sync="queryForm.limit"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="totalNumber"
                    @current-change="getList"
                    @size-change="getList">
                </el-pagination>
            </div>
        </div>
        <!-- 新增弹窗 -->
        <el-dialog
            :title="isTitle"
            :visible.sync="dialogVisible"
            width="80%"
            :before-close="handleClose">
            <el-form  :model="dialogForm" :rules="rules" ref="ruleForm"  label-width="120px">
                    <el-row>
                    <el-col :span="11">
                        <el-form-item label="工会活动名称" prop="activityName">
                            <el-input v-model="dialogForm.activityName"></el-input>
                        </el-form-item>
                        <!-- <el-form-item label="工会类型" prop="leagueType">
                            <el-select v-model="dialogForm.leagueType" placeholder="请选择工会类型" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item>                        -->
                        <el-form-item label="活动时间" prop="activityTime">
                            <el-date-picker
                                class="input-width"
                                v-model="dialogForm.activityTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        <el-form-item label="活动负责人" prop="principalIdText">
                            <el-input v-model="dialogForm.principalIdText" suffix-icon="el-icon-s-custom" @focus="forSearch=false;showMember=true"></el-input>
                        </el-form-item>
                        <el-form-item label="活动地址" prop="activityAddress">
                            <el-input v-model="dialogForm.activityAddress"></el-input>
                        </el-form-item>
                       
                    </el-col>
                    <el-col :span='11'>
                        <!-- <el-form-item label="所属工会" prop="leagueId">
                            <el-select v-model="dialogForm.leagueId" placeholder="请选择所属工会" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item> -->
                        
                        <el-form-item label="报名时间" prop="registrationTime">
                            <el-date-picker
                            class="input-width"
                                v-model="dialogForm.registrationTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        
                        <el-form-item label="签到时间" prop="activitySignTime">
                            <el-date-picker
                            class="input-width"
                                v-model="dialogForm.activitySignTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item label="负责人联系方式" prop="principalPhone">
                            <el-input v-model="dialogForm.principalPhone"></el-input>
                        </el-form-item>
                         <el-form-item label="活动人数要求" prop="needRegistrationCountMin">
                            <el-col :span="11">
                                <el-input v-model="dialogForm.needRegistrationCountMin"></el-input>
                            </el-col>
                            <el-col class="line" :span="2" style='text-align:center;'>-</el-col>
                            <el-col :span="11">
                                <el-input ref="needRegistrationCountMax" v-model="dialogForm.needRegistrationCountMax"></el-input>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <div class="flex-wrap">
                            <el-form-item label="活动封面图"  ref="fileUploadTips"  prop="coverUrl">
                                    <el-input v-model="dialogForm.coverUrl"   v-show="false" ></el-input>
                                    <el-upload
                                        class="upload-demo"
                                        action="https://jsonplaceholder.typicode.com/posts/"
                                        :on-remove="handleRemove"
                                        :before-remove="beforeRemove"
                                        :limit="1"
                                        :on-exceed="handleExceed"
                                        :on-change="handleChange"
                                        :file-list="fileList">
                                        <el-button size="small" type="primary">点击上传</el-button>
                                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过1M</div>
                                    </el-upload>
                               
                             </el-form-item>
                        </div>
                        <div class="flex-wrap">
                            <label for="">活动介绍</label>
                            <editor 
                            class="editor-wrap"
                            ref="editor"
                            :initCont="dialogForm.activityIntraduration"
                            @getHtml="getHtml"></editor>
                        </div>
                    </el-col>
                </el-row>                
            </el-form>
            <div class="dialog-footer-center">
                <el-button type="danger" @click="handleRelease('ruleForm',1)">发 布</el-button>
                <el-button @click="handleRelease('ruleForm',2)">保 存</el-button>
                <el-button @click="calcel">取 消</el-button>
            </div>
        </el-dialog>
        <!-- 活动详情 -->
         <el-dialog
            title="活动详情"
            :visible.sync="detailVisible"
            width="80%"
            >
            <el-form :model="detailForm" label-width="120px"  :disabled="true">
                <el-row>
                    <el-col :span="11">
                        <el-form-item label="工会活动名称">
                            <el-input v-model="detailForm.activityName"></el-input>
                        </el-form-item>
                                           
                        <el-form-item label="活动时间">
                            <el-date-picker
                                class="input-width"
                                v-model="detailForm.activityTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        <el-form-item label="活动负责人">
                            <el-input v-model="detailForm.principalIdText" suffix-icon="el-icon-s-custom" ></el-input>
                        </el-form-item>
                        <el-form-item label="活动地址">
                            <el-input v-model="detailForm.activityAddress"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span='11'>
                        <!-- <el-form-item label="所属工会">
                            <el-select v-model="detailForm.leagueId" placeholder="请选择所属工会" class="input-width"> 
                                <el-option v-for="item in options" :key="item.value" :value="item.value" :label="item.label"></el-option>
                            </el-select>
                        </el-form-item> -->
                        
                        <el-form-item label="报名时间">
                            <el-date-picker
                            class="input-width"
                                v-model="detailForm.registrationTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item> 
                        
                        <el-form-item label="签到时间">
                            <el-date-picker
                            class="input-width"
                                v-model="detailForm.activitySignTime"
                                value-format="yyyy-MM-dd hh:mm:ss"
                                type="datetimerange"
                                range-separator="-"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                            </el-date-picker>
                        </el-form-item>
                        <el-form-item label="负责人联系方式">
                            <el-input v-model="detailForm.phone"></el-input>
                        </el-form-item>
                        <el-form-item label="活动人数要求">
                            <el-col :span="11">
                                <el-input v-model="detailForm.needRegistrationCountMin"></el-input>
                            </el-col>
                            <el-col class="line" :span="2" style='text-align:center;'>-</el-col>
                            <el-col :span="11">
                                <el-input v-model="detailForm.needRegistrationCountMin"></el-input>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="22">
                        <div class="flex-wrap">
                            <label for="">活动封面图</label>
                             <!-- <el-upload
                                class="upload-demo"
                                action="https://jsonplaceholder.typicode.com/posts/"
                                :on-preview="handlePreview"
                                :on-remove="handleRemove"
                                :before-remove="beforeRemove"
                                :limit="1"
                                :on-exceed="handleExceed"
                                :file-list="fileList">
                                <el-button size="small" type="primary">点击上传</el-button>
                                <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过1M</div>
                            </el-upload> -->
                            <el-image
                                style="width: 300px; height: 200px"
                                :src="detailForm.coverUrl"
                                fit="cover">
                            </el-image>
                        </div>
                    </el-col>
                </el-row>  
                 <el-row>
                      <el-col :span="24" >
                        <div class="flex-wrap">
                            <!-- <label for="" >活动介绍</label> -->
                                <!-- <editor 
                                class="editor-wrap"
                                :initCont="detailForm.activityIntroduction"
                            ></editor> -->
                           <el-form-item label="活动介绍" style="width:92%">
                                <el-input
                                    type="textarea"
                                    v-model="detailForm.activityIntraduration"
                                    rows="6"
                                    show-word-limit
                                    resize="none"
                                    >
                                </el-input>
                           </el-form-item >
                        </div>
                    </el-col>
                </el-row>                
            </el-form>
            <div class="dialog-footer-center">
                <el-button @click="detailVisible = false">关 闭</el-button>
            </div>
        </el-dialog>
        <!-- 二维码弹窗 -->
        <el-dialog 
            title="活动二维码"
            :visible.sync="codeDialog"
            width="300px"
            @opened="checkCode">
            <div id="qrcode">
                <canvas id="codeCanvas"></canvas>
                <a :href="codeImgUrl" :download="codeImgName">下载</a>
            </div>
        </el-dialog>
        <!-- 工会会员 -->
        <member-list v-model="showMember" @getMembers="getCheckNos" ></member-list>
         <!-- 报名人员 -->
        <sign-up v-model="showSignUp" :queryid="queryid" ></sign-up>
         <!-- 参加人员 -->
         <participants  v-model="showParticipants" :queryid="queryid" ></participants>
    </div>
</template>



<script>

import QRCode from 'qrcode' 
import Editor from '@/views/activity/components/Editor.vue'
import MemberList from '@/views/activity/components/MemberList.vue'
import SignUp from '@/views/activity/components/SignUp.vue'
import Participants from '@/views/activity/components/Participants.vue'



export default {
    data(){
        // 验证规则
        var  isUploaded=(rule,value,callback)=>{
            if(this.fileList.length==1){
                callback();
            }else{
                 callback(new Error('请上传图片'))
            }
        };
        var checkOvertime = (rule, value, callback) => {

        let needRegistrationCountMax = this.$refs.needRegistrationCountMax.value;
        if (value && needRegistrationCountMax) {
            callback()
        } else {
            if (!value) {
            callback(new Error('请输入最小人数'))
            }
            if (!needRegistrationCountMax) {
            callback(new Error('请输入最大人数'))
            }
        }
        }

        return{
            forSearch:false,
            tableHeadColor:{
                backgroundColor:'#f5f7fa'
            },
            publicPath: process.env.BASE_URL,
            isEdit:false,//点击的是否是修改
            detailForm:{
                activityName: "",//工会活动名称
                needRegistrationCountMin: 1,//活动人数要求最小值
                activityAddress: "",//活动地址
                phone: "",//负责人联系方式
                activityTime:"",//活动时间
                activityEndTime: "",//活动结束时间
                activityStartTime: "",//活动开始时间
                registrationEndTime: "",//报名结束时间
                registrationStartTime: "",//报名开始时间
                needRegistrationCountMax: 2,//活动人数要求最大值
                activityIntroduction: "",//
                leagueId: "",//所属工会id
                leagueType: "",//工会类型code
                activityIntraduration:"",//活动介绍
                coverUrl:"",//活动封面图url
                activityEndSignTime: "",//签到结束时间
                activityStartSignTime: "",//签到开始时间
                principal:[],//活动负责人
                principalIdText:"",//活动负责人显示
                leagueTypeValue: "",//工会类型中文值
            },
            queryForm:{
                activityName:'', //工会活动名称
                activityStatus:'', //活动状态code
                principalId:'', //活动负责人
                registrationStartTime:[], //报名开始时间
                registrationStartTimeMin:'', //报名开始时间（最小值）
                registrationStartTimeMax:'', //报名开始时间（最大值）
                registrationEndTime:[], //报名结束时间
                registrationEndTimeMin:'', //报名结束时间（最小值）
                registrationEndTimeMax:'', //报名结束时间（最大值）
                activityStartTime:[], //活动开始时间
                activityStartTimeMin:'', //活动开始时间（最小值）
                activityStartTimeMax:'', //活动开始时间（最大值）
                activityEndTime:[],//活动结束时间
                activityEndTimeMin:'',//活动结束时间（最小值）
                activityEndTimeMax:'',//活动结束时间（最大值）
                activityStartSignTime:[],//签到开始时间
                activityStartSignTimeMin:'',//签到开始时间（最小值）
                activityStartSignTimeMax:'',//签到开始时间（最大值）
                activityEndSignTime:[],//签到结束时间
                activityEndSignTimeMin:'',//签到结束时间（最小值）
                activityEndSignTimeMax:'',//签到结束时间（最大值）
                currentPage:1, //当前页
                limit:10, //每夜条数
            },
            options:[
                {label:'111', value:'1'},
                {label:'2', value:'2'},
            ],
            tableData:[],
            totalNumber:0,
            getRowKey:function(row){
                return row.id;
            },
            codeDialog:false,
            dialogVisible:false,
            detailVisible:false,
            dialogForm:{
                activityName:'', //工会活动名称
                registrationTime:'', //报名时间
                registrationStartTime:'', //报名开始时间
                registrationEndTime:'', //报名结束时间
                activityTime:'', //活动时间
                activityStartTime:'', //活动开始时间
                activityEndTime:'', //活动结束时间
                activitySignTime:'', //签到时间
                activityStartSignTime:'', //签到开始时间
                activityEndSignTime:'', //签到结束时间
                principalId:[], //活动负责人(需要提交的数据)
                principalIdText:'', //活动负责人(需要展示的数据)
                principalPhone:'', //负责人联系方式
                activityAddress:'', //活动地址
                needRegistrationCountMin:'', //活动人数要求最小值
                needRegistrationCountMax:'', //活动人数要求最大值
                coverUrl:'', //活动封面图url
                activityIntraduration:'', //活动介绍
                saveType:'', //1发2保存布状态
            },
            rules:{
                activityName: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
                registrationTime:[ { required: true, message: '请选择报名时间', trigger: 'blur' }], //报名时间
                activityTime:[{ required: true, message: '请输入活动时间', trigger: 'blur' }], //活动时间
                activitySignTime:[{ required: true, message: '请输入签到时间', trigger: 'blur' }], //签到时间
                principalIdText:[{ required: true, message: '请输入活动负责人', trigger: ['blur','change'] }], //活动负责人(需要展示的数据)
                principalPhone:[{ required: true, message: '请输入负责人联系方式', trigger: 'blur' }], //负责人联系方式
                activityAddress:[{ required: true, message: '请输入活动地址', trigger: 'blur' }], //活动地址
                needRegistrationCountMin:[{ required: true, validator: checkOvertime, trigger: 'blur' }], //活动人数要求最小值
                coverUrl:[{ required: true, validator: isUploaded, trigger: 'change' }]
           },
            codeImgUrl:'',
            codeImgName:'活动二维码',
            showMember:false,//工会工人弹框
            queryid:'',//工会活动id
            showSignUp:false,//报名人数弹框
            showParticipants:false,//参加人员名单弹框
            fileList:[],
            checkedActivity:[],
            editId:'', //要修改的活动
        }
    },
    components:{
        Editor,
        MemberList,
        SignUp,
        Participants
    },
    created(){
        this.getList();
    },
    methods:{
        //参会人数
        SignUpClubActivity(row){
            this.queryid=row.id;
            this.showSignUp=true;
        },
        //报名人数
        participantsClubActivity(row){
            this.queryid=row.id;
            this.showParticipants=true;
        },
        //取消后恢复状态
        calcel(){          
            this.dialogForm.maxPerson='';
            this.$refs.editor.clear();
            this.dialogVisible=false;
           
            this.$nextTick(() => {
                 this. dialogForm={
                activityName:'', //工会活动名称
                leagueId:'', //所属工会id
                leagueType:'', //工会类型code
                signUpTimeStr:'', //报名时间
                signUpStartTimeStr:'', //报名开始时间
                signUpEndTimeStr:'', //报名结束时间
                activityTimeStr:'', //活动时间
                activityStartTimeStr:'', //活动开始时间
                activityEndTimeStr:'', //活动结束时间
                signInTimeStr:'', //签到时间
                signInStartTimeStr:'', //签到开始时间
                signInEndTimeStr:'', //签到结束时间
                checkNos:[], //活动负责人(需要提交的数据)
                checkNosText:'', //活动负责人(需要展示的数据)
                responsibilityUserPhone:'', //负责人联系方式
                activityAdress:'', //活动地址
                minPerson:'', //活动人数要求最小值
                maxPerson:'', //活动人数要求最大值
                activityPiciture:'', //活动封面图url
                activityIntroduction:'', //活动介绍
                saveStatus:'', //新增状态
            };
                this.resetForm('ruleForm');
            })
        },
        //弹框关闭确认按钮
        handleClose(done) {
        this.$confirm('确认关闭？')
          .then(() => {
              this.calcel();
               done();
          })
          .catch(() => {});
        },
        handleSelectionChange(val){
            this.checkedActivity = val;
        },
        getIndex(index){
            return((this.queryForm.currentPage - 1) * this.queryForm.limit + index + 1)
        },

        //获取列表
        getList(){
            let params = this.queryForm;
            //报名开始时间
            if(this.queryForm.registrationStartTime.length > 0){
                params.registrationStartTimeMin = this.queryForm.registrationStartTime[0];
                params.registrationStartTimeMax = this.queryForm.registrationStartTime[1];
            }
            // //报名结束时间
            if(this.queryForm.registrationEndTime.length > 0){
                params.registrationEndTimeMin = this.queryForm.registrationEndTime[0];
                params.registrationEndTimeMax = this.queryForm.registrationEndTime[1];
            }
            //活动开始时间
            if(this.queryForm.activityStartTime.length > 0){
                params.activityStartTimeMin = this.queryForm.activityStartTime[0];
                params.activityStartTimeMax = this.queryForm.activityStartTime[1];
            }
            //活动结束时间
            if(this.queryForm.activityEndTime.length > 0){
                params.activityEndTimeMin = this.queryForm.activityEndTime[0];
                params.activityEndTimeMax = this.queryForm.activityEndTime[1];
            }
            //签到开始时间
             if(this.queryForm.activityStartSignTime.length > 0){
                params.activityStartSignTimeMin = this.queryForm.activityStartSignTime[0];
                params.activityStartSignTimeMax = this.queryForm.activityStartSignTime[1];
            }
            //签到结束时间
            if(this.queryForm.activityEndSignTime.length > 0){
                params.activityEndSignTimeMin = this.queryForm.activityEndSignTime[0];
                params.activityEndSignTimeMax = this.queryForm.activityEndSignTime[1];
            }
            
            this.$api.myApi.unionActivity.getUnionActivityList(params).then(res => {
                if (res.retCode == "0") {
                    this.totalNumber = res.result.totalNumber;
                    this.tableData = res.result.tLaborUnionActivitys;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        reset(){
            this.queryForm = {
                activityName:'', //工会活动名称
                leagueName:'', //所属工会
                leagueType:'', //工会类型code
                status:'', //活动状态code
                responsibilityName:'', //活动负责人
                signUpStartTime:[], //报名开始时间
                signUpStartMinTime:'', //报名开始时间（最小值）
                signUpStartMaxTime:'', //报名开始时间（最大值）
                signUpEndTime:[], //报名结束时间
                signUpEndMinTime:'', //报名结束时间（最小值）
                signUpEndMaxTime:'', //报名结束时间（最大值）
                activityStartTime:[], //活动开始时间
                activityStartMinTime:'', //活动开始时间（最小值）
                activityStartMaxTime:'', //活动开始时间（最大值）
                activityEndTime:[], //活动结束时间
                activityEndMinTime:'', //活动结束时间（最小值）
                activityEndMaxTime:'', //活动结束时间（最大值）
                currentPage:1, //当前页
                limit:10, //每夜条数
            }
            this.getList();
        },
        //点击二维码
        showQRCode(url){
            this.codeDialog=true;
            this.$nextTick(()=>{
                this.checkCode(url);
            })
        },
        //查看二维码
        checkCode(url){
            let canvas = document.getElementById('codeCanvas');
          
            if(canvas){
                QRCode.toCanvas(canvas,url, function (error) {
                   this.$alert(error);
                })
                this.codeImgUrl = canvas.toDataURL("image/png");
            }
        },
        //获取负责人
        getCheckNos(val){

           
            let principalIdTextArr = [], principalPhoneArr = [],ids=[],principalIds=[];
            val.forEach((item) => {
                let principalIdItem = {
                        checkNo:item.checkNo,
                        phone: item.phone
                    }
                principalIds.push(principalIdItem);
                let principalIdTextArrItem = `${item.userName}(${item.checkNo})`;
                ids.push(item.checkNo);
                principalIdTextArr.push(principalIdTextArrItem);
                principalPhoneArr.push(item.phone);
            })
            if(this.forSearch){
                this.queryForm.principalId = ids.toString();
                this.queryForm.responsibilityName = principalIdTextArr.toString();
            }else{
              this.dialogForm.principalIdText = principalIdTextArr.toString();
              this.dialogForm.principalPhone = principalPhoneArr.toString();
                this.dialogForm.principalId=principalIds;
            }
            
        },
         //解析负责人
        getUsers(val){
            let users= [];
            val.forEach((item) => {
                users.push(`${item.principalName}(${item.principalId})`);
            })
           return users.join();
        },
        // handleRemove(file, fileList) {
        //     this.fileList.pop()
        // },
        // handlePreview(file) {
        //     console.log(file);
        // },
        // handleExceed(files, fileList) {
        //     this.$message.warning(`只能选择 1 个文件`);
        // },
        // beforeRemove(file, fileList) {
        //     return this.$confirm(`确定移除 ${ file.name }？`);
        // },
        // handleChange(response, file){
           
            // this.$refs.fileUploadTips.clearValidate();
            // this.fileList.push(response);
        },
        //获取富文本内容
        getHtml(html){
            this.dialogForm.activityIntroduction = html;
        },
        //上传图片
        uploadImg(){

        },
        //新增或修改
        operationClubActivity(saveType){
            //1发布2保存
            if(this.dialogForm.registrationTime.length > 0){
                this.dialogForm.registrationStartTime = this.dialogForm.registrationTime[0];
                this.dialogForm.registrationEndTime = this.dialogForm.registrationTime[1];
            }
            if(this.dialogForm.activityTime.length > 0){
                this.dialogForm.activityStartTime = this.dialogForm.activityTime[0];
                this.dialogForm.activityEndTime = this.dialogForm.activityTime[1];
            }
            if(this.dialogForm.activitySignTime.length > 0){
                this.dialogForm.activityStartSignTime = this.dialogForm.activitySignTime[0];
                this.dialogForm.activityEndSignTime = this.dialogForm.activitySignTime[1];
            }
            this.dialogForm.coverUrl=this.fileList;
            this.dialogForm.saveType=saveType;   //发布 or // 保存
                if(!this.isEdit){
                    //新增
                 this.$api.myApi.unionActivity.addUnionActivity(this.dialogForm).then(res => {
                if (res.retCode == "0") {
                    this.$message.success(res.retMsg);
                    this.dialogVisible = false;
                    this.calcel();
                    this.getList();
                } else {
                    this.$message.error(res.retMsg)
                } 
                    });
                }else{
                    //修改
                 this.$api.myApi.unionActivity.editUnionActivity(this.dialogForm).then(res => {
                        if (res.retCode == "0") {
                            this.$message.success(res.retMsg);
                            this.dialogVisible = false;
                            this.calcel();
                        } else {
                            this.$message.error(res.retMsg)
                        }
                    });
                } 
        },
        //查看活动详情
        detailClubActivity(row){
             this.$api.myApi.unionActivity.getUnionActivityDetail(row.id).then(res => {
                if (res.retcode == "0") {      
                    this.detailForm = res.result;
                     res=res.result;
                    // 活动时间
                    this.detailForm.activityTime=[res.activityStartTime,res.activityEndTime];
                    //报名时间
                    this.detailForm.registrationTime=[res.registrationStartTime,res.registrationEndTime];
                    //签到时间
                    this.detailForm.activitySignTime=[res.activityStartSignTime,res.activityEndSignTime];
                    //活动负责人
                    this.detailForm.principalIdText=this.getUsers(res.principal);
                   
                   
                    this.detailVisible=true;
                } else {
                    this.$message.error(res.retMsg)
                }
            });
        },
        //点击修改
        clickEdit(){

            if(this.checkedActivity.length == 0){
                this.$alert('请先选择活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else if(this.checkedActivity.length > 1){
                this.$alert('请选择一条活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else{

                this.editId = this.checkedActivity[0].id;
                this.isEdit=true;
                this.forSearch=false;
                //查询详情
                 this.$api.myApi.unionActivity.getUnionActivityDetail(this.editId).then(res => {
                if (res.retcode == "0") {      
                    this.dialogForm = res.result;
                    res=res.result;
                    // 活动时间
                    this.$set(this.dialogForm, "activityTime", [res.activityStartTime,res.activityEndTime]);
                    //报名时间
                     this.$set(this.dialogForm, "registrationTime", [res.registrationStartTime,res.registrationEndTime]);
                  
                    //签到时间
                      this.$set(this.dialogForm, "activitySignTime", [res.activityStartSignTime,res.activityEndSignTime]);

                    this.dialogForm.principalIdText=this.getUsers(res.principal);
                    this.dialogForm.principalPhone=res.phone;
                    this.dialogVisible=true;
                    this.$nextTick(()=>{
                        this.$refs.editor.changeHtml(res.activityIntroduction);
                    })
                } else {
                    this.$message.error(res.retMsg)
                }
            });
            }
        },
        //一键发布
        onekeyRelease(){
            if(this.checkedActivity.length == 0){
                this.$alert('请先选择要发布的活动', '提示', {
                    confirmButtonText: '确定',
                });
                return;
            }
             let preReleases=this.checkedActivity;
             preReleases=preReleases.filter(item=>item.status==='未发布').map(item=>item.id);
            if(preReleases.length<1){
                 this.$alert('请先选择未发布的活动', '提示', {
                    confirmButtonText: '确定',
                });
                return;
            }
            //一键发布
        },
        //发布// 保存
        handleRelease(formName,saveState){
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.operationClubActivity(saveState);
                } else {
                    return false;
                }
             });
        },
        
        // handleSave(formName){
        //      this.$refs[formName].validate((valid) => {
        //         if (valid) {
        //             this.operationClubActivity(2);
        //         } else {
        //             console.log('error submit!!');
        //             return false;
        //         }
        //      });
        // },
        //重置方法
        resetForm(formName){
             this.$refs[formName].resetFields();
        },
        //删除活动
        delClubActivity(){
            if(this.checkedActivity.length == 0){
                this.$alert('请先选择活动', '提示', {
                    confirmButtonText: '确定',
                });
            }else{
                 this.$confirm('此操作将永久删除该活动, 是否继续?', '提示', {
                confirmButtonText: '确定',
                type: 'warning',
                showCancelButton:false
            }).then(() => {
             let idsArr = this.checkedActivity.map((item) => {
                return item.id;
            })
            let params = {
                ids: idsArr.toString()
            }
            this.$api.myApi.unionActivity.delUnionActivity(params).then(res => {
                if (res.retCode == "0") {
                    this.$message.success(res.retMsg);
                    this.getList();
                } else {
                    this.$message.error(res.retMsg)
                }
                });
            }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
            });
        }
                // this.$alert('确定删除该活动吗', '提示', {
                //     confirmButtonText: '确定',
                //     callback: () => {
                        // let idsArr = this.checkedActivity.map((item, index) => {
                        //     return item.id;
                        // })
                        // let params = {
                        //     ids: idsArr.toString()
                        // }
                        // this.$api.myApi.unionActivity.delUnionActivity(params).then(res => {
                        //     if (res.retCode == "0") {
                        //         this.$message.success(res.retMsg);
                        //         this.getList();
                        //     } else {
                        //         this.$message.error(res.retMsg)
                        //     }
                        // });
                    // }
                // });
            // }
        // }
    },
    computed:{
        isTitle:function(){
             return this.isEdit?"修改活动":"新增活动";
        }
    }
    // watch:{
    //    fileList:{
    //         deep:true, //深度监听设置为 true
    //         handler:function(newV,oldV){
    //         console.log('watch中：',newV)
    //         }
    //    }
    // }
}
</script>
<style scoped lang="scss">
    .container /deep/ .el-dialog__body{
        padding:0px 20px 30px 20px;
    }
    .input-width{
        width:100%;
    }
    #qrcode{
        text-align:center;
    }
    #codeCanvas{
        width:250px !important;
        height:250px !important;
    }
    .flex-wrap{
        display:flex;
        margin-bottom:22px;
        label{
            width:120px;
            padding-right:12px;
            text-align:right;
        }
    }
    .editor-wrap{
        flex:1;
    }
    .dialog-footer-center{
        // margin-top:20px;
        text-align:center;
    }
</style>