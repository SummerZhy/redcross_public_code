<template>
  <div class="dashboard_container">
    <div class="dashboard_top">
      <div class="configuration">
        <div class="statistics">
          <el-row :gutter="10">
            <el-col :xs="20" :sm="20" :md="21" :lg="21" :xl="21">
              <el-form ref="form" :model="form" :rules="rules" label-width="100px">
              <el-row :gutter="10">
                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <el-form-item label="会员名称：" prop="memberName">
                  <el-input style="width:210px;" v-model="form.memberName" placeholder="请输入内容"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <el-form-item label="所属部门：" prop="deptment">
                    <el-select v-model="form.deptment" placeholder="请选择">
                      <el-option
                          v-for="item in deptmentOptions"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <el-form-item label="会员状态：" prop="memberStatus">
                    <el-select v-model="form.memberStatus" placeholder="请选择">
                      <el-option
                          v-for="item in memberStatusOptions"
                          :key="item.value"
                          :label="item.label"
                          :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                  <el-form-item label="联系方式：" prop="contact">
                    <el-input style="width:210px;" v-model="form.contact" placeholder="请输入内容"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            </el-col>
            <el-col :xs="4" :sm="4" :md="3" :lg="3" :xl="3">
              <el-row  :gutter="10">
                <el-col  :xs="24" :sm="24" :md="24" :lg="24" :xl="24">
                    <el-button style="width:90px;float:right;margin-right:10px;" type="primary" :loading="queryLoading" @click="queryList">查询</el-button>
                </el-col>
                <el-col style="margin-top: 23px;" :sm="24" :md="24" :lg="24" :xl="24">
                    <el-button style="width:90px;float:right;margin-right:10px;" type="" @click="reset">重置</el-button>
                </el-col>
              </el-row>
            </el-col>
          </el-row>

        </div>
        <div class="common_menu">
          <div class="tittle">
            <span class="">工会会员列表</span>
            <div class="btns">
              <el-button style="width:90px;" type="primary"  @click="handlePop('add')">新增</el-button>
              <el-button style="width:90px;" type="" @click="handleImport">批量导入</el-button>
              <el-button style="width:90px;" type=""  @click="handlePop('edit')">修改</el-button>
              <el-button style="width:90px;" type="">删除</el-button>
            </div>
          </div>
          <div class="content">
            <el-table
                :data="tableData"
                border
                :header-cell-style="tableHeadColor"
                :row-key="getRowKey"
                @selection-change="handleSelectionChange"
                @row-click="handlePop('detail')"
                style="width: 100%">
              <el-table-column
                  header-align="center"
                  align="center"
                  :reserve-selection="true"
                  type="selection"
                  width="55">
              </el-table-column>
              <el-table-column
                  type="index"
                  header-align="center"
                  align="center"
                  label="序号"
                  width="60">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="会员名称"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="性别"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="联系方式"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="所属部门"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="职位"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="会员状态"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="操作人"
                  width="180">
              </el-table-column>
              <el-table-column
                  header-align="center"
                  align="center"
                  prop="name"
                  label="操作时间"
                  width="180">
              </el-table-column>

            </el-table>
          </div>
          <div class="paginator" >
            <el-pagination style="float:right;"
                @size-change="pageSizeChange"
                @current-change="pageCurrentChange"
                :current-page.sync="currentPage"
                :page-sizes="[5, 10, 20, 100]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNumber"
            ></el-pagination>
          </div>
        </div>


      </div>
      <!--新增 编辑 修改 弹框-->
      <el-dialog :title="dialogTitle" :visible.sync="dialogFormVisible" width="800">
        <el-form ref="dialogForm" :model="dialogForm" :rules="dialogRules" label-width="120px">
          <el-row :gutter="10">
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="会员姓名：" prop="userName" >
                <el-input style="width:210px;" v-model="dialogForm.userName" :disabled="cantEdit"></el-input>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="统一认证号：" prop="checkNo" >
                <el-input style="width:210px;" v-model="dialogForm.checkNo" :disabled="cantEdit"></el-input>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="性别" prop="gender">
                <el-radio-group v-model="dialogForm.gender" :disabled="cantEdit">
                  <el-radio :label="1">男</el-radio>
                  <el-radio :label="2">女</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="联系方式：" prop="phone">
                <el-input style="width:210px;" v-model="dialogForm.phone" :disabled="cantEdit"></el-input>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="所属部门：" prop="deptNo">
                <el-select style="width:210px;" v-model="dialogForm.deptNo" placeholder="请选择" :disabled="cantEdit">
                  <el-option
                      v-for="item in deptmentOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="职位：" prop="position" >
                <el-select style="width:210px;" v-model="dialogForm.position" placeholder="请选择" :disabled="cantEdit">
                  <el-option
                      v-for="item in positionOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="联系地址：" prop="address">
                <el-input :disabled="cantEdit" style="width:210px;" v-model="dialogForm.address" ></el-input>
              </el-form-item>
            </el-col>
            <el-col :xs="12" :sm="12" :md="12" :lg="12" :xl="12">
              <el-form-item label="会员状态：" prop="status">
                <el-select style="width:210px;" v-model="dialogForm.status" placeholder="请选择" :disabled="cantEdit">
                  <el-option
                      v-for="item in memberStatusOptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>

          </el-row>
          <el-row style="display: flex;align-items:center;justify-content:center; margin-top: 30px;">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer" type="flex" justify="center">

        </div>
      </el-dialog>
      <!--批量导入dialog-->
      <el-dialog title="批量导入会员" :visible.sync="dialogImport">
        <p style="font-size: 16px;color:#C8424B;">温馨提示：</p>
        <p>1、请点击下载模板： <el-button type="info" plain>下载模板</el-button></p>
        <p>2、请选择需要导入的文件： <el-button type="info" plain>上传文件</el-button></p>

        <div slot="footer" style="display: flex;align-items:center;justify-content:center; margin-top: 10px;" >
          <el-button @click="dialogImport = false">提 交</el-button>
          <el-button type="primary" @click="dialogImport = false">取 消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { default as myApi } from "./server";
export default {
  name: "dashboard",
  data() {
    return {

      currentPage:1,
      pagesize:10,
      totalNumber: 9,
      tableData: [{
        id:1,
        date: '2016-05-02',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        id:2,
        date: '2016-05-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        id:3,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:4,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:5,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:6,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:7,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:8,
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        id:9,
        date: '2016-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }],
      tableHeadColor:{
        backgroundColor:'#f5f7fa'
      },
      form: {
        memberName:'',
        memberStatus:0,
        deptment:0,
        contact:''
      },
      rules: {
        name: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
      },
      memberStatusOptions:[
        {
          value: 0,
          label: '全部'
        }, {
          value: 1,
          label: '启用'
        }, {
          value: 2,
          label: '停用'
        }
      ],
      deptmentOptions:[
        {
          value: 0,
          label: '全部'
        }, {
          value: 1,
          label: '技术一部'
        }, {
          value: 2,
          label: '技术二部'
        },
      ],
      positionOptions:[
        {
          value: 0,
          label: '普通员工'
        }, {
          value: 1,
          label: '技术一部'
        }, {
          value: 2,
          label: '技术二部'
        },
      ],
      queryLoading:false,
      dialogFormVisible:false,
      dialogForm:{
        userName:'张三',
        checkNo:'技术部',
        gender:1,
        phone:'13266668888',
        deptNo:0,
        position:0,
        address:'北京朝阳区天圆祥泰',
        status:0,
      },
      dialogTitle:'',
      dialogRules: {
        userName: [
          { required: true, message: '请输入姓名', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        checkNo: [
          { required: true, message: '请输入统一认证号', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        gender: [
          { required: true, message: '请选择性别', trigger: 'change' }
        ],
        phone: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
        ],
        deptNo: [
          { required: true, message: '请选择所属部门', trigger: 'change' },
        ],

      },
      cantEdit:false,
      dialogImport:false,
    };
  },
  created() {

  },
  watch: {

  },
  methods: {
//    //1.日历列表查询
//    getCalendar() {
//      myApi.getCalendar().then(res => {
//        if (res.retCode == "0") {
//          this.datelist = res.result.list;
//        } else {
//          this.$message.closeAll();
//          this.$message({
//            type: "warning",
//            content: res.retMsg
//          });
//        }
//      });
//    },
    // 分页多选必须代码
    getRowKey(row){
            return row.id
    },
    handleSelectionChange(val){

    },
    // 查询列表数据
    queryList(){
      this.queryLoading = true;
    },
    // 重置表单数据
    reset(){
      this.queryLoading = false;
      this.$refs['form'].resetFields();
    },
    // 打开弹窗
    handlePop(flag){
      if(flag == 'add'){
        this.dialogFormVisible = true;
        this.dialogTitle = '新增会员信息';
        this.cantEdit = false;
        this.dialogForm = {
            userName:'',
              checkNo:'',
              gender:1,
              phone:'',
              deptNo:0,
              position:0,
              address:'',
              status:0,
        }
      }else if(flag == 'edit'){
        this.dialogFormVisible = true;
        this.dialogTitle = '编辑会员信息';
        this.cantEdit = false;

      }else{
        this.dialogFormVisible = true;
        this.dialogTitle = '会员详情';
        this.cantEdit = true;

      }
    },
    // 处理导入会员
    handleImport(){
      this.dialogImport=true;
    },

    pageSizeChange(val) {
//      this.dataForm.limit = val;
//      this.dataForm.currentPage = 1;
//      this.getPosition();
    },
    pageCurrentChange(val) {
//      this.dataForm.currentPage = val;
//      this.getPosition();
    },

  },
  components: {

  }
};
</script>
<style lang="scss" scoped>
$gray: #ebeef5;
.dashboard_container {
  width: 100%;
  min-width: 1200px;
  padding-bottom:20px;
  .dashboard_top {
    height: 100%;
    position: relative;
    .calendar {
      display: inline-block;
      width: 33.4%;
      height: 100%;
      position: relative;
      border: 1px solid #ccc;
      padding: 5px;
      overflow: hidden;
      .calendar_top {
        position: absolute;
        width: 100%;
        top: 0;
        left: 0;
        height: 40px;
        z-index: 10;
        background-color: $gray;
        .title {
          position: absolute;
          left: 10px;
          top: 10px;
          line-height: 20px;
          font-size: 14px;
          .icon {
            display: inline-block;
            width: 15px;
            height: 15px;
            background-color: #ddd;
            vertical-align: text-bottom;
          }
        }
        .menu {
          display: inline-block;
          float: right;
          margin-top: 10px;
          margin-right: 15px;
          width: 20px;
          height: 20px;
          background-color: #ddd;
          cursor: pointer;
        }
      }
      .calendar_main {
        height: 100%;
        padding-top: 40px;
        overflow-y: auto;
        .calendar_cont {
          background-color: #fff;
        }
        .task {
          padding: 10px;
          font-size: 12px;
          line-height: 20px;
          p {
            height: 20px;
            background-color: #ccc;
            &.a {
              width: 100px;
            }
            &.b {
              width: 200px;
            }
          }
        }
      }
    }
    .configuration {
      margin-left: 0px;
      position: absolute;
      margin-bottom:56px;
      /*left: calc(33.4%);*/
      left: 0;
      top: 0;
      width: 100%;
      /*height: 100%;*/
      .statistics {
        padding-top: 20px;
        /*height: 32%;*/
        border: 1px solid #ccc;
        .filter {
          padding-top: 10px;
          padding-left: 10px;
          .el-select {
            margin-left: 10px;
          }
          .el-checkbox {
            margin-left: 10px;
          }
        }
        .content {
          padding: 40px;
          .item {
            width: 33%;
            display: inline-block;
          }
        }
      }
      .common_menu {
        /*height: calc(40% - 10px);*/
        margin-top: 10px;
        border: 1px solid #ccc;
        .tittle {
          height: 56px;
          padding-left: 10px;
          border-bottom: 1 solid $gray;
          line-height: 56px;
          font-size: 16px;
          color: #333;
          border-bottom: 1px solid $gray;
          .btns{
            float: right;
            margin-right: 10px;
            display: inline-block;
          }
        }
        .content {
          padding-left: 10px;
          padding-top: 10px;
        }
        .paginator {
          height:40px;
          width:100%;
          padding-right: 10px;
          padding-top: 10px;
          display: inline-block;
        }
      }
    }
  }
  .dashboard_tab {
    width: 100%;
    margin-top: 10px;
    min-height: 200px;
    padding: 0 20px;
    border: 1px solid #ccc;
    .paginator {
      height:40px;
      padding-top: 10px;
      display: inline-block;
    }
  }
}
.textLabel{
  display: inline-block;
}
  .tableHeadColor{
    background-color: #ddd;
  }
</style>

