<template>
  <div class="content">
    <positionItem v-for='item in data' 
      :key='item.id' 
      @positionClick='itemClick'
      :data='item'> 
    </positionItem>
  </div>
</template>
<script>
import positionItem from './components/positionItem';
export default {
  props:['data'],
  data(){
    return{
      test:'123456'
    }
  },
  methods:{
    itemClick(val){
      this.$emit('positionId',val)
    }
  },
  components:{
    positionItem,
  }
}
</script>
<style lang="scss" scoped>
  .content{
    padding: 10px;
  }
</style>
