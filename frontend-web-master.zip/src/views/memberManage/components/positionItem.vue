<template>
  <div class="position_cont" @click="positionClick(data.positionId)">
    <div class="tittle">
      <span class="des">{{data.positionName}}</span>
      <span class="icon"></span>
    </div>
    <div class="content">
      <span>{{data.typeString}}</span>
      <span class="line"></span>
      <span>{{data.workPlace}}</span>
      <span class="line"></span>
      <span>{{data.number}}人</span>
      <span class="line"></span>
      <span>{{data.updateTime}}</span>
    </div>
  </div>
</template>
<script>
export default {
  props: ["data"],
  methods: {
    positionClick(id){
      this.$emit('positionClick',id);
    }
  }
};
</script>
<style lang="scss" scoped>
.position_cont {
  margin: 10px;
  display: inline-block;
  width: calc(25% - 20px);
  height: 100px;
  padding:10px 20px;
  box-sizing: border-box;
  border: 1px solid #ddd;
  &:hover {
    cursor: pointer;
    box-shadow: 2px 2px 3px #ccc;
  }
  .tittle {
    position: relative;
    height: 40px;
    .des {
      font-size: 16px;
      font-weight: bold;
      line-height: 40px;
      color: #333;
      display: inline-block;
      overflow:hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      width: 90%;
    }
    .icon{
      position:absolute;
      top: 12px;
      right: 0px;
      width: 15px;
      height: 15px;
      background-color: red;
    }
  }
  .content {
    padding-top: 10px;
    font-size: 12px;
    color: #666;
    span{
      margin-right:5px;
    }
    span.line{
      height: 20px;
      border-left: 1px solid #666;
    }
  }
}
</style>

