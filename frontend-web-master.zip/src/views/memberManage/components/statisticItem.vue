<template>
  <div class="statisticItem">
    <div class="tittle">{{label}}</div>
    <div class="content">{{num}}</div>
  </div>
</template>
<script>
export default {
  props:['num','label']
}
</script>
<style lang="scss" scoped>
  .statisticItem{
    padding-bottom: 20px;
    .tittle{
      font-size:16px;
      line-height: 20px;
      color:rgba(0, 0,0,0.65);
    }
    .content{
      font-size: 32px;
      line-height: 40px;
      font-weight: bold;
    }
  }
</style>


