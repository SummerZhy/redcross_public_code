import {
  get,
  getResponse,
  post,
  postResponse,
  put,
  patch,
  del
} from '@/utils/http'
export default {
  //接口
  //1.获取招聘类型字典表
  getRecruitmentType:function(param){
    return get('/recruitment/parameter/dict', param);
  },
  //2.获取当前系统的招聘项目
  getRecruitments:function(param){
    return get('/parameter/require/project/list/v1', param);
  },
  //3.统计指标查询
  getStatistics:function(param){
    return get('/recruitment/dashboard/statistics',param);
  },
  //3.日历列表查询
  getCalendar:function(param){
    return get('/recruitment/dashboard/calendar',param);
  },
  //4.指定日期任务列表查询
  getTask:function(param){
    return get('/recruitment/dashboard/task',param);
  },
  //5.在招职位查询
  getPosition:function(param){
    return get('/recruitment/dashboard/position',param);
  },
  //6.动态信息查询----(一期项目不做)
  getInfomation:function(){
    return get('/recruitment/dashboard/infomation',param);
  }

}