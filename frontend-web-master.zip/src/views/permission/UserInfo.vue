<template>
  <div class="main-con">
    <section class="wrap-class">
      <title-style>用户详细信息</title-style>
      <div class="user-info-wrap">
        <ul class="user-info-left">
          <li><label>用户编码:</label><span>{{formData.userId}}</span></li>
          <li><label>所属机构:</label><span>{{formData.branchName}}</span></li>
          <li><label>电话:</label><span>{{formData.mobilePhone}}</span></li>
          <li><label>修改用户:</label><span>{{formData.lstModiUserName}}</span></li>
          <li><label>用户状态:</label><span>{{formData.statusName == '解冻' ? '正常':formData.statusName}}</span></li>
        </ul>
        <ul class="user-info-right">
          <li><label>用户名称:</label><span>{{formData.userName}}</span></li>
          <li><label>用户默认角色:</label><span>{{formData.roleName}}</span></li>
<!--          <li><label>用户操作权限:</label><span>formData.</span></li>-->
          <li><label>E-mail:</label><span>{{formData.mail}}</span></li>
          <li><label>修改日期:</label><span>{{formData.lstModiTime}}</span></li>
        </ul>
      </div>
    </section>
    <section class="wrap-class fun-menu-wrap">
      <title-style>功能菜单</title-style>
      <div class="fun-menu-wrap-con">
        <el-form ref="form"  label-width="130px" label-position="left">
          <el-form-item label="请选择相应角色：">
            <el-select v-model="checkedRoleId" placeholder="请选择活动区域" @change="changeRole">
              <el-option v-for="item in formData.roles" :label="item.roleName" :value="item.roleId" :key="item.roleId"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <section class="menu-list-wrap">
          <div class="title-tip">
            <section>功能菜单名称</section>
            <section>
             <!-- <span>展开全部</span>
              <span>收起全部</span>-->
            </section>
          </div>
          <el-tree :data="data" :props="defaultProps"></el-tree>
        </section>
      </div>
      <section class="com-btn-wrap-center">
        <el-button type="danger" @click="close" size="small" class="button">关闭</el-button>
      </section>
    </section>

  </div>
</template>

<script>
  export default{
    data(){
      return {
        id:this.$route.query.id,
        formData:{
          branchId:'',
          branchName:'',
          departmentName:'',
          department_id:'',
          lstModiTime:'',
          lstModiUserName:'',
          mail:'',
          mobilePhone:'',
          roleId:'',
          roles:[],
          status:'',
          statusName:'',
          userId:'',
          userName:'',
        },
        checkedRoleId:'',
        data:[
          {
            label: '一级 1',
            children: [{
              label: '二级 1-1',
            }]
          },
          {
            label: '一级 1',
            children: [{
              label: '二级 1-1',
            }]
          }
        ],
        defaultProps: {
          children: 'children',
          label: 'menuChinaName'
        }
      }
    },
    created(){
      this.queryDetail();
    },
    methods:{
      //查询详情
      queryDetail(){
        let params = {
          userId:this.id
        }
        this.$api.myApi.permission.userInfoGet(params)
          .then( res => {
            if(res.retCode == 0){
              this.formData = res.result;
              this.checkedRoleId = res.result.roleId;
              this.queryMenu(res.result.roleId);
            }else{
              this.$message.error(res.retMsg);
            }
          })
      },
      //根据角色id查询功能菜单
      queryMenu(roleId){
        let params = {
          id:roleId
        }
        this.$api.myApi.role.roleInfoGet(params)
          .then( res => {
            if(res.retCode == 0){
              this.data = res.result.menus;
            }else{
              this.$message.error(res.retMsg);
            }
          })
      },
      //change角色时
      changeRole(val){
        //console.log(val)
        this.queryMenu(val);
      },
      //关闭
      close(){
        this.$router.push('/permission/user-management');
      }
    },
  }
</script>

<style lang="scss" scoped>
  .user-info-wrap{
    display:flex;
    padding:20px 30px 4px 30px;
    .user-info-left{
      margin-right:350px;
    }
    >ul{
      li{
        padding-bottom:16px;
        label{
          display:inline-block;
          width:90px;
        }
      }
    }
  }
  .fun-menu-wrap{
    margin:10px 0 20px;
  }
  .fun-menu-wrap-con{
    padding:20px 30px;
  }
  .menu-list-wrap{
    border: 1px solid #DCDFE6;
    border-radius: 4px;
    .title-tip{
      height:44px;
      line-height:44px;
      padding:0 15px;
      background: rgba(237,241,242,0.50);
      display:flex;
      justify-content: space-between;
      border-bottom: 1px solid #DCDFE6;
    }
  }
  .button{
    width: 73px;
    height: 32px;
    padding: 6px 20px;
  }
  .com-btn-wrap-center{
    padding-bottom: 30px;
  }
</style>
