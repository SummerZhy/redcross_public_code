<template>
  <div class="main-con">
    <common-list
      :commonListConfig="commonListConfig"
      :condition.sync="condition"
      :tableData="tableData"
      @pageChanged="pageChanged"
      @queryClicked="getUserList"
      @rowCheckChanged="rowCheckChanged"
    >

      <!-- 独立插槽-顶部 -->
      <template #head>
      </template>

      <!-- 条件插槽 -->
      <template #beforeConditions>
      </template>
      <template #afterConditions>
        <el-form-item label="性别">
          <el-select
            v-model="condition.gender"
            placeholder="请选择性别"
          >
            <el-option
              label="男"
              value="01"
            ></el-option>
            <el-option
              label="女"
              value="02"
            ></el-option>
          </el-select>
        </el-form-item>
      </template>
      <template #beforeBtnSearch>
      </template>
      <template #afterBtnSearch>
      </template>

      <!-- 独立插槽-条件和表格中间 -->
      <template #center>
      </template>

      <!-- 表格插槽 -->
      <template #beforeTable>
        <section class="com-operation-left">
          <el-button
            size="mini"
            @click="exportSelect"
          >导出选项</el-button>
          <el-button
            size="mini"
            @click="exportAll"
          >导出全部</el-button>
        </section>
        <section class="com-operation-right">
          <span @click="toAdd">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>新增
          </span>
          <span @click="refresh">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>刷新
          </span>
          <span @click="changeUserStatus(2)">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>冻结
          </span>
          <span @click="changeUserStatus(1)">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>解冻
          </span>
          <span @click="delUsers">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>删除
          </span>
        </section>
      </template>
      <template #columnsBefore>
      </template>
      <template #columnsAfter>
      </template>
      <template #afterTable>
      </template>
      <template #beforePagination>
      </template>
      <template #afterPagination>
      </template>

      <!-- 独立插槽-底部 -->
      <template #tail>
      </template>
    </common-list>
  </div>
</template>

<script>
import CommonList from "@/components/CommonBusiness/CommonList";

export default {
  name: "UserManagement",
  components: { CommonList },
  data() {
    return {
      inline: true,
      currentTab: "x",
      condition: {
        page: 1,
        limit: 10,
        total: 0
      },
      commonListConfig: {
        // 查询条件设置
        condition: {
          noCondition: false,
          noSearchBtn: false,
          searchBtnConf: { text: "查询" },
          formSettings: {},
          conditions: [
            {
              label: "所属机构",
              key: "departmentId",
              placeholder: "请选择活动区域",
              type: "select",
              selections: [
                { label: "上海", value: "shanghai" },
                { label: "北京", value: "beijing" }
              ]
            },
            {
              label: "关键字",
              key: "search",
              placeholder: "",
              type: "input"
            }
          ]
        },

        // 表格设置
        table: {
          dataGetter: this.$api.myApi.permission.getUerList,
          // data: this.tableData,
          conf: {},
          columns: [
            { width: "55", type: "selection", reserveSelection: true },
            { width: "70px", align: "center", label: "序号", isIndex: true },
            {
              width: "180",
              label: "用户编码",
              key: "userId",
              action: this.toDetail,
              class: "com-click-class"
            },
            { width: "180", label: "用户名称", prop: "userName" },
            { label: "所属机构", prop: "branchName" },
            { label: "所属部门", prop: "departmentName" },
            { width: "120", label: "用户默认角色", prop: "roleName" },
            { label: "用户状态", prop: "status" },
            {
              label: "操作",
              align: "center",
              isActions: true,
              actions: [{ label: "修改", action: this.toEdit }]
            }
          ]
        },

        //
        pagination: {
          conf: {
            layout: "total, prev, pager, next, jumper"
          },
          data: {}
        }
      },
      queryForm: {
        currentPage: 1,
        limit: 10,
        departmentId: "",
        search: ""
      },
      getRowKey(row) {
        return row.userId;
      },
      totalNum: 0,
      tableData: [],
      rowCheckedList: [],
      checkList: ""
    };
  },
  created() {
    this.getUserList();
  },
  methods: {
    pageChanged() {
      this.getUserList();
    },
    rowCheckChanged(value) {
      this.rowCheckedList = value;
    },
    toAdd() {
      this.$router.push("/permission/user-add");
    },
    toDetail(userId) {
      this.$router.push({
        path: "/permission/user-info",
        query: {
          id: userId
        }
      });
    },
    toEdit(row) {
      this.$router.push({
        path: "/permission/user-add",
        query: {
          id: row.userId
        }
      });
    },
    //机构列表
    //用户管理列表
    getUserList() {
      // debugger;
      // this.$api.myApi.permission.getUerList(this.queryForm).then(res => {
      //   if (res.retCode == 0) {
      //     // console.log("res.result :", res.result);
      //     this.totalNum = res.result.totalNum;
      //     this.commonListConfig.table.data = res.result.list;
      //     // FAKE 假数据，增加页码数
      //     this.condition.total =
      //       parseInt(res.result.totalNum) * Math.floor(Math.random() * 20 + 5);
      //   } else {
      //     this.$message.error(res.retMsg);
      //   }
      // });
    },
    //查询
    querySearch() {
      this.queryForm.currentPage = 1;
      this.getUserList();
    },
    //表格序号
    getIndex($index) {
      return (
        (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
      );
    },
    //table多选框改变
    handleSelectionChange(val) {
      let arr = val.map(item => {
        return item.userId;
      });
      this.checkList = arr.toString();
    },
    //刷新
    refresh() {
      this.checkList = "";
      this.$refs.multipleTable.clearSelection();
      this.queryForm = {
        currentPage: 1,
        limit: 10,
        departmentId: "",
        search: ""
      };
      this.getUserList();
    },
    //冻结、解冻、删除后要执行的方法
    funAfter() {
      this.checkList = "";
      this.$refs.multipleTable.clearSelection();
      this.queryForm.currentPage = 1;
      this.getUserList();
    },
    //改变用户状态（冻结、解冻）
    changeUserStatus(status) {
      if (!this.checkList || this.checkList == "") {
        this.$message.warning("请选择用户");
        return;
      }
      let params = {
        userId: this.checkList,
        status: status //1：解冻 2：冻结
      };
      this.$api.myApi.permission.userStatusPut(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
          this.funAfter();
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //删除
    delUsers() {
      if (!this.checkList || this.checkList == "") {
        this.$message.warning("请选择用户");
        return;
      }
      let params = {
        userId: this.checkList
      };
      this.$api.myApi.permission.userStatusPut(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
          this.funAfter();
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //导出全部
    exportAll() {
      let params = {
        departmentId: this.queryForm.departmentId,
        search: this.queryForm.search
      };
      this.$api.myApi.permission.uerAllExport(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //导出选项
    exportSelect() {
      // if(!this.checkList || this.checkList == ''){
      //   this.$message.warning('请选择用户');
      //   return
      // }
      let params = {
        // userIds: this.checkList
        userIds: "chenf"
      };
      this.$api.myApi.permission.uerExport(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
        } else {
          this.$message.error(res.retMsg);
        }
      });
    }
  }
};
</script>

<style lang="scss">
.search-wrap {
  padding: 20px 30px;
  margin-bottom: 10px;
  .el-form--inline .el-form-item {
    margin-right: 30px;
  }
  .el-form-item {
    margin-bottom: 0;
  }
}
.con-list {
  padding: 0 30px;
}
</style>
