<template>
  <div class="main-con">
    <common-list
      ref="commonList"
      :commonListConfig="commonListConfig"
      :condition.sync="condition"
      @rowCheckChanged="rowCheckChanged"
    >

      <!-- 表格插槽 -->
      <template #beforeTable>
        <section class="com-operation-left">
          <el-button
            size="mini"
            @click="exportSelect"
          >导出选项</el-button>
          <el-button
            size="mini"
            @click="exportAll"
          >导出全部</el-button>
        </section>
        <section class="com-operation-right">
          <span @click="routePush('/permission/user-add')">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>新增
          </span>
          <span @click="$refs.commonList.getPageData()">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>刷新
          </span>
          <span @click="changeUserStatus(2)">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>冻结
          </span>
          <span @click="changeUserStatus(1)">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>解冻
          </span>
          <span @click="delUsers">
            <svg-icon
              class="right-icon"
              icon-class="bell"
            ></svg-icon>删除
          </span>
        </section>
      </template>
    </common-list>
  </div>
</template>

<script>
import CommonList from "@/components/CommonBusiness/CommonList";

export default {
  name: "UserManagement",
  components: { CommonList },
  data() {
    return {
      condition: {
        page: 1,
        limit: 10,
        total: 0
      },
      commonListConfig: {
        // 查询条件设置
        condition: {
          noCondition: false,
          noSearchBtn: false,
          searchBtnConf: { text: "查询" },
          formSettings: {},
          conditions: [
            {
              label: "所属机构",
              key: "departmentId",
              placeholder: "请选择活动区域",
              type: "select",
              selections: [
                { label: "上海", value: "shanghai" },
                { label: "北京", value: "beijing" }
              ]
            },
            {
              label: "关键字",
              key: "search",
              placeholder: "",
              type: "input"
            }
          ]
        },

        // 表格设置
        table: {
          dataGetter: this.$api.myApi.permission.getUerList,
          // data: [],
          conf: {},
          columns: [
            { width: "55", type: "selection", reserveSelection: true },
            { width: "70px", align: "center", label: "序号", isIndex: true },
            {
              width: "180",
              label: "用户编码",
              action: this.toDetail,
              key: "userId",
              class: "com-click-class"
            },
            { width: "180", label: "用户名称", prop: "userName" },
            { label: "所属机构", prop: "branchName" },
            // { label: "所属部门", prop: "departmentName" },
            { width: "120", label: "用户默认角色", prop: "roleName" },
            { label: "用户状态", prop: "status" },
            {
              label: "操作",
              align: "center",
              isActions: true,
              actions: [{ label: "修改", action: this.toEdit }]
            }
          ]
        },

        //
        pagination: {
          conf: {
            layout: "total, prev, pager, next, jumper"
          }
        }
      },
      rowCheckedList: [],
      checkList: ""
    };
  },
  created() {},
  methods: {
    routePush(path, query) {
      this.$router.push({ path, query });
    },
    toDetail(row) {
      this.routePush("/permission/user-info", {
        id: row.userId
      });
    },
    toEdit(row) {
      this.routePush("/permission/user-add", {
        id: row.userId
      });
    },
    //table多选框改变
    rowCheckChanged(val) {
      let arr = val.map(item => {
        return item.userId;
      });
      this.checkList = arr.toString();
    },
    //冻结、解冻、删除后要执行的方法
    funAfter() {
      this.checkList = "";
      this.$refs.multipleTable.clearSelection();
      this.queryForm.currentPage = 1;
      this.getUserList();
    },
    //改变用户状态（冻结、解冻）
    changeUserStatus(status) {
      if (!this.checkList || this.checkList == "") {
        this.$message.warning("请选择用户");
        return;
      }
      let params = {
        userId: this.checkList,
        status: status //1：解冻 2：冻结
      };
      this.$api.myApi.permission.userStatusPut(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
          this.funAfter();
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //删除
    delUsers() {
      if (!this.checkList || this.checkList == "") {
        this.$message.warning("请选择用户");
        return;
      }
      let params = {
        userId: this.checkList
      };
      this.$api.myApi.permission.userStatusPut(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
          this.funAfter();
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //导出全部
    exportAll() {
      let params = {
        departmentId: this.queryForm.departmentId,
        search: this.queryForm.search
      };
      this.$api.myApi.permission.uerAllExport(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
        } else {
          this.$message.error(res.retMsg);
        }
      });
    },
    //导出选项
    exportSelect() {
      // if(!this.checkList || this.checkList == ''){
      //   this.$message.warning('请选择用户');
      //   return
      // }
      let params = {
        // userIds: this.checkList
        userIds: "chenf"
      };
      this.$api.myApi.permission.uerExport(params).then(res => {
        if (res.retCode == 0) {
          this.$message.success(res.retMsg);
        } else {
          this.$message.error(res.retMsg);
        }
      });
    }
  }
};
</script>

<style lang="scss">
.search-wrap {
  padding: 20px 30px;
  margin-bottom: 10px;
  .el-form--inline .el-form-item {
    margin-right: 30px;
  }
  .el-form-item {
    margin-bottom: 0;
  }
}
.con-list {
  padding: 0 30px;
}
</style>
