<template>
    
</template>

<script>
    export default {
        name: "InformationSettings"
    }
</script>

<style scoped>

</style>