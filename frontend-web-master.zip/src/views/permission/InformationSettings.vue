<template>
    <div>
        <el-row>
            <el-col :span="10" :offset="6">
                <h3>信息公示生效模式设置</h3>
                <el-form size="small"  class="wrap-class search-wrap">
                    <el-form-item label="款项生效模式设置：" label-position="right">
                        <el-select v-model="queryForm.fundEffectType" placeholder="请选择">
                            <el-option
                                    v-for="item in effectiveModeSet"
                                    :key="item.paramId"
                                    :label="item.paramName"
                                    :value="item.paramId">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="评论生效模式设置：">
                        <el-select v-model="queryForm.evaluationEffectType" placeholder="请选择">
                            <el-option
                                    v-for="item in effectiveModeSet"
                                    :key="item.paramId"
                                    :label="item.paramName"
                                    :value="item.paramId">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-divider></el-divider>
                    <el-button type="info" size="small">取消</el-button>
                    <el-button type="danger" size="small" @click="setEven">确定</el-button>
                </el-form>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    export default {
        name: "InformationSettings",
        data(){
            return{
                queryForm:{
                    fundEffectType:'',//款项
                    evaluationEffectType:'',//评论
                },
            }
        },
        computed:{
            ...mapGetters('dictionary', [
              'effectiveModeSet'
            ]),
        },
        created(){

        },

        methods:{
            //设置事件
            setEven(){
                this.$confirm('是否设置?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() =>{
                this.$api.myApi.moneyHandling.paramInfoPut(this.queryForm)
                    .then( res => {
                        if(res.retCode == 0){
                            this.$message.success(res.retMsg)
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消操作'
                    });
                });
            },
        }
    }
</script>

<style scoped>
</style>