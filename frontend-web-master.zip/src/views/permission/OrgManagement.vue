<template>
  <div class="main-con">
   <!-- <el-form class="wrap-class search-wrap"  ref="form" :model="queryForm" label-width="90px" :inline="true" label-position="left" size="mini">
      <el-form-item label="所属机构">
        <el-select v-model="queryForm.search" placeholder="请选择所属机构">
          <el-option label="区域一" value="shanghai"></el-option>
          <el-option label="区域二" value="beijing"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="机构编号">
        <el-input v-model="queryForm.branchId"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="danger" @click="getSearchList">查询</el-button>
      </el-form-item>
    </el-form>-->
    <section class="wrap-class">
      <div class="com-operation-div">
        <section class="com-operation-left">
          <div></div>
        </section>
        <section class="com-operation-right">
         <!-- <span @click=""><svg-icon class="right-icon" icon-class="bell"></svg-icon>新增</span>
          <span @click=""><svg-icon class="right-icon" icon-class="bell"></svg-icon>删除</span>-->
          <span @click="toAdd"><svg-icon class="right-icon" icon-class="add"></svg-icon>新增</span>
        </section>
      </div>
      <div class="list" style="padding: 0 30px 20px 30px">
        <tree-table :data="objectList"
                    :columns="columns"
                    height="calc(100vh - 220px)"
                    element-loading-text="加载中"
                    @load-data=""
                    @destroy-data=""
                    :expandAll="true"
                    :size="size"
                   >
          <template slot-scope="scope">
            <el-table-column label="机构/部门名称" prop="name">
              <template slot-scope="scope">
                <span class="link-type" @click="toOrgInfo(scope.row.branchId)">{{ scope.row.name }}</span>
              </template>
            </el-table-column>
            <el-table-column label="所属机构" prop="branchName">
              <template slot-scope="scope">
                <span>{{ scope.row.branchName }}</span>
              </template>
            </el-table-column>
            <el-table-column label="机构/部门" prop="branchName" align="center" width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.type == 2 ? "部门" : "机构" }}</span>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="150" align="center">
              <template slot-scope="scope">
                <el-button-group>
                  <el-button type="text" title="修改" size="mini" @click="toEdit(scope.row.branchId,'goEdit')">修改</el-button>
                  <!--<el-button type="text" title="新增" size="mini" @click="toAdd(scope.row)" style="margin:0 5px">新增</el-button>-->
                  <el-button type="text" title="删除" size="mini" @click="handleDelete(scope.row)" style="margin-left: 5px" :disabled="scope.row.type == 2 ? false:true">删除</el-button>
                </el-button-group>
              </template>
            </el-table-column>
          </template>
        </tree-table>
      </div>
    </section>
  </div>
</template>

<script>
  import treeTable from '@/components/TreeTable' //封装树
  import treeToArray from './customEval' //数据转换
  import validator from '@/utils/validator'  //验证

  export default {
      name: "OrgManagement",
      components: {treeTable},
      data() {
        return {
          tabData:[],
          objectList:[],//处理数据
          func: treeToArray,
          expandAll: false,
          queryForm: {
            branchId:'',
            search:''
          },
          columns: [
            {
              text: '机构编号',
              value: 'branchId',
            },
          ],
          dialogStatus: '',
          dialogFormVisible: false,
          textMap: {
            update: '修改',
            create: '新增',
            detail: '详情'
          },
          rules: {
            branchName: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.branchName, trigger: 'blur'}
            ],
            branchShortname: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.branchName, trigger: 'blur'}
            ],
            branchNameEn: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.branchNameEn, trigger: 'blur'}
            ],
            branchShortnameEn: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.branchNameEn, trigger: 'blur'}
            ],
            postcode: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.postcode, trigger: 'blur'}
            ],
            uniformSocialCreditCode: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.uniformSocialCreditCode, trigger: 'blur'}
            ],
            industry: [{required: true, message: '必填', trigger: 'blur'}],
            branchAttributeCode: [{required: true, message: '必填', trigger: 'blur'}],
            branchAttribute: [{required: true, message: '必填', trigger: 'blur'}],
            parentId: [{required: true, message: '必填', trigger: 'blur'}],
            corporation: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.cname, trigger: 'blur'}
            ],
            initialFunds: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.positiveInteger, trigger: 'blur'}
            ],
            weight: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.weight, trigger: 'blur'}
            ],
            phoneNumber: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.telphone, trigger: 'blur'}
            ],
            branchAddress: [
              {required: true, message: '必填', trigger: 'blur'},
              {validator: validator.branchAddress, trigger: 'blur'}
            ],
            memo: [
              {validator: validator.memo, trigger: 'blur'}
            ],
          },
          size: 'mini',
          children:[],
        }
      },
      created(){
        this.getList();
      },
      methods:{
        //去新增
        toAdd(){
          this.$router.push({
            path:'/permission/branch-add',
          })
        },
        //去修改
        toEdit(res,edit){
          this.$router.push({
            path:'/permission/branch-modify',
            query:{
              branchId:res,
              edit:'edit'
            }
          })
        },
        toOrgInfo(res){
          this.$router.push({
            path:'/permission/org-details',
            query:{
              branchId:res,
              edit:'edit'
            }
          })
        },
        //获取机构列表
        getList(){
          this.$api.myApi.permission.getMechanismList().then( res => {
            if(res.retCode == '0'){
              //debugger;
              this.objectList = [];
              this.tabData = res.result;
              let list = res.result.departmentList;
              let list1 = res.result.subBranchList;
              if(list1 == null){
                this.children = list;
                let obj = {};
                obj.name = this.tabData.name;
                obj.branchId = this.tabData.branchId;
                obj.branchName = this.tabData.branchName;
                obj.children = this.children;
                this.objectList.push(obj)
              };
              if(list == null){
                this.children = list1;
                let obj = {};
                obj.name = this.tabData.name;
                obj.branchId = this.tabData.branchId;
                obj.branchName = this.tabData.branchName;
                obj.children = this.children;
                this.objectList.push(obj)
              }
              if( list1 != null && list != null){
                this.children = list.concat(list1);
                let obj = {};
                obj.name = this.tabData.name;
                obj.branchId = this.tabData.branchId;
                obj.branchName = this.tabData.branchName;
                obj.children = this.children;
                this.objectList.push(obj)
              }
              if(list == null && list1 == null){
                this.objectList = [];
                let obj = {};
                obj.name = this.tabData.name;
                obj.branchId = this.tabData.branchId;
                obj.branchName = this.tabData.branchName;
                obj.children = this.children;
                this.objectList.push(obj)
              }
            }else{
              this.$message.error(res.retMsg);
            }
          })
        },
        //机构列表检索
        getSearchList(){
          this.$api.myApi.permission.getMechanismSearch(this.queryForm).then( res => {
            if(res.retCode == '0'){
              this.objectList = res.list;
            }else{
              this.$message.error(res.retMsg);
            }
          })
        },
        //列表删除
        handleDelete(row) {
          //console.log(row);
          let data = {branchId: row.branchId};
          this.$confirm('是否删除?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.getMechanismListDelete(data).then((res) => {
              if (res.retCode === '0') {
                this.$message({
                  type: 'success',
                  message: '删除成功!'
                });
                this.$nextTick(() => {
                  this.getList();
                })
              } else {
                this.$message({
                  message: res.retMsg,
                  type: 'warning'
                })
              }
            })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消删除'
            });
          });
        },
      }
    }
</script>

<style scoped lang="scss">
  .search-wrap{
    padding:20px 30px;
    margin-bottom:10px;
    .el-form--inline .el-form-item{
      margin-right:30px;
    }
    .el-form-item{
      margin-bottom:0;
    }
  }
  .con-list{
    padding:0 30px 30px 30px;
  }
 .list /deep/ .has-gutter{
    height: 32px;
  }
  .list /deep/ th{
    padding: 4px 0px;
  }
</style>
