<template>
    <div class="main-con">
      <el-form class="wrap-class search-wrap"  ref="form" :model="queryForm" label-width="90px" :inline="true" label-position="left" size="small">
        <el-form-item label="角色名称">
          <el-input v-model="queryForm.roleName" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="danger" @click="querySearch" size="small" >查询</el-button>
        </el-form-item>
      </el-form>
      <section class="wrap-class">
        <div class="com-operation-div">
          <section class="com-operation-right">
            <span @click="toAdd"><svg-icon class="right-icon" icon-class="add"></svg-icon>新增</span>
          </section>
        </div>
        <div class="con-list">
          <el-table
            ref="multipleTable"
            :data="tableData"
            style="width: 100%"
            >
            <el-table-column width="70px" align="center" label="序号">
              <template slot-scope="scope">
                <span v-text="getIndex(scope.$index)"></span>
              </template>
            </el-table-column>
            <el-table-column
              label="角色名称">
              <template slot-scope="scope"><span class="com-click-class" @click="toDetail(scope.row.roleId)">{{scope.row.roleName}}</span></template>
            </el-table-column>
            <el-table-column
              prop="description"
              label="角色描述">
            </el-table-column>
            <el-table-column
              label="操作">
              <template slot-scope="scope">
                <span class="com-click-class op-click-class" @click="toEdit(scope.row.roleId)">修改</span>
                <span class="com-click-class op-click-class" @click="delRole(scope.row.roleId)">删除</span>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            @current-change="getRoleList"
            :current-page.sync="queryForm.currentPage"
            :page-size="queryForm.limit"
            layout="total, prev, pager, next, jumper"
            :total="totalNum">
          </el-pagination>
        </div>
      </section>
    </div>
</template>

<script>
    export default {
        name: "RoleManagement",
      data(){
          return{
            queryForm:{
              roleName:'',
              currentPage:1,
              limit:10
            },
            tableData:[
              {userId:1,userName:2}
            ],
            totalNum:0,
          }
      },
      created(){
          this.getRoleList();
      },

      activated() {
        if (this.$route.meta.isBack) {
          this.$route.meta.isBack = false;
        } else {
          this.reset();
          this.fold = false;
        }
      },
      beforeRouteEnter(to, from, next) {
        if (from.path == '/permission/role-add' || from.path == '/permission/role-info' || from.path == '/permission/role-modify') {
          to.meta.isBack = true
        } else {
          to.meta.isBack = false
        }
        next()
      },
      methods:{
        toAdd(){
          this.$router.push('/permission/role-add');
        },
        toDetail(roleId){
          this.$router.push({
            path:'/permission/role-info',
            query:{
              roleId
            }
          })
        },
        toEdit(roleId){
          this.$router.push({
            path:'/permission/role-modify',
            query:{
              roleId
            }
          })
        },
        //表格序号
        getIndex($index) {
          return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
        },
        //角色列表
        getRoleList(){
          this.$api.myApi.role.getRoleList(this.queryForm).then( res => {
              if(res.retCode == 0){
                this.totalNum = res.result.totalNum;
                this.tableData = res.result.roles;
              }else{
                this.$message.error(res.retMsg);
              }
            })
        },
        //搜索
        querySearch(){
          this.queryForm.currentPage = 1;
          this.getRoleList();
        },
        //删除角色
        delRole(roleId){
          this.$confirm('确定删除？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
              let params = {
                roleId:roleId
              }
              this.$api.myApi.role.roleInfoDel(params).then( res => {
                  if(res.retCode == 0){
                    this.$message.success(res.retMsg);
                    this.queryForm.currentPage = 1;
                    this.getRoleList();
                  }else{
                    this.$message.error(res.retMsg);
                  }
                })
            })
        },
        //刷新
        reset(){
          this.queryForm.currentPage = 1;
          this.queryForm.limit = 10;
          this.queryForm.roleName= ''
        }
      }
    }
</script>

<style scoped lang="scss">
  .search-wrap{
    padding:20px 30px;
    margin-bottom:10px;
    .el-form--inline .el-form-item{
      margin-right:30px;
    }
    .el-form-item{
      margin-bottom:0;
    }
  }

  .op-click-class{
    margin-right:30px;
  }
</style>
