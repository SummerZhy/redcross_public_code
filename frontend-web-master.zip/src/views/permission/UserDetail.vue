<template>
  <div>
    <div class="filter-container">
      <el-row>
        <el-form ref="ruleForm"
                 :model="dataForm"
                 :rules="rules"
                 label-position="left"
                 label-width="120px"
                 size="mini"
                 inline>
          <el-col :span="24">
            <el-transfer
              filterable
              :titles="['待选角色','已选角色']"
              :filter-method="filterMethod"
              filter-placeholder="请输入角色"
              v-model="dataForm.roleList"
              :data="data">
            </el-transfer>
          </el-col>
        </el-form>
      </el-row>
      <br/>
      <div slot="footer" class="dialog-footer" style="text-align: center">
        <el-button  size="mini" v-if="dialogStatus=='create'" type="success" @click="roleAdd">新增</el-button>
        <el-button  size="mini" v-else-if="dialogStatus=='update'" type="success" @click="roleModify">修改</el-button>
        <!--<el-button @click="">取消</el-button>-->
      </div>
    </div>
  </div>
</template>

<script>
  import treeTransfer from 'el-tree-transfer' // 引入
  import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'

  export default {
    props: ['dialogStatus','userId'],
    inject: ['reload'],
    data(){
      return {
        rules: {
          roleName: [{required: true, message: '必输', trigger: 'blur'}],
          firstItemId: [{required: true, message: '必输', trigger: 'change'}]
        },
        value: [],
        filterMethod(query, item) {
          return item.pinyin.indexOf(query) > -1;
        }
      }
    },
    created() {
      //this.getRoleList()
      //this.getRoleList({userId: this.userId})
      //this.dataForm.roleList = [1,2,3]
    },
    computed: {
      ...mapGetters('userRole', [
        'dataForm',
        'data'
      ])
    },
    methods:{
      ...mapActions('userRole',[
        'getDetailList',
        'getRoleList'
      ]),
      getRoleList(data) {
        this.$api.myApi.getUserRole(data)
          .then((res) => {
            if (res.retCode == '0') {
              const generateData = _ => {
                let roles = []
                let roleNames = []
                let roleIds = []
                for (let i = 0; i < res.result.roleList.length; i++) {
                  roleNames.push(res.result.roleList[i].roleName)
                  roleIds.push(res.result.roleList[i].roleId)
                }
                roleNames.forEach((role, index) => {
                  roles.push({
                    label: role,
                    key: roleIds[index],
                    pinyin: roleNames[index]
                  })
                })
                return roles
              }
              this.data = generateData()
            } else {
              this.$message({
                type: 'error',
                message: res.retMsg,
                duration: 3 * 1000
              });
            }
          })
      },
      roleModify() {
        let data = {userId: this.userId, roleList: this.dataForm.roleList}
        this.$confirm('确定修改？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$api.myApi.userUpdate(data)
            .then((res) => {
              if (res.retCode == '0') {
                this.$message({
                  type: 'success',
                  message: '修改成功!',
                  duration: 3 * 1000
                });
                this.$nextTick(() => {
                  this.reload()
                })
              } else {
                this.$message({
                  type: 'warning',
                  message: res.retMsg,
                  duration: 3 * 1000
                });
              }
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消修改'
          });
        });
      },
      roleAdd() {
        let data = {userId: this.userId, roleList: this.dataForm.roleList}
        this.$confirm('确定新增？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$api.myApi.userAdd(data)
            .then((res) => {
              if (res.retCode == '0') {
                this.$message({
                  type: 'success',
                  message: '新增成功!',
                  duration: 3 * 1000
                });
                this.$nextTick(() => {
                  this.reload()
                })
              } else {
                this.$message({
                  type: 'error',
                  message: res.retMsg,
                  duration: 3 * 1000
                });
              }
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消新增'
          });
        });
      }
    },
    components:{ treeTransfer } // 注册
  }

</script>


