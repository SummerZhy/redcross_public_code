<template>
  <div class="main-con">
    <section class="wrap-class">
      <title-style>角色基本信息</title-style>
      <div class="com-info-wrap">
        <ul class="com-info-wrap-left">
          <li><label>角色名称:</label><span>{{infoData.roleName}}</span></li>
        </ul>
        <ul class="com-info-wrap-right">
          <li><label>角色描述:</label><span>{{infoData.description}}</span></li>
        </ul>
      </div>
    </section>
    <section class="wrap-class fun-menu-wrap">
      <title-style>功能菜单</title-style>
      <div class="fun-menu-wrap-con">
        <section class="menu-list-wrap">
          <div class="title-tip">
            <section>功能菜单名称</section>
            <section>
             <!-- <span>展开全部</span>
              <span>收起全部</span>-->
            </section>
          </div>
          <el-tree :data="infoData.menus" :props="defaultProps"></el-tree>
        </section>
      </div>
    </section>
    <section class="com-btn-wrap-center">
      <el-button type="danger" @click="close">关闭</el-button>
    </section>
  </div>
</template>

<script>
  export default{
    data(){
      return{
        id:this.$route.query.roleId,
        infoData:{},
        defaultProps: {
          children: 'children',
          label: 'menuChinaName'
        }
      }
    },
    created(){
      this.queryDetail();
    },
    methods:{
      //查询详情
      queryDetail(){
        let params = {
          id:this.id
        }
        this.$api.myApi.role.roleInfoGet(params).then( res => {
          if(res.retCode == 0){
            this.infoData = res.result;
          }else{
            this.$message.error(res.retMsg);
          }
        })
      },
      close(){
        this.$router.push('/permission/role-management');
      }
    }
  }
</script>

<style lang="scss" scoped>
  .fun-menu-wrap{
    margin:10px 0 20px;
  }
  .fun-menu-wrap-con{
    padding:20px 30px;
  }
  .menu-list-wrap{
    border: 1px solid #DCDFE6;
    border-radius: 4px;
    .title-tip{
      height:44px;
      line-height:44px;
      padding:0 15px;
      background: rgba(237,241,242,0.50);
      display:flex;
      justify-content: space-between;
      border-bottom: 1px solid #DCDFE6;
    }
  }
</style>
