<template>
  <div class="app-container">
<!--    <div>111</div>-->
<!--    <div>222</div>-->

<!--    <div>33</div>-->
<!--    <div><span>111</span></div>-->
<!--    <div><span>222</span></div>-->
    <el-table :data="dataList" border fit size="mini" v-loading="loading" highlight-current-row>
      <el-table-column align="center" label="序号" width="80">
        <template slot-scope="scope">
          <span v-text="getIndex(scope.$index)"> </span>
        </template>
      </el-table-column>
      <el-table-column align="center" label="用户ID" prop="userId" style="width: 30px;"></el-table-column>
      <el-table-column align="center" label="用户名称" prop="userName" style="width: 30px;"></el-table-column>
      <el-table-column align="center" label="操作" width="400">
        <template slot-scope="scope">
          <el-button-group>
            <!--<el-button type="primary" size="mini" icon="edit" @click="dataCreate(scope.row)">新增</el-button>-->
            <el-button type="primary" size="mini" icon="el-icon-document" title="详情" @click="dataDetail(scope.row)"></el-button>
            <el-button type="primary" size="mini" icon="el-icon-edit" title="修改" @click="dataModify(scope.row)"></el-button>
            <el-button type="danger" size="mini" icon="el-icon-goods" title="解锁" @click="dataUnlock(scope.row)"></el-button>
            <!--<el-button type="danger" size="mini" icon="edit" @click="dataDel(scope.row)">删除</el-button>-->
            <!--<el-button type="danger" size="mini" icon="delete" @click="dataDel(scope.row)">删除</el-button>-->
          </el-button-group>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="queryForm.currentPage"
      :page-size="queryForm.limit"
      :total="totalNum"
      :page-sizes="[10, 20, 50, 100]"
      layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <el-dialog :title="textMap[dialogStatus]"
               :visible.sync="detailForm"
               width="36%"
               :before-close="handleClose">
      <user-detail :dialogStatus="dialogStatus" :userId="userId" ref="child"></user-detail>
    </el-dialog>
    <el-dialog title="删除角色"
               :visible.sync="delForm"
               width="40%"
               :before-close="handleClose">
      <user-del :userId="userId"></user-del>
    </el-dialog>
  </div>
</template>
<script>
  import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
  import userDetail from './UserDetail'
  import validator from '@/utils/validator'

  export default {
    components: {
      userDetail
    },
    inject: ['reload'],
    data() {
      return {
        detailForm: false,
        delForm: false,
        dialogStatus: '',
        userId: '',
        textMap: {
          update: '修改角色',
          create: '新增角色',
          detail: '角色详情'
        },
        queryForm: {
          userName: '',
          currentPage: 1,
          limit: 10,
        },
        rules: {
          projectName: [
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
        },
      }
    },
    created() {
      //this.loading = true
      this.getDataList(this.queryForm)
    },
    computed: {
      ...mapGetters('userRole', [
        'dataList',
        'dataForm',
        'totalNum',
        'loading'
      ])
    },
    methods: {
      ...mapActions('userRole', [
        'getDataList',
        'getDetailList',
        'resetDetailList',
        'getRoleList',
        'getRoleAllList',
        'getMyRoleAll'
      ]),

      handleClose(done) {
        this.detailForm = false
        /*this.$confirm('确认关闭？')
          .then(_ => {
            done()
            this.detailForm = false
          })
          .catch(_ => {
          })*/
      },

      handleSizeChange(val) {
        //改变每页数量
        this.queryForm.limit = val
        this.getDataList(this.queryForm)
      },
      handleCurrentChange(val) {
        //改变页码
        this.queryForm.currentPage = val
        this.getDataList(this.queryForm)
      },
      dataQuery() {
        //查询事件
        this.queryForm.currentPage = 1
        this.getDataList(this.queryForm)
      },
      getIndex($index) {
        //表格序号
        return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
      },
      dataCreate(row) {
        //新增事件
        this.userId = row.userId
        this.detailForm = true
        this.dialogStatus = 'create'
        this.resetDetailList()
        this.getRoleList({userId: this.userId})
        //this.$refs.child.getRoleList()
        //this.$refs.child.getRoleList({userId: this.userId})
      },
      dataUnlock(row) {
        let data = {userId: row.userId}
        this.$confirm('确定解锁？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$api.myApi.userUnlock(data)
            .then((res) => {
              if (res.retCode == '0') {
                this.$message({
                  type: 'success',
                  message: '解锁成功!',
                  duration: 3 * 1000
                });
                this.$nextTick(() => {
                  this.reload()
                })
              } else {
                this.$message({
                  type: 'warning',
                  message: res.retMsg,
                  duration: 3 * 1000
                });
              }
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消解锁'
          });
        });
      },
      dataModify(row) {
        this.userId = row.userId
        let data = {userId: row.userId}
        this.getRoleAllList({
          data:{currentPage: 1, limit: 10000}
        })
        this.getDetailList(data)
        this.detailForm = true
        this.dialogStatus = 'update'
      },
      dataDetail(row) {
        this.userId = row.userId
        let data = {userId: row.userId}
        this.getRoleAllList({
          data:{currentPage: 1, limit: 10000},
          disabled:true
        })
        this.getDetailList(data)
        this.detailForm = true
        this.dialogStatus = 'detail'
      },
      dataDel(row) {
        //删除事件
        this.userId = row.userId
        this.delForm = true
        /*let data = {userId: row.userId}
        this.getDetailList(data)*/
        this.resetDetailList()
        this.getMyRoleAll({userId: row.userId})
      }
    }
  }
</script>


<style scoped lang="scss">

</style>
