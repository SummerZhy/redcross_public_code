<template>
  <div class="main-con">
    <el-card class="susp-query-list">
      <el-form size="small">
        <el-row>
          <el-col :span="8" >
            <el-form-item label="机构编号">
              <el-col :span="7">
               <span>{{roleListData.branchId}}</span>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="机构名称">
              <el-col :span="9">
                <span>{{roleListData.name}}</span>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="roleListData.type != 2">
            <el-form-item label="机构状态">
              <el-col :span="9">
                <span>{{roleListData.status}}</span>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="8" >
            <el-form-item label="机构简称">
              <span>{{roleListData.abbreviation}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="roleListData.type != 2">
            <el-form-item label="机构地区号">
              <span>{{roleListData.areaCode}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" >
            <el-form-item label="机构描述">
              <span>{{roleListData.description}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" >
            <el-form-item label="上报机构代码">
              <span>{{roleListData.reportBranchCode}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" >
            <el-form-item label="金融机构代码">
              <span>{{roleListData.financeBranchCode}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" >
            <el-form-item label="地区行政区划代码">
              <span>{{roleListData.areaZoneCode}}</span>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="roleListData.type != 2">
            <el-form-item label="网点代码">
              <span>{{roleListData.networkCode}}</span>
            </el-form-item>
          </el-col>
          <!--<el-col :span="8" >
            <el-form-item label="报告机构代码">
              &lt;!&ndash;<span>{{roleListData.reportBranchCode}}</span>&ndash;&gt;
            </el-form-item>
          </el-col>-->
          <el-col :span="8" >
            <el-form-item label="机构类型">
              <span>{{roleListData.typeName}}</span>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
    <section class="com-btn-wrap-center">
      <el-button @click="cancel" size="small">关闭</el-button>
    </section>
  </div>
</template>

<script>
  export default{
    name: "OrgDetails",
    data(){
      return{
        id:this.$route.query.branchId,
        roleListData:[]
      }
    },
    created(){
      this.getOrgDetails();
    },
    methods:{
      //机构详情
      getOrgDetails(){
        let params = {
          limit:10,
          currentPage:1,
          branchId:this.id
        }
        this.$api.myApi.permission.getMechanismSearch(params)
          .then( res => {
            if(res.retCode == 0){
              this.roleListData = res.result;
            }else{
              this.$message.error(res.retMsg);
            }
          })
      },
      //取消
      cancel(){
        this.$router.push('/permission/org-management');
      },
    }
  }
</script>

<style lang="scss" scoped>
  .power-wrap{
    margin:10px 0 20px 0;
    .power-con-wrap{
      padding:20px 30px;
    }
  }
</style>
