<template>
  <div class="main-con">
    <section class="wrap-class">
      <title-style>基础信息填写</title-style>
      <el-form class="com-base-info-wrap" ref="form1" :model="formData" :rules="rules" label-width="92px" label-position="left" size="small">
        <section class="com-base-info-left">
          <!--<el-form-item label="所属机构：">
            所属机构
          </el-form-item>-->
          <el-form-item label="用户编码：" prop="userId">
            <el-input v-model="formData.userId" :disabled = "disabledType"></el-input>
          </el-form-item>
<!--          <el-form-item label="用户状态：">-->
<!--            <el-select v-model="formData.region" placeholder="请选择活动区域">-->
<!--              <el-option label="区域一" value="shanghai"></el-option>-->
<!--              <el-option label="区域二" value="beijing"></el-option>-->
<!--            </el-select>-->
<!--          </el-form-item>-->
          <el-form-item label="E-mail：" prop ="mail">
            <el-input v-model="formData.mail"></el-input>
          </el-form-item>
          <el-form-item label="电话：" prop="mobilePhone">
            <el-input v-model="formData.mobilePhone"></el-input>
          </el-form-item>
        </section>
        <section class="com-base-info-right" >
          <el-form-item label="所属部门：" prop="departmentId" v-if="formData.departmentId != 0 || formData.departmentId == ''">
            <el-select v-model="formData.departmentId" placeholder="请选择所属部门">
              <el-option
                v-for="item in departmentNameList"
                :key="item.branchId"
                :label="item.name"
                :value="item.branchId">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="所属机构：" v-if="formData.departmentId == 0 && formData.departmentId != ''">
              <el-input v-model="formData.branchName" :disabled = "disabledType"></el-input>
          </el-form-item>
          <el-form-item label="用户名称：" prop="userName">
            <el-input v-model="formData.userName"></el-input>
          </el-form-item>
        </section>
      </el-form>
    </section>
    <section class="wrap-class power-wrap">
      <title-style>权限角色分配</title-style>
      <div class="power-con-wrap">
        <el-form ref="form2" :model="formData" :rules="rules" label-width="96px" label-position="left">
          <el-form-item label="所属角色：" prop="checkedRolesId">
            <el-transfer
              v-model="formData.checkedRolesId"
              :data="roleListData"
              :titles="['所有角色', '已选角色']"
              :props="{
                key: 'roleId',
                label: 'roleName'
              }"
              @change="changeChecked">
            </el-transfer>
          </el-form-item>
          <el-form-item label="默认角色：" prop="roleId">
            <el-select v-model="formData.roleId" placeholder="请选择活动区域">
              <el-option v-for="item in checkedRoles" :label="item.roleName" :value="item.roleId" :key="item.roleId"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <section class="com-btn-wrap-center">
        <el-button v-if="id" type="danger" @click="editUser" size="small" class="button">修改</el-button>
        <el-button v-else type="danger" @click="addUser" size="small"  class="button">新增</el-button>
        <el-button @click="cancel" size="small"  class="button">取消</el-button>
      </section>
    </section>

  </div>
</template>

<script>
  import validator from '@/utils/validator'
  export default{
    data(){
      return{
        id:this.$route.query.id,
        disabledType:false,
        formData:{
          userId:'',
          mail:'',
          departmentId:'',
          userName:'',
          mobilePhone:'',
          roles:[],
          roleId:'',
          checkedRolesId:[],//穿梭框选中的角色列表id
          branchName:''
        },
        rules:{
          userId:[
            { required: true, message: '请输入用户编码数字', trigger: 'blur' },
            {validator: validator.isNumber, trigger: 'blur'}
          ],
          departmentId:[
            { required: true, message: '请输入所属部门', trigger: 'blur' },
          ],
          userName:[
            { required: true, message: '请输入用户名称', trigger: 'blur' },
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
          mobilePhone:[
            { required: true, message: '请输入电话', trigger: 'blur' },
            {validator: validator.telphone, trigger: 'blur'}
          ],
          mail:[
            { required: true, message: '请输入联系邮箱', trigger: 'blur' },
            {validator: validator.email, trigger: 'blur'}
          ],
          checkedRolesId:[
            { required: true, message: '请选择所属角色', trigger: 'blur' },
          ],
          roleId:[
            { required: true, message: '请选择默认角色', trigger: 'blur' },
          ]
        },
        roleListData:[], //所有的角色列表
        checkedRoles:[], //穿梭框选中的角色列表
        departmentNameList:[],
      }
    },
    created(){
      this.getRoleList();
      this.branchTree();
      if(this.id){
        this.queryDetail();
        this.disabledType = true
      }
    },
    methods:{
      //角色列表
      getRoleList(){
        let params = {
          limit:999,
          currentPage:1,
        }
        this.$api.myApi.role.getRoleList(params)
          .then( res => {
            if(res.retCode == 0){
              this.roleListData = res.result.roles;
            }else{
              this.$message.error(res.retMsg);
            }
          })
      },
      //选择所属角色发生变化时
      changeChecked(val){
        this.formData.roles = this.formData.checkedRolesId;
        this.checkedRoles = [];
        this.roleListData.forEach(item => {
          if(this.formData.checkedRolesId.indexOf(item.roleId) != -1){
            this.checkedRoles.push(item);
          }else{
            this.formData.roleId = ''
          }
        })
      },
      //新增
      addUser(){
        let valid1 = false, valid2 = false;
        this.$refs.form1.validate(valid => {
          if(valid){
            valid1 = true;
          }
        })
        this.$refs.form2.validate(valid => {
          if(valid){
            valid2 = true;
          }
        })
        if(valid1 && valid2){
          this.$confirm('是否新增?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userInfoPost(this.formData)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/user-management');
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消新增'
            });
          });
        }
      },
      //取消
      cancel(){
        this.$router.push('/permission/user-management');
      },
      //查询详情
      queryDetail(){
        let params = {
          userId:this.id
        }
        //console.log(this.id)
        this.$api.myApi.permission.userInfoGet(params)
          .then( res => {
            if(res.retCode == 0){
              let obj = res.result;
              this.formData.userId = obj.userId;
              this.formData.mail = obj.mail;
              this.formData.departmentId = obj.departmentId;
              this.formData.userName = obj.userName;
              this.formData.mobilePhone = obj.mobilePhone;
              this.checkedRoles = obj.roles;
              this.formData.roleId = obj.roleId;
              this.formData.branchName = obj.branchName;
              this.formData.roles = obj.roles.map(item => {
                return item.roleId
              });
              this.formData.checkedRolesId = obj.roles.map(item => {
                return item.roleId
              })
            }else{
              this.$message.error(res.retMsg);
            }
          })
      },
      //修改用户
      editUser(){
        let valid1 = false, valid2 = false;
        this.$refs.form1.validate(valid => {
          if(valid){
            valid1 = true;
          }
        })
        this.$refs.form2.validate(valid => {
          if(valid){
            valid2 = true;
          }
        })
        if(valid1 && valid2){
          this.$confirm('是否修改?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userInfoPut(this.formData)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/user-management');
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消修改'
            });
          });

        }
      },
      //所属机构
      branchTree(){
        /*this.$api.myApi.permission.getBranchTree().then( res => {
          if(res.retCode == 0){
            this.departmentNameList = res.result.list;
          }else{
            this.$message.error(res.retMsg);
          }
        })*/
        this.$api.myApi.permission.getMechanismList().then( res => {
          if(res.retCode == 0){
            this.departmentNameList = res.result.departmentList;
          }else{
            this.$message.error(res.retMsg);
          }
        })
      }
    }
  }
</script>

<style lang="scss">
  .el-transfer-panel__list{
    .el-transfer-panel__item{
      display:block !important;
    }
  }
</style>
<style lang="scss" scoped>
  .power-wrap{
    margin:10px 0 20px 0;
    .power-con-wrap{
      padding:20px 30px;
    }
  }
  .el-form-item{
    margin-bottom: 20px;
  }
  .button{
    width: 73px;
    height: 32px;
    padding: 6px 20px;
  }
  .com-btn-wrap-center{
   padding-bottom: 30px;
  }

</style>
