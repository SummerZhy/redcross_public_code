<template>
 <div class="main-con">
    <el-form label-width="100px" size="small" label-position="left" class="wrap-class search-wrap">
        <el-row style="margin-bottom:10px">
          <el-col :span="12">
            <el-form-item label="操作日期：" >
              <el-date-picker type="date" placeholder="开始日期" v-model="startTime" value-format="yyyy-MM-dd" style="width: 40%"></el-date-picker>
              <span>&nbsp;—&nbsp;</span>
              <el-date-picker type="date" placeholder="结束日期" v-model="endTime"  value-format="yyyy-MM-dd" style="width: 40%"></el-date-picker>
            </el-form-item>
            <!-- <el-form-item label="操作时间">
               <el-col :span="9">
                 <el-time-select  placeholder="起始时间" v-model="addSecond1"
                                  :picker-options="{
                        start: '00:00',
                        step: '00:01',
                        end: '23:59'}"
                                  style="width: 100%;">
                 </el-time-select>
               </el-col>
               <el-col class="line" :span="1" style="text-align:center;">-</el-col>
               <el-col :span="9">
                 <el-time-select placeholder="结束时间" v-model="addSecond2" :picker-options="{
                      start: '00:00',
                      step: '00:01',
                      end: '23:59',
                      minTime: addSecond1}"
                                 style="width: 100%;">
                 </el-time-select>
               </el-col>
             </el-form-item>-->
          </el-col>
          <el-col :span="6">
            <el-form-item label="操作发起人：">
              <!--  <el-select v-model="operId" placeholder="请选择">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>-->
              <el-input v-model="operId" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="6" style="text-align:right;">
            <el-button-group size="small">
              <el-button type="danger" size="small" @click="refresh">查询</el-button>
              <el-button size="small" v-show="!fold" @click="fold = !fold">展开</el-button>
              <el-button size="small" v-show="fold" @click="fold = !fold">收起</el-button>
            </el-button-group>
          </el-col>
        </el-row>
        <el-row v-show="fold">
          <el-col :span="9" >
           <!-- <el-form-item label="操作发起人">
            &lt;!&ndash;  <el-select v-model="operId" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>&ndash;&gt;
              <el-input v-model="operId" style="width: 50%"></el-input>
            </el-form-item>-->
          </el-col>
          <el-col :span="9" >
            <el-form-item label="操作模块：">
              <el-input v-model="modelId" style="width: 50%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

    <section class="wrap-class">
      <div class="com-operation-div">
        <el-button size="mini" @click="exportSelect">导出选项</el-button>
        <el-button size="mini" @click="downloadExcel">导出全部</el-button>
        <section class="com-operation-right">
          <!--<span style="cursor: pointer"  @click="downloadExcel"><i class="el-icon-download"></i>下载</span>-->
          <div></div>
        </section>
      </div>
      <div class="con-list">
        <el-table
          :data="tableData"
          @selection-change="selectEven"
          style="width: 100%">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="operDate"
            label="操作日期"
           >
          </el-table-column>
          <el-table-column
            prop="operTime"
            label="操作时间"
            >
          </el-table-column>
          <el-table-column
            prop="userName"
            label="操作发起人">
          </el-table-column>
          <el-table-column
            prop="modelId"
            label="操作模块">
          </el-table-column>
        </el-table>
        <el-pagination
          @current-change="pageLogList"
          :current-page.sync="currentPage"
          :page-size="10"
          layout="total, prev, pager, next, jumper"
          :total="totalNum">
        </el-pagination>
      </div>
    </section>
  </div>
</template>

<script>
  import common from '@/utils/common'
    export default {
        name: "OperationLog",
      data(){
        return{
          fold:false,
          operId:'',
          modelId:'',
          operTimeStart:'',
          operTimeEnd:'',
          tableData:[],
          startTime:'',
          endTime:'',
          limit:10,
          currentPage:1,
          totalNum:0,
          reportId:[],
          arrList:{},
          fold:false,
          /*addSecond1:'',
          addSecond2:'',*/
        }
      },
      created(){
        this.pageLogList();
      },
      methods:{
        //操作日志列表查询
        pageLogList(){
          let staTime = new Date(this.startTime).getTime();
          let enTime = new Date(this.endTime).getTime();
          if(staTime != '' && enTime != ''){
            if(staTime > enTime){
              this.$confirm('操作起始日期不能大于操作结束日期');
              return;
            };
          }

          //为时间添加秒
         /* if(this.addSecond1 == '' || this.addSecond1 == null ){
            this.operTimeStart = this.addSecond1;
          }else{
            this.operTimeStart = this.addSecond1 +':00';
          };
          if(this.addSecond2 == '' || this.addSecond2 == null){
            this.operTimeEnd = this.addSecond2;
          }else{
            this.operTimeEnd = this.addSecond2 +':00';
          };*/
          let params = {limit:this.limit,
            currentPage:this.currentPage,
            operStartDate:this.startTime,
            operStopDate:this.endTime,
          /*  operStartTime:this.operTimeStart,
            operStopTime:this.operTimeEnd,*/
            operId:this.operId,
            modelId:this.modelId,
          };
          this.$api.myApi.permission.getLogList(params)
            .then(res =>{
              if (res.retCode === '0'){
                this.tableData = res.result.list;
                this.totalNum = res.result.totalNum;
              }else{
                this.$message.error(res.retMsg);
              }
            })
        },
        //选中事件
        selectEven(val){
          let arr = val.map(item => {
            return item.id;
          })
          this.arrList = val;
          //this.reportId = arr.toString();
          this.reportId = arr;
        },
        //下载全部
        downloadExcel(){
          let params = {
            operStartDate:this.startTime,
            operStopDate:this.endTime,
            operStartTime:this.operTimeStart,
            operStopTime:this.operTimeEnd,
            operId:this.operId,
            modelId:this.modelId,
          };
          this.$confirm('是否导出全部?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.getLogExport(params)
              .then(res =>{
                if (res.retCode === '0'){
                  let result = common.dataToFile(res.result, '操作日志导出.xls', 'application/vnd.ms-excel')
                  this.$message.success(res.retMsg);
                }else{
                  this.$message.error(res.retMsg);
                }
              });
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消导出'
            });
          });
        },
        //下载选项 暂时这么写 等接口确认
        exportSelect(){
          let params = {idList:this.reportId };
          this.$confirm('是否导出选中项?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.getLogExportPart(params)
              .then(res =>{
                if (res.retCode === '0'){
                  this.$message.success(res.retMsg);
                  let result = common.dataToFile(res.result, '操作日志导出.xls', 'application/vnd.ms-excel')
                }else{
                  this.$message.error(res.retMsg);
                }
              });
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消导出'
            });
          });
         },
        //查询刷新
        refresh(){
          this.currentPage = 1;
          this.pageLogList();
        },
      }
    }
</script>

<style scoped lang="scss">
 .el-col-4 {
		float:right;
		text-align: right;
		line-height:41px;
	}
  
  
</style>
