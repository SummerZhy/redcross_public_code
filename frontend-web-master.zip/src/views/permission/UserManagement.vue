<template>
    <div class="main-con">
      <el-form class="wrap-class search-wrap"  ref="form" :model="queryForm" label-width="82px" :inline="inline" label-position="left" size="small">
        <el-form-item label="所属部门：">
          <el-select v-model="queryForm.departmentId" placeholder="请选择所属机构" clearable size="small" class="select">
            <el-option
              v-for="item in departmentNameList"
              :key="item.branchId"
              :label="item.name"
              :value="item.branchId">
            </el-option>
          </el-select>
        </el-form-item>
       <!-- <el-form-item label="输入关键字">
          <el-input v-model="queryForm.search"></el-input>
        </el-form-item>-->
        <el-form-item>
          <el-button type="danger" @click="querySearch" size="mini">查询</el-button>
        </el-form-item>
      </el-form>
      <section class="wrap-class">
        <div class="com-operation-div">
          <section class="com-operation-left">
            <el-button size="mini" @click="exportSelect" class="downBtn">导出选项</el-button>
            <el-button size="mini" @click="exportAll" class="downBtn">导出全部</el-button>
          </section>
          <section class="com-operation-right">
            <span @click="toAdd"><svg-icon class="right-icon" icon-class="add"></svg-icon>新增</span>
            <span @click="refresh"><svg-icon class="right-icon" icon-class="refresh"></svg-icon>刷新</span>
            <span @click="changeUserStatus(2)"><svg-icon class="right-icon" icon-class="freeze"></svg-icon>冻结</span>
            <span @click="changeUserStatus(1)"><svg-icon class="right-icon" icon-class="thaw"></svg-icon>解冻</span>
            <span @click="delUsers"><svg-icon class="right-icon" icon-class="delete"></svg-icon>删除</span>
            <span @click="resetPasswordAll"><svg-icon class="right-icon" icon-class="refresh"></svg-icon>重置密码</span>
          </section>
        </div>
        <div class="con-list">
          <el-table
            ref="multipleTable"
            :data="tableData"
            style="width: 100%"
            @selection-change="handleSelectionChange"
            :row-key="getRowKey"
          >
            <el-table-column
              type="selection"
              width="55"
              :reserve-selection="true">
            </el-table-column>
            <el-table-column width="70px" align="center" label="序号">
              <template slot-scope="scope">
                <span v-text="getIndex(scope.$index)"></span>
              </template>
            </el-table-column>
            <el-table-column
              label="用户编码"
              width="180">
              <template slot-scope="scope"><span class="com-click-class" @click="toDetail(scope.row.userId)">{{scope.row.userId}}</span></template>
            </el-table-column>
            <el-table-column
              prop="userName"
              label="用户名称"
              width="180">
            </el-table-column>
            <el-table-column
              prop="branchName"
              label="所属机构">
            </el-table-column>
            <el-table-column
              prop="departmentName"
              label="所属部门">
            </el-table-column>
            <el-table-column
              prop="roleName"
              label="用户默认角色">
            </el-table-column>
            <el-table-column
              prop="status"
              label="用户状态">
              <template slot-scope="scope">
                <span>{{ scope.row.status == 2 ? "已冻结" : "正常" }}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="操作">
              <template slot-scope="scope">
                <span class="com-click-class" @click="toEdit(scope.row.userId)">修改</span>
                <span class="com-click-class" style="margin-left: 5px" @click="resetPassword(scope.row.userId)">重置密码</span>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            @current-change="getUserList"
            :current-page.sync="queryForm.currentPage"
            :page-size="queryForm.limit"
            layout="total, prev, pager, next, jumper"
            :total="totalNum">
          </el-pagination>
        </div>
      </section>
      <el-dialog
        title="提示"
        :visible.sync="centerDialogVisible"
        width="30%"
        :show-close="false"
        center>
        <span style="text-align: center">请至少选择一条记录，谢谢。</span>
        <span slot="footer" class="dialog-footer">
          <el-button type="danger" @click="centerDialogVisible = false" class="dialogButton">取消</el-button>
        </span>
      </el-dialog>

    </div>
</template>

<script>
  import common from '@/utils/common'
    export default {
      name: "UserManagement",
      data(){
          return{
            centerDialogVisible:false,
            inline:true,
            queryForm:{
              currentPage:1,
              limit:10,
              departmentId:'',
              search:'',
            },
            getRowKey(row){
              return row.userId;
            },
            totalNum:0,
            tableData:[],
            checkList:[],
            departmentNameList:[],
            exportList:[]
          }
      },
      created(){
        this.getUserList();
        this.branchTree();
      },

      activated() {
        if (this.$route.meta.isBack) {
          this.$route.meta.isBack = false;
        } else {
          this.refresh();
          this.fold = false;
        }
      },
      beforeRouteEnter(to, from, next) {
        if (from.path == '/permission/user-add' || from.path == '/permission/user-info' || from.path == '/permission/user-modify') {
          to.meta.isBack = true
        } else {
          to.meta.isBack = false
        }
        next()
      },
      methods:{
        toAdd(){
          this.$router.push('/permission/user-add');
        },
        toDetail(userId){
          this.$router.push({
            path:'/permission/user-info',
            query:{
              id:userId
            }
          });
        },
        toEdit(userId){
          this.$router.push({
            path:'/permission/user-modify',
            query:{
              id:userId
            }
          })
        },
        //机构列表
        //用户管理列表
        getUserList(){
          this.$api.myApi.permission.getUserList(this.queryForm)
            .then( res => {
              // debugger;
              if(res.retCode == 0){
                this.totalNum = res.result.totalNum;
                this.tableData = res.result.list;
                //this.$message.success(res.retMsg)
              }else{
                this.$message.error(res.retMsg);
              }
            })
        },
        //查询
        querySearch(){
          this.queryForm.currentPage = 1;
          this.getUserList();
        },
        //表格序号
        getIndex($index) {
          return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
        },
        //table多选框改变
        handleSelectionChange(val){
          let arr = val.map(item => {
            return item.userId;
          })
          //this.checkList = arr.toString();
          this.checkList = arr;
          this.exportList = arr;
        },
        //刷新
        refresh(){
          this.checkList = [];
          this.$refs.multipleTable.clearSelection();
          this.queryForm = {
            currentPage:1,
            limit:10,
            departmentId:'',
            search:'',
          }
          this.getUserList();
        },
        //冻结、解冻、删除后要执行的方法
        funAfter(){
          this.checkList = [];
          this.$refs.multipleTable.clearSelection();
          this.queryForm.currentPage = 1;
          this.getUserList();
        },
        //改变用户状态（冻结、解冻）
        changeUserStatus(status){
          if(this.checkList.length == 0 || this.checkList == []){
            //this.$message.warning('请选择用户');
            this.centerDialogVisible=true;
            return
          }
          let params = {
            userId:this.checkList,
            status:status //1：解冻 2：冻结
          }
          this.$confirm( status == 2 ?'是否冻结?' : '是否解冻?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userStatusPut(params)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.funAfter();
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: status == 2 ?'取消冻结' : "取消解冻"
            });
          });
        },
        //删除
        delUsers(){
          if(this.checkList.length == 0 || this.checkList == []){
            //this.$message.warning('请选择用户');
            this.centerDialogVisible=true;
            return
          }
          let params = {
            userId:this.checkList.toString()
          }
          this.$confirm('是否删除?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userInfoDel(params)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.funAfter();
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消删除'
            });
          });
        },
        //导出全部
        exportAll(){
          let params = {
            departmentId:this.queryForm.departmentId,
            search:this.queryForm.search
          }
          this.$confirm('是否导出全部?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.uerAllExport(params)
              .then( res => {
                if(res.retCode == 0){
                  let result = common.dataToFile(res.result, '导出用户.xls', 'application/vnd.ms-excel');
                  this.$message.success(res.retMsg);
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消导出'
            });
          });

        },
        //导出选项
        exportSelect(){
          if(this.checkList.length == 0 || this.checkList == []){
            this.$message.warning('请选择用户');
            return
          }
          let params = {
             userIds: this.exportList
            // userIds: 'chenf'
          }
          this.$confirm('是否导出选项?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.uerExport(params)
              .then( res => {
                let result = common.dataToFile(res.result, '导出用户.xls', 'application/vnd.ms-excel')
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消导出'
            });
          });

        },
        //所属机构
        branchTree(){
          /*this.$api.myApi.permission.getBranchTree().then( res => {
            if(res.retCode == 0){
              this.departmentNameList = res.result.list;
            }else{
              this.$message.error(res.retMsg);
            }
          })*/
          this.$api.myApi.permission.getMechanismList().then( res => {
            if(res.retCode == 0){
              this.departmentNameList = res.result.departmentList;
              //console.log(this.departmentNameList)
            }else{
              this.$message.error(res.retMsg);
            }
          })
        },
        handleClose(done) {
          this.$confirm('确认关闭？')
            .then(_ => {
              done();
            })
            .catch(_ => {});
        },
        //重置密碼
        resetPassword(e){
          let params = { userId:[e] }
          this.$confirm('是否重置密码?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userCodeReset(params)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消重置'
            });
          });
        },
        //批量重置密码resetPasswordAll
        resetPasswordAll(){
          if(this.checkList.length == 0 || this.checkList == []){
            this.centerDialogVisible=true;
            return
          };
          let params = { userId:this.checkList };
          this.$confirm('是否重置密码?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() =>{
            this.$api.myApi.permission.userCodeReset(params)
              .then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                }else{
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消重置'
            });
          });
        },
      }
    }
</script>

<style scoped lang="scss">
  .search-wrap{
    padding:20px 30px;
    margin-bottom:10px;
    .el-form--inline .el-form-item{
      margin-right:30px;
    }
    .el-form-item{
      margin-bottom:0;
    }
  }
 
  .select{
    width: 224px;
  }
  .button{
    width:52px;
    height: 32px;
    padding: 9px 12px;
  }
  .downBtn{
    width: 96px;
    height: 32px;
  }
  .el-dialog__footer{
    width: 77px;
    height: 28px;
    padding: 24px 28px;
  }
  .el-dialog{
    border-radius: 4px;
  }
  .el-dialog__wrapper .el-dialog__body{
    font-family: PingFangSC-Medium;
    font-size: 14px;
    color: #606266;
    letter-spacing: 0;
    text-align: center!important;
    line-height: 14px;
  }
  .el-dialog__header{
    padding: 30px 20px 20px!important;
  }
</style>
