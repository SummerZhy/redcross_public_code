<template>
  <div class="app-container">
    <div class="filter-container">
      <el-row>
      <el-form ref="queryForm"
               :model="queryForm"
               :rules="rules">
        <el-input size="mini" placeholder="角色名称" style="width: 150px" prefix-icon="el-icon-search" v-model="queryForm.roleName"></el-input>
        <el-button size="mini" class="filter-item" type="primary" icon="el-icon-search" @click="dataQuery">查询</el-button>
        <el-button size="mini" class="filter-item" style="margin-left: 10px;" type="primary" icon="el-icon-plus"
                   @click="dataCreate">新增
        </el-button>
      </el-form>
      </el-row>
    </div>
    <br/>
    <el-table :data="dataList" border fit size="mini" v-loading="loading" highlight-current-row>
      <el-table-column align="center" label="序号" width="80">
        <template slot-scope="scope">
          <span v-text="getIndex(scope.$index)"> </span>
        </template>
      </el-table-column>
      <!--<el-table-column align="center" label="角色ID" prop="roleId" style="width: 30px;"></el-table-column>-->
      <el-table-column align="center" label="角色名称" prop="roleName" style="width: 30px;"></el-table-column>
      <el-table-column align="center" label="操作" width="220">
        <template slot-scope="scope">
          <!--<el-button type="primary" size="mini" icon="edit" @click="dataDetail(scope.row)">详情</el-button>-->
          <!--<el-button type="primary" size="mini" icon="edit" @click="dataModify(scope.row)">修改</el-button>-->
          <!--<el-button type="danger" size="mini" icon="delete" @click="dataDel(scope.row)">删除</el-button>-->
        <el-button-group>
          <el-button type="primary" size="mini" icon="el-icon-document" title="详情" @click="dataDetail(scope.row)"></el-button>
          <el-button type="primary" size="mini" icon="el-icon-edit" title="修改" @click="dataModify(scope.row)"></el-button>
          <el-button type="danger" size="mini" icon="el-icon-delete" title="删除" @click="dataDel(scope.row)"></el-button>
        </el-button-group>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="queryForm.currentPage"
      :page-size="queryForm.limit"
      :total="totalNum"
      :page-sizes="[10, 20, 50, 100]"
      layout="total, sizes, prev, pager, next, jumper">
    </el-pagination>
    <el-dialog class="popContainer" :title="textMap[dialogStatus]"
               :visible.sync="detailForm"
               width="70%"
               :before-close="handleClose">
      <role-detail :dialogStatus="dialogStatus" :roleName="roleName" :roleId="roleId"></role-detail>
    </el-dialog>
  </div>
</template>
<script>
  import {mapState, mapGetters, mapActions, mapMutations} from 'vuex'
  import roleDetail from './RoleDetail'
  import validator from '@/utils/validator'

  export default {
    components: {
      roleDetail
    },
    inject: ['reload'],
    data() {
      return {
        detailForm: false,
        dialogStatus: '',
        textMap: {
          update: '修改角色',
          create: '新增角色',
          detail: '角色详情'
        },
        queryForm: {
          roleName: '',
          currentPage: 1,
          limit: 10,
        },
        roleName: '',
        roleId: '',
        rules: {
          projectName: [
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
        },
      }
    },
    created() {
      //this.loading = true
      this.getDataList(this.queryForm)
    },
    computed: {
      ...mapGetters('permissionRole', [
        'dataList',
        'dataForm',
        'totalNum',
        'permissionGroupList',
        'loading'
      ])
    },
    methods: {
      ...mapActions('permissionRole',[
        'getDataList',
        'getDetailPermissionList',
        'resetDetailList',
        'getDetailMenuList',
        'getPermissionList',
        'getPermissionListAll',
        'getMenuListAll'
      ]),

      handleClose (done) {
        this.detailForm = false
      },

      handleSizeChange(val) {
        //改变每页数量
        this.queryForm.limit = val
        this.getDataList(this.queryForm)
      },
      handleCurrentChange(val) {
        //改变页码
        this.queryForm.currentPage = val
        this.getDataList(this.queryForm)
      },
      dataQuery() {
        //查询事件
        this.queryForm.currentPage = 1
        this.getDataList(this.queryForm)
      },
      getIndex($index) {
        //表格序号
        return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
      },
      dataCreate () {
        //新增事件
        this.detailForm = true
        this.dialogStatus = 'create'
        this.resetDetailList()
        this.getPermissionListAll({disabled:false})
        this.getMenuListAll({disabled:false})
      },
      dataModify (row) {
        this.roleName = row.roleName
        this.roleId = row.roleId
        let data = {roleId: row.roleId}
        this.getPermissionListAll({
          data:data,
          disabled:false
        })
        this.getMenuListAll({
          data:data,
          disabled:false
        })
        this.getDetailPermissionList({
          data:data,
          disabled:false
        })
        this.getDetailMenuList({
          data:data,
          disabled:false
        })
        this.dataForm.roleName = row.roleName
        this.detailForm = true
        this.dialogStatus = 'update'
      },
      dataDetail (row) {
        //详情事件
        let data = {roleId: row.roleId}
        this.resetDetailList()
        this.getPermissionListAll({
          data:data,
          disabled:true
        })
        this.getMenuListAll({
          data:data,
          disabled:true
        })
        this.getDetailPermissionList({
          data:data,
          disabled:true
        })
        this.getDetailMenuList({
          data:data,
          disabled:true
        })
        this.detailForm = true
        this.dialogStatus = 'detail'
      },
      dataDel(row) {
        //删除事件
        let data = {roleId: row.roleId}
        this.$confirm('确定删除？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$api.myApi.roleDel(data)
            .then((res) => {
              if (res.retCode == '0') {
                this.$message({
                  type: 'success',
                  message: '删除成功!',
                  duration: 3 * 1000
                });
                this.$nextTick(() => {
                  this.reload()
                })
              } else {
                this.$message({
                  type: 'warning',
                  message: res.retMsg,
                  duration: 3 * 1000
                });
              }
            })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '取消删除'
          });
        });
      }
    }
  }
</script>


<style scoped lang="scss">
  .popContainer {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.3);
  }
</style>
