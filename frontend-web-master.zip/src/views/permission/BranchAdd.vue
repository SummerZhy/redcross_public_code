<template>
  <div class="main-con">
    <section class="wrap-class">
      <title-style>基础信息填写</title-style>
      <el-form class="com-base-info-wrap" ref="branchFrom" :model="formData" :rules="rules" label-width="150px"
               label-position="left" size="small">
        <div>
          <!--<section class="com-base-info-left">-->
          <el-row>
            <el-col :span="12">
              <el-form-item label="机构/部门">
                <el-select v-model="formData.type" placeholder="请选择要新增的类型" @change="changeEven" style="width: 90%" :disabled="disabledType">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构/部门名称：" prop="name">
                <el-input v-model="formData.name" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构/部门编号：" prop="branchId">
                <el-input v-model="formData.branchId" :disabled="disabledType" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构地区号：" prop="areaCode" v-if="hideShwo">
                <el-input v-model="formData.areaCode" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构/部门简称：" prop="abbreviation">
                <el-input v-model="formData.abbreviation" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="上报机构代码：" prop="reportBranchCode" v-if="hideShwo">
                <el-input v-model="formData.reportBranchCode" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="机构/部门描述：" prop="description">
                <el-input v-model="formData.description" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="地区行政区划代码：" prop="areaZoneCode" v-if="hideShwo">
                <el-input v-model="formData.areaZoneCode" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="金融机构代码：" prop="financeBranchCode" v-if="hideShwo">
                <el-input v-model="formData.financeBranchCode" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item v-if="hideShwo" label="管理员编码：" prop="userId">
                <el-input :disabled="disabledType" v-model="formData.userId" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="网点代码：" prop="networkCode" v-if="hideShwo">
                <el-input v-model="formData.networkCode" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item v-if="hideShwo" label="电话：" prop="mobilePhone">
                <el-input v-model="formData.mobilePhone" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item v-if="hideShwo" label="E-mail：" prop="mail">
                <el-input v-model="formData.mail" style="width: 90%"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <!--<el-form-item v-if="hideShwo" label="用户名称：" prop="userName">
            <el-input v-model="formData.userName" ></el-input>
          </el-form-item>-->
          <!--</section>-->
        </div>
      </el-form>
      <section class="com-btn-wrap-center" style="text-align: center;line-height: 100px;">
        <el-button v-if="editMark" type="danger" @click="editBranch" size="small">修改</el-button>
        <el-button v-if="addMark" type="danger" @click="addBranch" size="small">新增</el-button>
        <el-button @click="cancel" size="small">取消</el-button>
      </section>
    </section>
  </div>
</template>

<script>
  import validator from '@/utils/validator'

  export default {
    data() {
      return {
        type: this.$route.query.type,
        editMark: this.$route.query.edit,
        hideShwo: true,
        addMark: true,
        disabledType: false,
        options: [{
          value: 1,
          label: '机构'
        }, {
          value: 2,
          label: '部门'
        }],
        formData: {
          type: '',//机构/部门
          branchId: '',//机构编号
          name: '',    //机构名称
          abbreviation: '',//机构简称
          areaCode: '', //机构地区号
          description: '',//机构描述
          reportBranchCode: 'E2000811000015',//上报机构代码
          financeBranchCode: 'ICBCCS11',//金融机构代码
          areaZoneCode: '110102',//地区行政区划代码
          networkCode: '',//网点代码
          userId: '',  //用户编码
          userName: '',//用户名称
          mobilePhone: '',//电话
          mail: '',//电子邮件
        },
        rules: {
          branchId: [
            {required: true, message: '请输入机构编号', trigger: 'blur'},
            {validator: validator.isNumber, trigger: 'blur'}
          ],
          name: [
            {required: true, message: '请输入机构名称', trigger: 'blur'},
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
          abbreviation: [
            {required: true, message: '请输入机构简称', trigger: 'blur'},
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
          areaCode: [
            {required: true, message: '请输入机构地区号', trigger: 'blur'},
            {validator: validator.isNumber, trigger: 'blur'}
          ],
          description: [
            {required: true, message: '请输入机构描述', trigger: 'blur'},
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
          reportBranchCode: [
            {required: true, message: '请输入上报机构代码', trigger: 'blur'},
          ],
          financeBranchCode: [
            {required: true, message: '请输入金融机构代码', trigger: 'blur'},
          ],
          areaZoneCode: [
            {required: true, message: '请输入地区行政区划代码', trigger: 'blur'},
          ],
          networkCode: [
            {required: true, message: '请输入网点代码', trigger: 'blur'},
            {validator: validator.letterOrNumber, trigger: 'blur'}
          ],
          userId: [
            {required: true, message: '请输入用户编码', trigger: 'blur'},
            {validator: validator.letterOrNumber, trigger: 'blur'}
          ],
          userName: [
            {required: true, message: '请输入用户名称', trigger: 'blur'},
          ],
          mobilePhone: [
            {required: true, message: '请输入联系电话', trigger: 'blur'},
            {validator: validator.telphone, trigger: 'blur'}
          ],
          mail: [
            {required: true, message: '请输入联系邮箱', trigger: 'blur'},
            {validator: validator.email, trigger: 'blur'}
          ],
        },
        roleListData: [], //所有的角色列表
      }
    },
    created() {
      //判断新增还是修改
      if (this.editMark == 'edit') {
        this.addMark = false;
        this.disabledType = true;
        this.getAddList();
      }
    },
    methods: {
      //获取要修改的数据
      getAddList() {
        let params = {branchId: this.$route.query.branchId};
        this.$api.myApi.permission.getMechanismSearch(params).then(res => {
          if (res.retCode === '0') {
            let data = res.result;
            this.formData.type = data.type;
            this.formData.branchId = data.branchId;
            this.formData.name = data.name;
            this.formData.abbreviation = data.abbreviation;
            this.formData.areaCode = data.areaCode;
            this.formData.description = data.description;
            this.formData.reportBranchCode = data.reportBranchCode;
            this.formData.networkCode = data.networkCode;
            this.formData.financeBranchCode = data.financeBranchCode;
            this.formData.areaZoneCode = data.areaZoneCode;
            this.formData.userId = data.userId; //管理员编码
            this.formData.userName = data.userName;
            this.formData.mobilePhone = data.mobilePhone;
            this.formData.mail = data.mail;
            this.hideShwo = false;
            if (data.type == '1') {
              this.hideShwo = true;
            }
          } else {
            this.$message.error(res.retMsg);
          }
        })
      },

      //新增
      addBranch() {
        let valid1 = false;
        this.$refs.branchFrom.validate(valid => {
          if (valid) {
            valid1 = true;
          }
        })
        if (valid1) {
          this.$confirm('是否新增?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$api.myApi.permission.getMechanismListAdd(this.formData)
              .then(res => {
                if (res.retCode === '0') {
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/org-management');
                } else {
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消新增'
            });
          });
        }
      },
      //取消返回
      cancel() {
        this.$router.push('/permission/org-management');
      },
      //修改
      editBranch() {
        let valid1 = false;
        this.$refs.branchFrom.validate(valid => {
          if (valid) {
            valid1 = true;
          }
        });
        if (valid1) {
          this.$confirm('是否修改?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$api.myApi.permission.getMechanismEdit(this.formData)
              .then(res => {
                if (res.retCode === '0') {
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/org-management');
                } else {
                  this.$message.error(res.retMsg);
                }
              })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '取消修改'
            });
          });
        }

      },
      changeEven(ev) {
        if (ev == '1') {
          this.hideShwo = true
        } else {
          this.hideShwo = false
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .power-wrap {
    margin: 10px 0 20px 0;

    .power-con-wrap {
      padding: 20px 30px;
    }
  }

  .com-base-info-wrap /deep/ .el-form-item {
    margin-bottom: 30px;
  }

  .com-base-info-wrap {
    display: flex;
    justify-content: space-around;

  }

  .com-base-info-wrap /deep/ div {
    flex: 1;
  }
</style>
