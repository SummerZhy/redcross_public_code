<template>
  <div class="main-con">
    <el-form ref="form" :model="formData" :rules="rules" label-width="96px" label-position="left">
      <section class="wrap-class">
        <title-style>基础信息填写</title-style>
        <div class="com-base-info-wrap">
          <el-form-item class="com-base-info-left" label="角色名称：" prop="roleName">
            <el-input v-model="formData.roleName"></el-input>
          </el-form-item>
          <el-form-item class="com-base-info-right" label="角色描述：">
            <el-input v-model="formData.description"></el-input>
          </el-form-item>
        </div>
      </section>
      <section class="wrap-class menu-wrap">
        <title-style>角色菜单分配</title-style>
        <el-form-item class=" menu-con-wrap" label="请选择菜单：" prop="userId">
          <tree-transfer :title="title"
                         :from_data='permissionGroupList'
                         :to_data='formData.menus'
                         :defaultProps="{label:'menuChinaName'}"
                         @addBtn='add'
                         @removeBtn='remove'
                         :mode='mode' height='300px' filter openAll>
          </tree-transfer>
        </el-form-item>
        <section class="com-btn-wrap-center" style="text-align: center;line-height: 100px;">
          <el-button v-if="id" type="danger" @click="editRole" size="small">修改</el-button>
          <el-button v-else type="danger" @click="addRole" size="small">新增</el-button>
          <el-button @click="cancel" size="small">取消</el-button>
        </section>
      </section>
    </el-form>
  </div>
</template>

<script>
  import treeTransfer from 'el-tree-transfer' // 引入
  import validator from '@/utils/validator'
  export default{
    components:{ treeTransfer }, // 注册
    data(){
      return{
        id:this.$route.query.roleId,
        title: ["菜单列表", "已选菜单"],
        mode: "transfer",
        permissionGroupList:[],
        fromData:[],
        toData:[],
        formData:{
          roleName:'',
          description:'',
          menus:[],
        },
        rules:{
          roleName:[
            { required: true, message: '请输入角色名称', trigger: 'blur' },
            {validator: validator.notValidInputText, trigger: 'blur'}
          ],
        }
      }
    },
    created(){
      this.queryAllMenu();
      // if(this.id){
      //   this.queryDetail();
      // }
    },
    methods:{
      // 监听穿梭框组件添加
      add(fromData,toData,obj){
        // 树形穿梭框模式transfer时，返回参数为左侧树移动后数据、右侧树移动后数据、移动的        {keys,nodes,halfKeys,halfNodes}对象
        // 通讯录模式addressList时，返回参数为右侧收件人列表、右侧抄送人列表、右侧密送人列表
        //console.log("fromData:", fromData);
        //console.log("toData:", toData);
        // console.log("obj:", obj);
        this.fromData = fromData
        this.formData.menus = toData
        //console.log(this.fromData);
      },
      // 监听穿梭框组件移除
      remove(fromData,toData,obj){
        // 树形穿梭框模式transfer时，返回参数为左侧树移动后数据、右侧树移动后数据、移动的{keys,nodes,halfKeys,halfNodes}对象
        // 通讯录模式addressList时，返回参数为右侧收件人列表、右侧抄送人列表、右侧密送人列表
        /*console.log("fromData:", fromData);
        console.log("toData:", toData);
        console.log("obj:", obj);*/
        this.fromData = fromData
        this.formData.menus = toData
      },
      cancel(){
        this.$router.push('/permission/role-management');
      },
      //全部菜单查询
      queryAllMenu(){
        // debugger;
        this.$api.myApi.role.menuAll().then( res => {
          if(res.retCode == 0){
            //console.log(res.result.list);
            this.permissionGroupList = res.result.list;
            if(this.id){
              this.queryDetail();
            }
          }else{
            this.$message.error(res.retMsg);
          }
        })
      },
      //新增角色
      addRole(){
        if(this.formData.menus == '' || this.formData.menus.length == 0 ){
          this.$message.warning('请选择角色菜单分配！');
          return
        }
        this.$refs.form.validate(valid => {
          if(valid){
            this.$confirm('是否新增?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() =>{
              this.$api.myApi.role.roleInfoPost(this.formData).then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/role-management');
                }else{
                  this.$message.error(res.retMsg);
                }
              })
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '取消新增'
              });
            });
          }
        })
      },
      //查询角色详情
      queryDetail(){
        let params = {
          id:this.id
        }
        this.$api.myApi.role.roleInfoGet(params).then( res => {
          if(res.retCode == 0){
            if(!res.result.menus){
              res.result.menus = [];
            }
            this.formData = res.result;
            this.deWeight();
          }else{
            this.$message.error(res.retMsg);
          }
        })
      },
      //修改角色
      editRole(){
        if(this.formData.menus == '' || this.formData.menus.length == 0 ){
          this.$message.warning('请选择角色菜单分配！');
          return
        }
        this.$refs.form.validate(valid => {
          if(valid){
            let params = {
              roleId : this.id
            }
            Object.assign(params, this.formData);
            this.$confirm('是否修改?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() =>{
              this.$api.myApi.role.roleInfoPut(params).then( res => {
                if(res.retCode == 0){
                  this.$message.success(res.retMsg);
                  this.$router.push('/permission/role-management');
                }else{
                  this.$message.error(res.retMsg);
                }
              })
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '取消修改'
              });
            });

          }
        })
      },
      //去重
      deWeight(){
        if(this.formData.menus.length > 0){
          this.formData.menus.forEach((itemMenus, indexMenus) => {
            this.permissionGroupList.forEach((itemList, indexList) => {
              if(itemMenus.id == itemList.id){
                if(itemMenus.children == null || !itemMenus.children || itemMenus.children.length == itemList.children.length){
                  this.permissionGroupList.splice(indexList,1);
                  return;
                }else{
                  itemMenus.children.forEach((itemMenusChild, indexMenusChild) => {
                    itemList.children.forEach((itemListChild, indexListChild) => {
                      if(itemMenusChild.id == itemListChild.id){
                        itemList.children.splice(indexListChild,1);
                        return;
                      }
                    })
                  })
                }
              }
            })
          })
        }
      },
    }
  }
</script>

<style lang="scss" scoped>
  .menu-wrap{
    margin-top:10px;
  }
  .menu-con-wrap{
    padding:20px 30px;
  }
</style>
