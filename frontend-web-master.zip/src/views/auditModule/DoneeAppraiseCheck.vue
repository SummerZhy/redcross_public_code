<template>
    <!-- 审核处理-受赠人评价审核 -->
    <div>
        <section class="opration-wrap">
            <el-button type="danger" size="small" @click="batchOpration(1)">批量通过</el-button>
            <el-button size="small" @click="batchOpration(0)">批量删除</el-button>
        </section>
        <el-table
            ref="tableList"
            :data="tableData"
            :row-key="getRowKey"
            @selection-change="handelSelectChange"
            style="width: 100%">
            <el-table-column
                type="selection"
                reserve-selection
                width="50">
            </el-table-column>
            <el-table-column
                type="index"
                width="50"
                :index="getIndex"
                label="序号">
            </el-table-column>
            <el-table-column
                prop="projectCode"
                label="项目编码">
            </el-table-column>
            <el-table-column
                prop="beneficiaries"
                label="受捐人">
            </el-table-column>
            <el-table-column
                prop="amount"
                label="受捐金额">
            </el-table-column>
            <el-table-column
                prop="beneficialDate"
                label="受捐日期">
            </el-table-column>
            <el-table-column
                prop="commentStar"
                label="评价等级">
            </el-table-column>
            <el-table-column
                label="评价内容">
                <template slot-scope="scope" >
                    <div class="comment-wrap">
                        <!-- <p class="mini">{{scope.row.comment | contentSizeFilter}}</p> -->
                        <!-- <p class="big">{{scope.row.comment}}</p> -->
                        <el-tooltip class="item" effect="dark" :content="scope.row.comment" placement="bottom">
                            <span>{{scope.row.comment | contentSizeFilter}}</span>
                        </el-tooltip>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                width="200"
                label="操作">
                <template slot-scope="scope">
                    <el-button size="mini" type="danger" @click="opration('01', scope.row.projectCode, scope.row.cellphone)">通过</el-button>
                    <el-button size="mini" @click="opration('02', scope.row.projectCode, scope.row.cellphone)">删除</el-button>
                </template>    
            </el-table-column>
        </el-table>
        <el-pagination
            @size-change="getList"
            @current-change="getList"
            :current-page.sync="currentPage"
            :page-sizes="[10, 20,]"
            :page-size.sync="limit"
            layout="total, sizes, prev, pager, next, jumper"
            :total="totalNum">
        </el-pagination>
    </div>
</template>

<script>
export default {
    data(){
        return{
            tableData:[],
            totalNum:0,
            currentPage:1,
            limit:10,
            getRowKey:function(row){
                return row.projectCode
            },
            checkedList:[], //选中的
        }
    },
    created(){
        this.getList();
    },
    methods:{
        getIndex(index){
            return (this.currentPage - 1) * this.limit + index + 1 
        },
        getList(){
            let params = {
                currentPage: this.currentPage,
                limit: this.limit,
            }
            this.$api.myApi.checkDispose.outflowCommentList(params).then( res => {
                if(res.retCode == 0){
                    this.tableData = res.result.list;
                    this.totalNum = res.result.totalNum;
                }else{
                  this.$message.error(res.retMsg);
                }
            })
        },
        //单个通过 删除
        opration(checkStatus,projectCodes,cellphone){
            let tag = '';
            if(checkStatus == '01'){
                tag = '通过'
            }else{
                tag = '删除'
            }
            this.$confirm(`确定${tag}吗`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'info'
                }).then(() => {
                    let params = {
                        checkStatus: checkStatus,
                        list: [{
                            projectCodes: projectCodes,
                            cellphone: cellphone
                        }]
                    }
                    this.$api.myApi.checkDispose.putOutflowCommentInfo(params).then( res => {
                        if(res.retCode == 0){
                            this.$message.success(res.retMsg);
                            this.getList();
                        }else{
                        this.$message.error(res.retMsg);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: `取消${tag}`
                    });          
                });  
        },
        handelSelectChange(val){
            let checkedProjectCodes = val.map((item, index) => {
                let obj = {
                    projectCodes: item.projectCode,
                    cellphone: item.cellphone
                }
                return obj
            })
            this.checkedList = obj;
            console.log(this.checkedList);
        },
        //批量通过 删除
        batchOpration(checkStatus){
            if(this.checkedList.length == 0){
                this.$alert('请先选择', '提示', {
                    confirmButtonText: '确定',
                    callback: action => {
                        
                    }
                });
                return false;
            }
            let tag = '';
            if(checkStatus == '01'){
                tag = '通过'
            }else{
                tag = '删除'
            }
            this.$confirm(`确定${tag}吗`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'info'
                }).then(() => {
                    let params = {
                        checkStatus: checkStatus,
                        list: this.checkedList
                    }
                    this.$api.myApi.checkDispose.putOutflowCommentInfo(params).then( res => {
                        if(res.retCode == 0){
                            this.$message.success(res.retMsg);
                            this.$refs.tableList.clearSelection();
                            this.checkedList = [],
                            this.getList();
                        }else{
                        this.$message.error(res.retMsg);
                        }
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: `取消${tag}`
                    });          
                });  
        }
    },
    filters:{
        //内容字数过滤
        contentSizeFilter(val){
            return val.substring(0, 14) + '...'
            // return 1;
        }
    }
}
</script>

<style>
    .el-tooltip__popper{
        width:250px !important;
    }
</style>
<style lang="scss" scoped>
    .opration-wrap{
        text-align:right;
    }
    
</style>

