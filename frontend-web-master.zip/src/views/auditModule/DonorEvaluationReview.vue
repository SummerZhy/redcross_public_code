<template>
    <div class="main-con">
        <section class="wrap-class">
            <div class="com-operation-div">
                <el-button size="mini" @click="exportSelect(1)" title="批量审核通过">批量通过</el-button>
                <el-button size="mini" @click="exportSelect(2)" title="批量审核通过">批量删除</el-button>
                <section class="com-operation-right">
                    <div></div>
                </section>
            </div>
            <div class="con-list">
                <el-table
                        ref="tableList"
                        :data="tableData"
                        @selection-change="selectEven"
                        style="width: 100%">
                    <el-table-column
                            type="selection"
                            width="55">
                    </el-table-column>
                    <el-table-column
                            prop="cfundCode"
                            label="资金编码"
                    >
                    </el-table-column>
                    <el-table-column
                            prop="cdonerName"
                            label="捐赠人"
                    >
                    </el-table-column>
                    <el-table-column
                            prop="ntotalAmount"
                            label="捐赠金额">
                    </el-table-column>
                    <el-table-column
                            prop="dentryDate"
                            label="入账日期">
                    </el-table-column>
                    <el-table-column
                            prop="cfundState"
                            label="资金状态">
                    </el-table-column>
                    <el-table-column
                            prop="cscore"
                            label="评价等级">
                    </el-table-column>
                    <el-table-column
                            tooltip-effect="dark"
                            prop="cevaluation"
                            label="评价内容">
                      <!--  <template slot-scope="scope">
                            <el-popover trigger="hover" placement="top">
                                <p>评论: {{ scope.row.cEvaluation }}</p>
                                <div slot="reference" class="name-wrapper">
                                    <el-tag size="medium">{{ scope.row.cEvaluation }}</el-tag>
                                </div>
                            </el-popover>
                        </template>-->
                        <template slot-scope="scope" >
                            <div class="comment-wrap">
                                <!-- <p class="mini">{{scope.row.comment | contentSizeFilter}}</p> -->
                                <!-- <p class="big">{{scope.row.comment}}</p> -->
                                <el-tooltip class="item" effect="dark" :content="scope.row.cevaluation" placement="bottom">
                                    <span>{{scope.row.cevaluation | contentSizeFilter}}</span>
                                </el-tooltip>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                            fixed="right"
                            width="100"
                            label="操作">
                        <template slot-scope="scope">
                            <span class="com-click-class" @click="changeEven(scope.row.cfundCode ,1)" title="通过审核">通过</span>
                            <span class="com-click-class" style="margin-left: 5px" @click="changeEven(scope.row.cfundCode,2)" title="删除评论">删除</span>
                        </template>
                </el-table-column>
                </el-table>
                <el-pagination
                        @size-change="donorList"
                        @current-change="donorList"
                        :current-page.sync="queryForm.currentPage"
                        :page-sizes="[10, 20,]"
                        :page-size.sync="queryForm.limit"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalNum">
                </el-pagination>
            </div>
        </section>
    </div>
</template>

<script>
    export default {
        name: "DonorEvaluationReview",
        data(){
            return{
                operId:'',
                tableData:[],
                queryForm:{
                    limit:10,
                    currentPage:1,
                },
                totalNum:0,
                reportId:[],
                arrList:{},
            }
        },
        created(){
            this.donorList();
        },
        methods:{
            //捐赠人审核列表查询
            donorList(){
                this.$api.myApi.moneyHandling.donorListGet(this.queryForm)
                    .then(res =>{
                        if (res.retCode === '0'){
                            this.tableData = res.result.list;
                            this.totalNum = res.result.totalNum;
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //选中事件
            selectEven(val){
                let arr = val.map(item => {
                    return item.cFundCode;
                });
                this.arrList = val;
                //this.reportId = arr.toString();
                this.reportId = arr;
            },
            //选中勾选批量处理
            exportSelect(status){
                if(this.reportId.length == 0){
                    this.$alert('请至少勾选一项', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                        }
                    });
                    return false;
                }
                let tag = '';
                if(status == '01'){
                    tag = '通过'
                }else{
                    tag = '删除'
                }
                let params = {
                    cexamineStatus:status,
                    centryCode:this.reportId,
                };
                this.$confirm(`是否将选中项设置为${tag}?`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() =>{
                    this.$api.myApi.moneyHandling.donorListPut(params)
                        .then(res =>{
                            if (res.retCode === '0'){
                                this.$message.success(res.retMsg);
                                this.$refs.tableList.clearSelection();
                            }else{
                                this.$message.error(res.retMsg);
                            }
                        });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消审核通过'
                    });
                });
            },
            //审核通过删除事件
            changeEven(id,type){
                let tag = '';
                if(type == '01'){
                    tag = '通过'
                }else{
                    tag = '删除'
                }
                let params = {
                    centryCode:id,
                    cexamineStatus:type
                };
                this.$confirm(`是否将选中项设置为${tag}?`, '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() =>{
                    this.$api.myApi.moneyHandling.donorListPut(params)
                        .then(res =>{
                            if (res.retCode === '0'){
                                this.$message.success(res.retMsg);
                                this.donorList();
                            }else{
                                this.$message.error(res.retMsg);
                            }
                        });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消操作'
                    });
                });
            },
           /* //查询刷新
            refresh(){
                this.currentPage = 1;
                this.donorList();
            },*/

        },
        filters:{
            //内容字数过滤
            contentSizeFilter(val){
                return val.substring(0, 14) + '...'
            }
        }
    }
</script>

<style scoped lang="scss">
    .el-col-4 {
        float:right;
        text-align: right;
        line-height:41px;
    }


</style>
