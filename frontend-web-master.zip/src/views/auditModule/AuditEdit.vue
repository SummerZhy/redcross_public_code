<template>
    <div class="main-con">
        <div class="com-operation-div">
            <section class="com-operation-left">
                <div>入账详情</div>
            </section>
            <section class="com-operation-right">
                <div></div>
            </section>
        </div>
        <el-card class="susp-query-list">
            <el-form size="small">
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">入账信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="款项编码：">
                            <span>{{roleListData.cFundCode}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="日期：">
                            <span>{{roleListData.dEntryDate}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人姓名：">
                            <span>{{roleListData.cDonerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="联系方式：">
                            <span>{{roleListData.cDonorPhone}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="捐款人银行：">
                            <span>{{roleListData.cBankName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款人银行账户：">
                            <span>{{roleListData.cBankAcco}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐款金额：">
                            <span>{{roleListData.nTotalAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="已捐出：">
                            <span>{{roleListData.nUsedAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="剩余：">
                            <span>{{roleListData.nRemainAmount}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" v-if="roleListData.type != 2">
                        <el-form-item label="捐款方式：">
                            <span>{{roleListData.cDonateType}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="捐赠意向">
                            <span>{{roleListData.cIsDirect}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="物资分配：">
                            <span>{{roleListData.cDonateDirection}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="处理状态">
                            <span>{{roleListData.cHandleStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="审核状态：">
                            <span>{{roleListData.cExamineStatus}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{roleListData.cRemark1}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 10px">补录信息</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8" >
                        <el-form-item label="捐款人姓名：">
                            <span>{{supplement.cDonerName}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="身份证号：">
                            <span>{{supplement.cIdNo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="性别：">
                            <span>{{supplement.cSex}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="年龄：">
                            <span>{{supplement.cAge}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="职业：">
                            <span>{{supplement.cIdentityInfo}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" >
                        <el-form-item label="公示模式：">
                            <span>{{supplement.cEffectMode}}</span>
                        </el-form-item>
                    </el-col>
                    <el-col :span="16" >
                        <el-form-item label="备注：">
                            <span>{{supplement.cRemark2}}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
                <el-row>
                    <el-col>
                        <strong style="border-left: 2px solid red;padding-left: 15px; margin-bottom: 15px">审核操作</strong>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="16" >
                        <el-form-item label="补录信息：">
                            <el-select v-model="queryForm.cExamineStatus" placeholder="请选择">
                               <!-- <el-option
                                        v-for="item in checkValus"
                                        :key="item.paramId"
                                        :label="item.paramName"
                                        :value="item.paramId">
                                </el-option>-->
                                <el-option
                                        v-for="item in options"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="18" >
                        <el-form-item label="备注：">
                            <el-input v-model="queryForm.suggest" type="textarea"
                                      :rows="2"
                                      placeholder="请输入内容"
                            ></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-divider></el-divider>
            </el-form>
        </el-card>
        <section class="com-btn-wrap-center">
            <el-button @click="cancel" size="small">关闭</el-button>
            <el-button @click="changePut" size="small" type="danger">确定</el-button>
        </section>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex'
    export default{
        name: "AuditEdit",
        data(){
            return{
                id:this.$route.query.moneyId,
                roleListData:[],
                supplement:[],
                Situation:[],
                donerEvaluation:[],
                doneeEvaluation:[],
                activiti:[],
                review:[],
                icon: 'el-icon-more',
                type:'primary',
                options: [{
                    value: '01',
                    label: '审核通过'
                }, {
                    value: '02',
                    label: '审核退回'
                }],
                queryForm:{
                    suggest:'',
                    cExamineStatus:'',
                }
            }
        },
        computed:{
            ...mapGetters('dictionary', [
                'checkValus'
            ]),
        },
        created(){
            this.getDetails();
        },
        methods:{
            //详情
            getDetails(){
                let params = {
                    /*id:this.id*/
                    id:'this.id'
                }
                this.$api.myApi.moneyHandling.getMoneyDetail(params)
                    .then( res => {
                        if(res.retCode == 0){
                            this.roleListData = res.result.info; //入账信息
                            this.supplement = res.result.supplement;//补录信息
                            this.Situation = res.result.Situation.list;//使用情况
                            this.donerEvaluation = res.result.donerEvaluation;//捐款人评价
                            this.doneeEvaluation = res.result.doneeEvaluation;//受捐人评价
                            this.activiti = res.result.activiti;//流程跟踪
                            this.review = res.result.review;//审核操作
                            /*this.value = this.donerEvaluation.cEvaluation*/
                        }else{
                            this.$message.error(res.retMsg);
                        }
                    })
            },
            //关闭
            cancel(){
                this.$router.push('/moneyHandling/moneyHandling-list');
            },
            //确定事件
            changePut() {
               this.queryForm.cFundCode = 'this.id';//暂时这么写
               // this.queryForm.cFundCode = this.id; //真实对接时
                this.$confirm('确定修改？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$api.myApi.moneyHandling.auditInfoPut(this.queryForm)
                        .then((res) => {
                            if (res.retCode == '0') {
                                this.$message({
                                    type: 'success',
                                    message: res.retMsg,
                                    duration: 3 * 1000
                                });
                                this.$router.push('/auditModule/audit-list');
                            } else {
                                this.$message({
                                    type: 'warning',
                                    message: res.retMsg,
                                    duration: 3 * 1000
                                });
                            }
                        })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消修改'
                    });
                });
            },
        }
    }
</script>

<style lang="scss" scoped>
    .power-wrap{
        margin:10px 0 20px 0;
        .power-con-wrap{
            padding:20px 30px;
        }
    }
</style>
