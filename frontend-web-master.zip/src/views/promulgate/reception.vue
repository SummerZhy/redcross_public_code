<template>
    <div class="main-con">
        <h2>接收公示信息</h2>
        <div class="two">
            <el-table
                ref="multipleTable"
                :data="tableData"
                height="500"
                border
                style="width: 100%"
                >
                <el-table-column width="70px" align="center" label="序号">
                <template slot-scope="scope">
                    <span v-text="getIndex(scope.$index)"></span>
                </template>
                </el-table-column>
                <el-table-column
                prop="dEntryDate"
                label="日期">
                </el-table-column>
                <el-table-column
                prop="cDonerName"
                label="捐赠人/单位">
                </el-table-column>
                <el-table-column
                prop="nTotalAmount"
                label="金额(元)">
                </el-table-column>
                <el-table-column
                prop="cIsDirect"
                label="捐赠意愿">
                </el-table-column>
                <el-table-column
                prop="cRemark1"
                label="备注">
                </el-table-column>
            </el-table>
            <p style="line-height: 30px;font-size: 12px;">注：以上信息若有误，请及时联系我们查证，爱心电话：<a href="#" style="color: blue;">0546-8313089</a></p>
            <el-pagination
                @size-change="getInStaList"
                @current-change="getInStaList"
                :current-page="currentPage4"
                :page-sizes="[10,20]"
                :page-size="10"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
            </el-pagination>
        </div>
    </div>
</template>
<script>
    export default {
        name:"reception",
        data() {
            return {
                activeName: 'information',
                queryForm:{
                    currentPage:1,
                    limit:10
                },
                currentPage4:2,
                totalNum:'',
                tableData:[],
            };
        },
        created(){
           this.getInStaList();
            
        },
        methods: {
            //tab
            handleClick(tab, event) {
                console.log(tab, event);
            },
            // tab2
            //表格序号
            getIndex($index) {
             return (this.queryForm.currentPage - 1) * this.queryForm.limit + $index + 1
            },
            getInStaList(){
                let param=this.queryForm
                this.$api.myApi.promulgate.getInStaList(param)
                .then(res => {
                    if (res.retCode == 0) {
                            console.log('2',res)
                            this.totalNum = res.result.totalNum;
                            this.tableData = res.result.list;
                        } else {
                            this.$message.error(res.retMsg);
                        }
                    })
            },
           
        },
    };
</script>
<style lang="scss" scoped>
        h2{
            width:100%;
            padding-left:1%;
            line-height:30px;
            background-color:rgba(242, 242, 242, 1);
            margin-bottom: 20px;
        }
        .main-con /deep/ .el-tabs__item{
            font-size: 14px;
        }
        .one,.two{
            width: 100%;
            height: 600px;
        }
        h6{
            border: 1px solid #F2F2F2;
            background:#FCFCFC;
            width: 90%;
            line-height: 26px;
            font-size: 12px;
            padding-left: 10px;
        }
        .one-left,.one-right{
            border: 1px solid #F2F2F2;
            width: 40%;
            height: 80px;
            p{
                font-size: 12px;
                margin-left:24px;
                line-height:30px;
            }
            span{
                margin-left: 50%;
                transform: translateX(-50%);
                font-weight: 600;
                font-size: 16px;
            }
        }
        
</style>    