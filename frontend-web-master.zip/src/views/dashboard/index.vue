<template>
  <div class="dashboard-container">
    <a href="" target="_blank"><img style="margin: 40px"
      src=""></a>
  </div>
</template>
<script>
  export default {
    name: 'dashboard',
    data() {
      return {}
    },
  }
</script>
