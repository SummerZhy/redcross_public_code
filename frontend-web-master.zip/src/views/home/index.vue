<template>
  <div>
    <el-form class="com-base-info-wrap " ref="form" label-width="110px" label-position="left">
      <div class="left">
        <div v-for="(item,index) in formData1" :key="index">
          <p>{{item.menuName}}</p>
          <ul style="overflow-x: hidden;width: 317px;">
            <ul style="overflow-x:hidden;width:325px;height:107px;">
              <li v-for="(i,n) in item.children" :key="n"><span v-if="i">{{i.content}}{{i.count}}条</span>
                <button v-if="i" @click="turn(i.path)">处理</button>
                <h5 v-else>暂无处理信息</h5></li>
            </ul>

          </ul>
        </div>
      </div>
      <div class="right">
        <div class="r-top">
          <p>工作统计</p>
          <p>{{totaTodolNum}}</p>
          <span> <span></span> 累计待处理</span>
        </div>
        <div class="r-bottom">
          <p><span>快捷操作</span>
            <button @click="search">管理</button>
          </p>
          <div class="r-b-b">
            <div class="r-b-bottom" v-for="(item,index) in formData2" :key="index" @click="turn(item.path)"
                 style="overflow:hidden">
              <p>{{item.menuName}}</p>
            </div>
          </div>
        </div>
      </div>
    </el-form>
    <el-dialog
      title="快捷操作菜单管理"
      :visible.sync="fold"
      width="50%"
      center
      class="el">
        <span style="display:block;height:396px;">
          <el-input
            placeholder="输入关键字进行过滤"
            v-model="filterText">
          </el-input>
          <el-tree
            class="filter-tree"
            show-checkbox
            :data="formData3"
            :props="defaultProps"
            :filter-node-method="filterNode"
            ref="tree"
            node-key="menuChinaName"
            :default-expanded-keys="defaultCheck"
            :default-checked-keys="defaultCheck"
            @check="handleButton"
            style="display:block;height:356px;overflowX:hidden;border-bottom: 1px solid #DCDFE6; ">
          </el-tree>
        </span>
      <span slot="footer" class="dialog-footer">
          <el-button type="danger" @click="change">确 定</el-button>
          <el-button @click="back">取 消</el-button>
        </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "index",
    data() {
      return {
        defaultCheck: [],
        filterText: '',
        fold: false,
        roles: [],
        formData1: {},
        formData2: {},
        formData3: {},
        totaTodolNum: 0,
        menuArray: [],
        defaultProps: {
          children: 'children',
          label: 'menuChinaName'
        }
      }
    },

    watch: {
      roles(val, oldVal) {
        return val;
      },
      filterText(val) {
        this.$refs.tree.filter(val);
      }
    },
    created() {
      // this.getUserList();
      // this.getMenuList();
    },
    methods: {
      // 待办事项列表查询

      //处理按钮跳转页面
      turn(path) {
        this.$router.push({
          path,
        });
      },
      //菜单查询
      getMenuList() {
        let params = {roleId: window.localStorage.getItem('roleId') || ''}
        this.$api.myApi.home.fastMenu(params)
          .then(res => {
            if (res.retCode == '0') {
              this.formData2 = res.result.list;
            } else {
              this.$message.error(res.retMsg);
            }
          })
      },
      //角色查询
      search() {
        this.fold = true;
        this.defaultCheck = []
        for (let a of this.formData2) {
          this.defaultCheck.push(a.menuName)
        }
        let params = {id: window.localStorage.getItem('roleId') || ''}
        this.$api.myApi.role.roleInfoGet(params)
          .then(res => {
            if (res.retCode == '0') {
              if (!res.result.menus) {
                res.result.menus = [];
              }
              this.formData3 = res.result.menus;
            } else {
              this.$message.error(res.retMsg);
            }
          })
      },
      filterNode(value, data) {
        if (!value) return true;
        return data.menuChinaName.indexOf(value) !== -1;
      },
      setCheckedKeys() {
        this.$refs.tree.setCheckedKeys([3]);
      },
      handleButton(data, checked) {
        // console.log('111111111111',data,checked.checkedNodes);
        let arr = [];
        for (let a of checked.checkedNodes) {
          if (!a.children) {
            arr.push(a.id);
          }
        }
        this.menuArray = arr;
        // if(data.children){
        //   判断是全选则把children的menu存进数组
        //   否则从数组删除children的menu
        // }else{
        //   判断是选中则把自己的menu存进数组
        //   否则从数组删除自己的menu
        // }
      },
      //取消
      back() {
        this.fold = false;
      },
      //修改菜单
      change() {
        if (this.menuArray.length > 6) {
          this.$message.error('最多选择6个');
          return
        }
        let params = {
          roleId: window.localStorage.getItem('roleId'),
          list: this.menuArray
        }
        this.$api.myApi.home.meuPut(params)
          .then(res => {
            if (res.retCode == '0') {
              this.formData2 = res.result.list
              this.fold = false;
            } else {
              this.$message.error(res.retMsg);
            }
          })
      },
    }
  }
</script>

<style scoped lang="scss">
  .com-base-info-wrap {
    display: flex;
    flex-flow: row nowrap;
    justify-content: flex-start;
    align-content: flex-start;
    padding: 0;
    overflow-Y: hidden;
  }

  .left, .right {
    color: #fff;
    display: inline-block;
  }

  .left {
    width: 790px;
    display: flex;
    flex-flow: row wrap;
    justify-content: space-between;
    align-content: flex-start;
    margin-bottom: 20px;
    margin-right: 10px;
  }

  .left > div, .right > div {
    border-radius: 8px;
  }

  .left > div {
    width: 390px;
    height: 190px;
    background: linear-gradient(#7382E7, #5664C0);
    margin-bottom: 10px;
    border-radius: 8px;
    padding: 31px 20px 22px 45px;
  }

  .left > div > p {
    line-height: 30px;
    font-size: 18px;
    font-family: PingFangSC-Semibold;
  }

  .left li {
    width: 325px;
    line-height: 20px;
    padding: 4px 10px 4px 0;
  }

  .left ul span {
    line-height: 20px;
  }

  .left ul button {
    width: 60px;
    line-height: 20px;
    text-align: content;
    border: none;
    border-radius: 5px;
    background: #fff;
    float: right;
  }

  .r-top {
    width: 516px;
    height: 218px;
    background: linear-gradient(#FF636D, #DD4650);
    padding: 31px 30px;
    margin-bottom: 10px;
  }

  .r-top > p:nth-of-type(1) {
    line-height: 30px;
    font-size: 18px;
    font-family: PingFangSC-Semibold;
    margin-bottom: 29px;
  }

  .right > div > p:nth-of-type(2), .right > div > span {
    display: block;
    margin-left: 50%;
    transform: translateX(-50%);
    text-align: center;
  }

  .right > div > p:nth-of-type(2) {
    font-family: DINAlternate-Bold;
    font-size: 50px;
    margin-bottom: 10px;
  }

  .right > div > span > span {
    display: inline-block;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #F5FF52;
    margin-right: 10px;
    font-family: PingFangSC-Semibold;
  }

  .r-bottom {
    width: 516px;
    height: 362px;
    background: #FFFFFF;
    box-shadow: 0 2px 4px 0 rgba(190, 190, 190, 0.12);
    border-radius: 8px;
    border-radius: 8px;
    padding-top: 26px;
  }

  .r-bottom > p {
    width: 440px;
    height: 28px;
    display: flex;
    flex-flow: row wrap;
    justify-content: space-between;
    align-content: flex-start;
    margin-left: 45px;
    margin-bottom: 25px;
  }

  .r-bottom > p > span {
    font-family: PingFangSC-Semibold;
    font-size: 18px;
    color: #000000;
    line-height: 28px;
  }

  .r-bottom > p > button {
    width: 56px;
    height: 28px;
    background: #C8424B;
    border-radius: 4px;
    border: none;
    color: #FFFFFF;
    font-family: PingFangSC-Regular;
    font-size: 14px;
    outline: none;
  }

  .r-b-b {
    width: 440px;
    display: flex;
    flex-flow: row wrap;
    justify-content: space-between;
    align-content: flex-start;
    margin-left: 45px;
  }

  .r-b-bottom {
    width: 210px;
    height: 48px;
    border: 1px solid #DCDFE6;
    border-radius: 4px;
    margin-bottom: 6px;
  }

  .r-b-bottom > p {
    font-family: PingFangSC-Regular;
    color: #798082;
    letter-spacing: 0.24px;
    text-align: center;
    line-height: 48px;
  }

  .el /deep/ .el-dialog__body {
    padding: 0;
  }
</style>
