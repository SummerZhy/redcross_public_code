import axios from 'axios'
// import QS from 'qs'
import {Message, MessageBox} from 'element-ui'
import {getToken, setToken, removeToken} from '@/utils/auth'
import store from '../store'
import apis from '@/api/api'
import router from '../router'

axios.defaults.timeout = 120000
axios.defaults.baseURL = process.env.BASE_URL
axios.defaults.responseType = 'json'
axios.defaults.isRetryRequest = false
axios.defaults.headers = {
  'Content-Type': 'application/json;charset=UTF-8',
  'CHANNEL-TYPE': 'PC'
}
/*axios.defaults.headers = {
  'Content-Type': 'application/x-www-form-urlencoded'
}*/

// request拦截器
axios.interceptors.request.use(
  config => {
    //console.log('-------------'+JSON.stringify(config));
    //每次请求前判断是否存在token
    //如果存在则统一在http请求的header中加上token
    const token = getToken()
    if (token) {
      config.headers.Authorization = `${token}`
    }
    return config
  }, error => {
    Promise.reject(error)
  })
// respone拦截器
axios.interceptors.response.use(
  response => {
    const res = response.data;
    //登陆超时
    if (res.retCode == "22009" || res.retCode == "22008") {
      //alert('登陆超时');
      Message({
        showClose: true,
        message: res.retMsg,
        // type: 'error',
        duration: 3 * 1000,
        onClose: () => {
          store.dispatch('FedLogOut').then(() => {
            location.reload()// 为了重新实例化vue-router对象 避免bug
          })
        }
      });
      return Promise.reject("未登录")
      //全局错误提示
    } else if (res.retCode == "22007") {
      return apis.myApi.getNewToken()
        .then(res => {
          if (res.data.retCode == '0') {
            removeToken()
            let token = setToken(res.headers.authorization)
            let config = response.config
            if (!config.isRetryRequest) {
              config.headers.Authorization = token
              let url = response.config.url
              if (response.config.data) {
                config.data = response.config.data
              }
              //config.url = url.substr(4)
              config.url = url.substring(url.indexOf('api/') + 3)
              /*console.log(`上次请求地址：${url}`)
              console.log(`上次请求参数：${param}`)*/
              config.isRetryRequest = true
              return axios(config)
            }
          }
        })
    } else {
      return response
    }
  },
  error => {
    if (error && error.response) {
      switch (error.response.status) {
        case 400:
          error.message = '请求错误（400）';
          break;
        case 401:
          error.message = ' 未授权请重新登陆（401）';
          break;
        case 403:
          error.message = '请求错误（403）';
          break;
        case 404:
          error.message = '请求错误（404）';
          break;
        case 408:
          error.message = '请求错误（408）';
          break;
        case 501:
          error.message = '请求错误（501）';
          break;
        case 502:
          error.message = '请求错误（502）';
          break;
        case 503:
          error.message = '请求错误（503）';
          break;
        case 504:
          error.message = '请求错误（504）';
          break;
        case 505:
          error.message = '请求错误（505）';
          break;
        default:
          error.massage = `连接出错（${error.response.status}）!`
      }
    } else {
      error.message = '连接服务器失败！'
    }
    Message({
      message: error.message,
      type: 'error',
      duration: 3 * 1000
    })
    return Promise.reject(error)
  }
)

/**
 * 封装get方法
 * @param url
 * @param data
 * @returns {promise}
 * */
export function get(url, params = {}) {
  return new Promise((resolve, reject) => {
    axios.get(url, {
      params: params
    }, {
      onDownloadProgress(process) {
        console.log(process.loaded / process.total * 100)
      }
    })
      .then(response => {
        if (response != undefined) {
          resolve(response.data)
        } else {
          this.$message.warning(response.data.retMsg)
        }
      })
      .catch(err => {
        reject(err)
      })
  })
}

export function get1(url, params = {}) {
  return new Promise((resolve, reject) => {
    axios.get(url, {
      params: params
    })
      .then(response => {
        resolve(response)
      })
      .catch(err => {
        reject(err)
      })
  })
}

/**
 * 封装post方法
 * @param url
 * @param data
 * @returns {promise}
 * */
export function post(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.post(url, data)
    //axios.post(url, QS.stringify(data))
      .then(response => {
        resolve(response.data)
      }).catch(err => {
      reject(err)
    })
  })
}

/**
 * 封装post方法,返回response
 * @param url
 * @param data
 * @returns {promise}
 * */
export function postResponse(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.post(url, data)
    //axios.post(url, QS.stringify(data))
      .then(response => {
        resolve(response)
      }).catch(err => {
      reject(err)
    })
  })
}

/**
 * 封装put方法
 * @param url
 * @param data
 * @returns {promise}
 * */
export function put(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.put(url, data)
      .then(response => {
        resolve(response.data)
      })
      .catch(err => {
        reject(err)
      })
  })
}

/**
 * 封装patch方法
 * @param url
 * @param data
 * @returns {promise}
 * */
export function patch(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.patch(url, data)
      .then(response => {
        resolve(response.data)
      })
      .catch(err => {
        reject(err)
      })
  })
}

/**
 * 封装delete方法
 * @param url
 * @param data
 * @returns {promise}
 * */
export function del(url, params = {}) {
  return new Promise((resolve, reject) => {
    axios.delete(url, {
      params: params
    })
      .then(response => {
        resolve(response.data)
      })
      .catch(err => {
        reject(err)
      })
  })
}

