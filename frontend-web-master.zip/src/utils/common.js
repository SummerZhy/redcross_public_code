export default {
  dataURLtoBlob(res, type) {
    let bstr = window.atob(res)
    let n = bstr.length
    let u8arr = new Uint8Array(n)
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n)
    }
    return new Blob([u8arr], {type: type});
  },
  /**
   * @name dataToFile
   * @param data
   * @param fileName
   * @param type
   * */
  dataToFile(data, fileName, type) {
    //判断数据是否存在
    if (typeof data == 'string') {
      let bstr = window.atob(data)
      let n = bstr.length
      let u8arr = new Uint8Array(n)
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n)
      }
      let blob = new Blob([u8arr], {type: type});
      let alink = document.createElement('a');
      alink.href = window.URL.createObjectURL(blob);
      alink.download = fileName;
      alink.click();
      URL.revokeObjectURL(alink.href);
      return true;
    } else {
      return false;
    }
  },
  omit(obj, uselessKeys) {
    uselessKeys.forEach(key => {
      delete obj[key]
    })
    return obj;
  }
}
