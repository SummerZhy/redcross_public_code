import CryptoJs from 'crypto-js'
import JSEncrypt from "jsencrypt";

export default {
  // DES加密
  encryptByDES: function (message, key) {
    //debugger
    const keyHex = CryptoJs.enc.Utf8.parse(key)
    const encrypted = CryptoJs.TripleDES.encrypt(message, keyHex, {
      mode: CryptoJs.mode.ECB,
      padding: CryptoJs.pad.Pkcs7
    })
    return encrypted.toString()
  },
  // DES解密
  decryptByDES (ciphertext, key) {
    const keyHex = CryptoJs.enc.Base64.parse(key)
    const decrypted = CryptoJs.TripleDES.decrypt({
      ciphertext: CryptoJs.enc.Base64.parse(ciphertext)
    }, keyHex, {
      mode: CryptoJs.mode.ECB,
      padding: CryptoJs.pad.Pkcs7
    })
    return decrypted.toString(CryptoJs.enc.Utf8)
  },

  /**
   * RSA加密
   * @param code 加了盐的密码
   * @param key 公钥，不写的话直接从环境变量中获取PUB_KEY
   */
  encryptByRSA(code, salt, key) {
    // BETTER 这个对象是不是可以缓存在什么地方重复使用？
    let encryptor = new JSEncrypt();
    // key = key || process.env.PUB_KEY;
    key = key || 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApOVkDk3ldNsXZIoeFbXfEI4LQqN9nQcpXrqs8sQrwGWSbixMjxVYIJLvNg8rzCHmyAp75i4trif5IZFyZXXp34XJmQA4VZTrG6w04H9VJ64vQrQfrTYCqaeExurNvk/kllHMwioFJY8noFsYL3WtGo736ETPWTBZM4zcsUaCLv9f91Ek5xRMegdNqqaqvqukX7DxXPIP9uTusiIOde8p7gbulqSZNwJN5FiZR46W/6zLBG8/vTxNx1claQ3b+FqIszQA2iL7FjgUH4veGStlXM8vB9DJXnMFHx1Da/tUxNJQHccdmu+/gzgqEHZmzVMlqjC5Oj6vQIfHHUdbr9rpsQIDAQAB';
    encryptor.setPublicKey(key);
    return encryptor.encrypt(code + salt);
  },

}
