import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
    {
        path: '/promulgate',
        component: Layout,
        name: '公示模块',
        meta: {title: '公示模块', icon: 'set'},
        menu: 'promulgate',
        children: [
          {
            path: 'reception',
            name: '接收公示',
            component: _import('promulgate/reception'),
            meta: {title: '接收公示', icon: '', keepAlive:true, isBack:false},
            menu: 'reception'
          },
          {
            path: 'donation',
            name: '捐赠公示',
            component: _import('promulgate/donation'),
            meta: {title: '捐赠公示', icon: '',keepAlive:true, isBack:false},
            menu: 'donation'
          },
        ]
      }
    ];
