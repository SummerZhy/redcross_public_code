import Vue from "vue";
import Router from "vue-router";
// in development env not use Lazy Loading,because Lazy Loading too many pages will cause webpack hot update too slow.so only in production use Lazy Loading
/* layout */
import Layout from "../views/layout/Layout";
// import activityManage from "./activityManage";
//import memberManage from "./memberManage";
import sysManage from "./sysManage";
import moneyHandling from "./moneyHandling"; //善款处理
import auditModule from "./auditModule"; //审核处理
import statistics from "./statistics";
import promulgate from "./promulgate";
import fundRetrospect from "./fundRetrospect"; //资金追溯


const _import = require("./_import_" + process.env.NODE_ENV);
Vue.use(Router);
export const constantRouterMap = [
  {path: '/login', component: _import('login/Login'), hidden: true},
  {path: '/user-register', component: _import('login/UserRegister'), hidden: true},
  {path: '/user-modify', component: _import('login/UserModify'), hidden: true},
  {path: '/user-forget', component: _import('login/UserForget'), hidden: true},
  {path: '/404', component: _import('404'), hidden: true},
  /**退出系统*/
  {
    path: '/logout', component: Layout, hidden: true, name: '退出系统', children: [
      {path: 'account', name: '个人账号', component: _import('logout/account'), hidden: true},
      {path: 'changePassword', name: '修改密码', component: _import('logout/change'), hidden: true},
    ]
  },
  {
    path: '/', component: Layout, redirect: '/home', name: '首页', hidden: true,
  },
  /**首页*/
  {
    path: '', component: Layout, children:
      [
        {path: 'home', component: _import('home/index'), name: '主页', meta: {title: '首页', icon: 'home',keepAlive:true, isBack:false}}
      ],
  },
  {path: '*', redirect: '/404', hidden: true},
  ...sysManage,
  ...moneyHandling,
  ...auditModule,
  ...statistics,
  ...promulgate,
  ...fundRetrospect,
  // ...memberManage,
  //...activityManage,

];
export default new Router({
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({
    y: 0
  }),
  routes: constantRouterMap
});
export const asyncRouterMap = [
  // {
  //   path: "*",
  //   redirect: "/404",
  //   hidden: true
  // }
];
