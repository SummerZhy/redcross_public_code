/* layout */

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
  {
    path: "/examinationPaper",
    name: "捐赠人追溯",
    component: _import("fundRetrospect/DonorRetrospect"),
    meta: { title: "捐赠人追溯" },
    menu: "examinationPaper"
  },
  {
    path: "/clubactivity",
    name: "受捐人追溯",
    component: _import("fundRetrospect/DoneeRetrospect"),
    meta: { title: "受捐人追溯" },
    menu: "clubactivity"
  },
  /*{
    path: "/fundRetrospect",
    component: Layout,
    name: "资金追溯",
    meta: { title: "资金追溯", icon: 'set' },
    children: [
      {
        path: "examinationPaper",
        name: "捐赠人追溯",
        component: _import("fundRetrospect/DonorRetrospect"),
        meta: { title: "捐赠人追溯" },
        menu: "examinationPaper"
      },
      {
        path: "clubactivity",
        name: "受捐人追溯",
        component: _import("fundRetrospect/DoneeRetrospect"),
        meta: { title: "受捐人追溯" },
        menu: "clubactivity"
      }
    ]
  }*/
];
