import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
    {
        path: '/moneyHandling',
        component: Layout,
        name: '善款处理',
        meta: {title: '善款处理', icon: 'donation'},
        menu: 'moneyHandling',
        children: [
            {
                path: 'moneyHandling-list',
                name: '资金接收',
                component: _import('moneyHandling/MoneyHandlingList'),
                meta: {title: '资金接收', icon: '', keepAlive:true, isBack:false},
                menu: 'moneyHandling-list'
            },
            {
                path: 'moneyHandling-details',
                name: '银行入账详情信息',
                component: _import('moneyHandling/MoneyHandlingDetails'),
                meta: {title: '银行入账详情信息', icon: '',keepAlive:true, isBack:false},
                menu: 'moneyHandling-details',
                hidden: true
            },
            {
                path: 'moneyHandling-supplement',
                name: '银行入账补录',
                component: _import('moneyHandling/MoneyHandlingSupplement'),
                meta: {title: '银行入账补录', icon: '',keepAlive:true, isBack:false},
                menu: 'moneyHandling-supplement',
                hidden: true
            },
            {
                path: 'audit-return',
                name: '审核退回处理',
                component: _import('moneyHandling/AuditReturn'),
                meta: {title: '审核退回处理', icon: '',keepAlive:true, isBack:false},
                menu: 'audit-return',
            },
            {
                path: 'audit-details',
                name: '审核退回处理详情',
                component: _import('moneyHandling/AuditReturnDetails'),
                meta: {title: '审核退回处理详情', icon: "", keepAlive:true, isBack:false},
                menu: 'role-management',
                hidden: true
            },
           {
                path: 'audit-edit',
                name: '审核退回处理编辑',
                component: _import('moneyHandling/AuditReturnEdit'),
                meta: {title: '审核退回处理编辑', icon: "",keepAlive:true, isBack:false},
                menu: 'audit-edit',
                hidden: true
            },
            {
                path: "FundEmploy",
                name: "资金使用",
                component: _import("moneyHandling/FundEmploy"),
                meta: { title: "资金使用" },
                menu: "examinationPaper"
            },
        ]
    }
];
