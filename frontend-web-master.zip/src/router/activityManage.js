/* layout */
import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
  {
    path: "/activity",
    component: Layout,
    name: "活动管理",
    meta: { title: "活动管理" },
    children: [
      {
        path: "examinationPaper",
        name: "工会活动管理",
        component: _import("activity/examinationPaper/index"),
        meta: { title: "工会活动管理" },
        menu: "examinationPaper"
      },
      {
        path: "clubactivity",
        name: "社团活动管理",
        component: _import("activity/clubactivity/index"),
        meta: { title: "社团活动管理" },
        menu: "clubactivity"
      }
    ]
  }
];
