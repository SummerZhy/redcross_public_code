/**
 * Created by lpj on 2020/2/13.
 */

import Layout from "../views/layout/Layout";

const _import = require("./_import_" + process.env.NODE_ENV);

export default [
    {
        path: '/permission',
        component: Layout,
        name: '系统管理',
        meta: {title: '系统管理', icon: 'set'},
        menu: 'permission',
        children: [
          {
            path: 'user-management',
            name: '用户管理',
            component: _import('permission/UserManagement'),
            meta: {title: '用户管理', icon: '', keepAlive:true, isBack:false},
            menu: 'user-management'
          },
          {
            path: 'user-add',
            name: '新增用户',
            component: _import('permission/UserAdd'),
            meta: {title: '新增用户', icon: '',keepAlive:true, isBack:false},
            menu: 'user-add',
            hidden: true
          },
          {
            path: 'user-modify',
            name: '修改用户',
            component: _import('permission/UserAdd'),
            meta: {title: '修改用户', icon: '',keepAlive:true, isBack:false},
            menu: 'user-modify',
            hidden: true
          },
          {
            path: 'user-info',
            name: '用户详情',
            component: _import('permission/UserInfo'),
            meta: {title: '用户详情', icon: '',keepAlive:true, isBack:false},
            menu: 'user-info',
            hidden: true
          },
          {
            path: 'role-management',
            name: '角色管理',
            component: _import('permission/RoleManagement'),
            meta: {title: '角色管理', icon: "", keepAlive:true, isBack:false},
            menu: 'role-management',
          },
          {
            path: 'role-add',
            name: '新增角色',
            component: _import('permission/RoleAdd'),
            meta: {title: '新增角色', icon: "",keepAlive:true, isBack:false},
            menu: 'role-add',
            hidden: true
          },
          {
            path: 'role-modify',
            name: '修改角色',
            component: _import('permission/RoleAdd'),
            meta: {title: '修改角色', icon: "",keepAlive:true, isBack:false},
            menu: 'role-modify',
            hidden: true
          },
          {
            path: 'role-info',
            name: '角色详情',
            component: _import('permission/RoleInfo'),
            meta: {title: '角色详情', icon: "",keepAlive:true, isBack:false},
            menu: 'role-info',
            hidden: true
          },
          {
            path: 'org-management',
            name: '机构管理',
            component: _import('permission/OrgManagement'),
            meta: {title: '机构管理', icon: '',keepAlive:true, isBack:false},
            menu: 'org-management'
          },
          {
            path: 'org-details',
            name: '机构详情',
            component: _import('permission/OrgDetails'),
            meta: {title: '机构详情', icon: "",keepAlive:true, isBack:false},
            menu: 'branch-detail',
            hidden: true
          },
          {
            path: 'operation-log',
            name: '操作日志查询',
            component: _import('permission/OperationLog'),
            meta: {title: '操作日志查询', icon: '',keepAlive:true, isBack:false},
            menu: 'operation-log'
          },
          {
            path: 'branch-add',
            name: '新增机构',
            component: _import('permission/BranchAdd'),
            meta: {title: '新增机构', icon: "",keepAlive:true, isBack:false},
            menu: 'branch-add',
            hidden: true
          },
          {
            path: 'branch-modify',
            name: '修改机构',
            component: _import('permission/BranchAdd'),
            meta: {title: '修改机构', icon: "",keepAlive:true, isBack:false},
            menu: 'branch-modify',
            hidden: true
          },
          {
            path: 'info-set',
            name: '信息公示设置',
            component: _import('permission/InformationSettings'),
            meta: {title: '信息公示设置', icon: '',keepAlive:true, isBack:false},
            menu: 'info-set'
          },
        ]
      }
    ];
