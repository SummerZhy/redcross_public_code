import Vue from 'vue'
import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locale from 'element-ui/lib/locale/lang/zh-CN'
import echarts from 'echarts'  
import App from './App'
import router from './router'
import store from './store'
import '@/assets/icons' // icon
import '@/permission' // 权限
import axios from 'axios'
import {
  default as myApi
} from './api/api'
// import myScoreApi from './api/scoreManagement'
import {
  hasPermission
} from "./utils/hasPermission";

import {
  post,
  get,
  patch,
  put
} from './utils/http'


Vue.prototype.$echarts = echarts
Vue.use(ElementUI, {
  locale
})
//Vue.prototype.api = api
Vue.prototype.$api = myApi
// Vue.prototype.$scoreApi = myScoreApi
axios.defaults.baseURL = '/api'
//全局的常量
Vue.prototype.hasPerm = hasPermission
//生产环境时自动设置为 false 以阻止 vue 在启动时生成生产提示。
Vue.config.productionTip = (process.env.NODE_ENV != 'production')
Vue.filter('money',function(item){
  if(item){
    var val = item;
    val = val.toString().replace(/\$|\,/g,'');
    if(isNaN(val)){
      val = "0";
    }
    let sign = (val == (val = Math.abs(val)));
    val = Math.floor(val*100+0.50000000001);
    let cents = val%100;
    val = Math.floor(val/100).toString();
    if(cents<10){
      cents = "0"+cents
    }
    for(var i = 0; i<Math.floor((val.length-(1+i))/3);i++){
      val = val.substring(0,val.length-(4*i+3))+','+val.substring(val.length-(4*i+3));
    }
    return (((sign)?'':'-') + val +'.' + cents);
  }else{
    return null
  }
  
})
//全局组件
import TitleOperation from '@/components/TitleOperation/index.vue'
Vue.component('TitleOperation', TitleOperation);

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
}).$mount('#app')