<template>
  <el-table :data="data" ref="commonTable" v-loading="loading" size="mini">
    <slot name="front"></slot>
    <el-table-column align="center" label="序号" width="50">
      <template slot-scope="scope">
        <span v-text="getIndex(scope.$index)"> </span>
      </template>
    </el-table-column>
    <el-table-column v-for="(column, index) in columns"
                     :key="column.value"
                     :label="column.text"
                     :width="column.width"
                     align="center">
      <template slot-scope="scope">
        {{scope.row[column.value]}}
      </template>
    </el-table-column>
    <slot name="back"></slot>
  </el-table>

</template>

<script>
  import {mapGetters} from 'vuex'

  export default {
    name: "CommonTable",
    props: {
      data: {
        type: Array,
        required: true,
      },
      columns: {
        type: Array,
        default: () => [],
      },
      queryData: {
        type: Object,
        required: true,
      },
      totalNum: {
        type: Number,
        default: 0,
      },
      listData: [],
    },
    computed: {
      ...mapGetters('risk', [
        'loading',
      ])
    },
    methods: {
      getIndex($index) {
        //表格序号
        return (this.queryData.currentPage - 1) * this.queryData.limit + $index + 1
      },
    }
  }
</script>

<style scoped>

</style>
