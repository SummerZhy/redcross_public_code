<template>
  <div class="title-style">
    <slot></slot>
  </div>
</template>

<script>
  export default{
    name:'titleStyle'
  }
</script>

<style lang="scss" scoped>
  @import '../../styles/variables.scss';
  .title-style{
    padding:15px 30px;
    color:$mainTitle;
    font-weight:bold;
    border-bottom:1px solid  #DCDFE6;
  }
</style>
