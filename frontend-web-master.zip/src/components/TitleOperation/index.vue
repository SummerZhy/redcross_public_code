<template>
  	<div class="title-operation">
        <section class="title-wrap">
            {{title}}
        </section>
        <section class=btn-wrap>
            <slot></slot>
        </section>
    </div>
</template>
<script>
export default {
    name:'TitleOperation',
  	data(){
    	return{

    	}
      },
      props:['title'],
}
</script>
<style scoped lang=scss>
    .title-operation{
        display:flex;
        justify-content:space-between;
        place-items: center;
        padding:10px;
        border-bottom:1px solid #ebeef5;
    }
</style>