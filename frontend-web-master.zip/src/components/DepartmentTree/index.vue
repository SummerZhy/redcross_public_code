<template>
    <el-dialog title="机构树" :visible.sync="jumpValue" append-to-body>
      <tree-table :data="objectList"
                  :columns="columns"
                  :expandAll="true"
                  size="mini"
                  element-loading-text="加载中">
        <template #frontSlot >
          <el-table-column label="选择" align="center" width="100">
            <template slot-scope="scope">
              <el-radio v-model="selectOrg" :label="scope.row.branchId">&nbsp;</el-radio>
            </template>
          </el-table-column>
        </template>
      </tree-table>
      <div style="padding-top:20px; text-align:center;">
        <el-button type="danger" size="mini" @click="sure">确定</el-button>
        <el-button size="mini" @click="jumpValue = false">取消</el-button>
      </div>
    </el-dialog>
</template>

<script>
  import TreeTable from '@/components/TreeTable' //封装树
  import treeToArray from '@/components/TreeTable/eval.js' //数据转换
    export default {
      name: "index",
      components: {TreeTable},
      data(){
        return{
          jumpValue:false,
          objectList:[],
          selectOrg:'',
          columns: [
            {
              text: '机构编号',
              value: 'branchId',
            },
            {
              text: '机构名称',
              value: 'name',
            },
          ],
        }
      },
      props:{
        value:{
          type:Boolean,
        }
      },
      watch:{
        value(newValue, oldValue){
          this.jumpValue = newValue;
        },
        jumpValue(newValue, oldValue){
          this.$emit('input', newValue);
        }
      },
      created(){
        this.getList();
      },
      methods:{
        //获取机构列表
        getList(){
          this.$api.myApi.permission.getMechanismList().then( res => {
            if(res.retCode == '0'){
              this.objectList = [];
              this.tabData = res.result;
              let list = res.result.departmentList || [];
              let list1 = res.result.subBranchList || [];
              let children = list.concat(list1);
              let obj = {};
              obj.name = this.tabData.name || '';
              obj.branchId = this.tabData.branchId || '';
              obj.branchName = this.tabData.branchName || '';
              obj.children = children;
              this.objectList.push(obj)
            }else{
              this.$message.error(res.retMsg);
            }
          })
        },
        sure(){
          this.jumpValue = false;
          this.$emit('getValue', this.selectOrg);
        }
      }
    }
</script>

<style scoped>

</style>
