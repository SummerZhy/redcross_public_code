<!-- 通用列表，包含查询条件和分页表格 -->
<template>
  <div>

    <slot name="head"></slot>

    <!-- 通用条件组件 -->
    <common-condition
      v-if="commonListConfig.condition"
      :config="commonListConfig.condition"
      :condition="conditionLocal"
      @update:condition="conditionLocal=$event;$emit('update:condition',conditionLocal);"
      @queryClicked="queryClicked"
    >
      <template #beforeConditions>
        <slot name="beforeConditions"></slot>
      </template>
      <template #afterConditions>
        <slot name="afterConditions"></slot>
      </template>
      <template #beforeBtnSearch>
        <slot name="beforeBtnSearch"></slot>
      </template>
      <template #afterBtnSearch>
        <slot name="afterBtnSearch"></slot>
      </template>
    </common-condition>

    <slot name="center"></slot>

    <!-- 通用表格组件 -->
    <common-table
      :condition="conditionLocal"
      :tableConfig="commonListConfig.table"
      :paginationConfig="commonListConfig.pagination"
      @pageChanged="pageChanged"
      @sizeChanged="sizeChanged"
      @rowCheckChanged="rowCheckChanged"
    >
      <template #beforeTable>
        <slot name="beforeTable"></slot>
      </template>
      <template #columnsBefore>
        <slot name="columnsBefore"></slot>
      </template>
      <template #columnsAfter>
        <slot name="columnsAfter"></slot>
      </template>
      <template #afterTable>
        <slot name="afterTable"></slot>
      </template>
      <template #beforePagination>
        <slot name="beforePagination"></slot>
      </template>
      <template #afterPagination>
        <slot name="afterPagination"></slot>
      </template>

    </common-table>

    <slot name="tail"></slot>
  </div>
</template>
<script>
import Vue from "vue";
import CommonCondition from "./CommonCondition";
import CommonTable from "./CommonTable";

export default {
  data() {
    return {
      conditionLocal: {},
      pageData: [],
      rowCheckedList: []
    };
  },
  props: {
    condition: {
      type: Object,
      default() {
        return {};
      }
    },
    commonListConfig: {
      type: Object,
      default() {
        return {};
      }
    }
  },

  components: { CommonCondition, CommonTable },

  computed: {},
  methods: {
    queryClicked() {
      this.pageChanged(1);
      this.$emit("queryClicked");
    },
    pageChanged(value) {
      this.conditionLocal.page = value;
      this.$emit("update:condition", this.conditionLocal);
      this.getPageData();
      this.$emit("pageChanged", value);
    },
    sizeChanged(value) {
      this.conditionLocal.limit = value;
      this.conditionLocal.page = 1;
      this.$emit("sizeChanged", value);
      this.pageChanged(1);
    },
    rowCheckChanged(value) {
      this.rowCheckedList = value;
      this.$emit("rowCheckChanged", value);
    },
    getPageData() {
      const method = this.commonListConfig.table.dataGetter;
      if (method) {
        method(this.conditionLocal).then(res => {
          if (res.retCode == 0) {
            // this.totalNum = res.result.totalNum;
            this.commonListConfig.table.data = res.result.list;
            // this.condition.total = parseInt(res.result.totalNum);
            // FAKE 假数据，增加页码数
            this.condition.total =
              parseInt(res.result.totalNum) *
              Math.floor(Math.random() * 20 + 5);
          } else {
            this.$message.error(res.retMsg);
          }
        });
      }
    }
  },
  filters: {},
  watch: {
    condition: {
      deep: true,
      immediate: true,
      handler(value) {
        this.conditionLocal = { ...this.conditionLocal, ...value };
      }
    }
  },
  beforeCreate() {},
  created() {
    this.getPageData();
  },
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  activated() {},
  deactivated() {},
  beforeDestory() {},
  destoryed() {},
  errorCaptured() {}
};
</script>
<style scoped lang="scss">
</style>
<documentation>
</documentation>