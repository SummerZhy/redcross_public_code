<!-- 通用表格，带分页。基于ElementUI -->
<template>
  <div class="wrap-class">
    <div class="com-operation-div">
      <slot name="beforeTable"></slot>
    </div>
    <div class="con-list">
      <el-table
        ref="dataTable"
        :data="tableConfig.data||[]"
        style="width: 100%"
        @selection-change="rowCheckChanged"
        :row-key="'userId'"
      >
        <template v-for="(c,i) in tableConfig.columns">
          <el-table-column
            v-if="c.isIndex"
            :width="c.width"
            :align="c.align"
            :label="c.label"
            :prop="c.prop"
          >
            <template slot-scope="scope">
              {{getIndex(scope.$index)}}
            </template>
          </el-table-column>
          <el-table-column
            v-else-if="c.action"
            :type="c.type"
            :width="c.width"
            :align="c.align"
            :label="c.label"
            :prop="c.prop"
            :reserve-selection="true"
          >
            <template slot-scope="scope">
              <span
                :class="c.class"
                @click="c.action(scope.row)"
              >{{fillColumnText(c,scope.row)}}</span>
            </template>
          </el-table-column>
          <el-table-column
            v-else-if="c.isActions"
            :type="c.type"
            :width="c.width"
            :align="c.align"
            :label="c.label"
            :prop="c.prop"
            :reserve-selection="true"
          >
            <template slot-scope="scope">
              <el-button
                v-for="(b,i) in c.actions"
                :key="i"
                :size="b.size||'mini'"
                :type="b.type||'text'"
                @click.stop="b.action(scope.row)"
              >
                {{b.label}}
              </el-button>
            </template>
            <!-- <template v-if="c.isActions"></template> -->
          </el-table-column>
          <el-table-column
            v-else
            :type="c.type"
            :width="c.width"
            :align="c.align"
            :label="c.label"
            :prop="c.prop"
            :reserve-selection="true"
          >
          </el-table-column>
        </template>
      </el-table>
      <el-pagination
        :total="condition.total"
        :current-page="currentPageFinal"
        :page-size="rowPerPageFinal"
        :pager-count="paginationConfig['pager-count']||paginationConfig.pagerCount||7"
        :page-sizes="paginationConfig['page-sizes']||paginationConfig.pageSizes||pageSizes"
        :background="paginationConfig.background||false"
        :layout="paginationConfig.layout||'total, prev, pager, next, jumper'"
        @current-change="page=>{pageChanged(page)}"
        @size-change="sizeChanged"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import Vue from "vue";

export default {
  data() {
    return {
      pageDataLocal: [],
      checkList: [],
      page: 1,
      limit: 10,
      total: 0,
      pageSizes: [10, 20, 30, 40, 50, 100]
    };
  },
  props: {
    condition: {
      type: Object,
      default() {
        return {};
      }
    },
    tableConfig: {
      type: Object,
      default() {
        return {};
      }
    },
    paginationConfig: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  components: {},
  computed: {
    pageDataFinal() {
      // TODO 需要支持Props模式
      return this.pageDataLocal;
    },
    currentPageFinal() {
      return this.currentPageLocal;
    },
    rowPerPageFinal() {
      return this.rowPerPageLocal;
    },
    totalRowCountFinal() {
      return this.totalRowCountLocal;
    },
    tableData() {
      if (this.tableConfig.data) {
        return this.tableConfig.data;
      }
    }
  },
  methods: {
    fillColumnText(c, row) {
      if (c.key) {
        return row[c.key];
      }
    },
    pageChanged(value) {
      this.$emit("pageChanged", value);
    },
    sizeChanged(value) {
      this.$emit("sizeChanged", value);
    },
    //表格序号
    getIndex(i) {
      return (this.condition.page - 1) * this.condition.limit + i + 1;
    },
    //table多选框改变
    rowCheckChanged(value) {
      this.$emit("rowCheckChanged", value);
    }
  },
  filters: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  activated() {},
  deactivated() {},
  beforeDestory() {},
  destoryed() {},
  errorCaptured() {}
};
</script>
<style scoped>
</style>
<documentation>
</documentation>
