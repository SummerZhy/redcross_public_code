<!-- 通用详情页 -->
<template>

</template>
<script>
import Vue from "vue";

export default {
  data() {
    return {};
  },
  props: [],
  components: {},
  computed: {},
  methods: {},
  filters: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  activated() {},
  deactivated() {},
  beforeDestory() {},
  destoryed() {},
  errorCaptured() {}
};
</script>
<style scoped>
</style>
<documentation>
</documentation>