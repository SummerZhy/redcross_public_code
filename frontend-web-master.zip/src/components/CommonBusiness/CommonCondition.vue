<!-- 通用查询条件框 -->
<template>
  <!-- TODO 增加表单属性支持 -->
  <el-form
    class="common-condition wrap-class search-wrap"
    ref="condition"
    :model="conditionLocal"
    :label-width="formSettings['label-width']||formSettings.labelWidth||'90px'"
    :label-position="formSettings['label-position']||formSettings.labelPosition||'left'"
    :inline="formSettings.inline||true"
  >

    <slot name="beforeConditions"></slot>

    <!-- TODO 增加表单项属性支持 -->
    <el-form-item
      v-for="(c,i) in conditions"
      :key="i"
      :label="c.label"
    >
      <!-- TODO 增加输入类型支持，比如日期区间，数值，Cascader等。可能还需要增加伸缩隐藏区域 -->

      <!-- TODO 增加文本框属性支持 -->
      <el-input
        v-if="c.type=='input'"
        v-model="conditionLocal[c.key]"
        :placeholder="c.placeholder||''"
        @change="updateCondition"
      ></el-input>

      <!-- TODO 增加下拉列表属性支持 -->
      <el-select
        v-if="c.type=='select'"
        v-model="conditionLocal[c.key]"
        :placeholder="c.placeholder||''"
        @change="updateCondition"
      >
        <!-- TODO 增加下拉列表选项属性支持 -->
        <el-option
          v-for="(s) in c.selections"
          :key="s.value"
          :label="s.label"
          :value="s.value"
        ></el-option>
      </el-select>
    </el-form-item>

    <slot name="afterConditions"></slot>

    <slot name="beforeBtnSearch"></slot>

    <el-form-item v-if="!noSearchBtn">
      <!-- TODO 这里支持配置的属性还可以增加 -->
      <el-button @click="$emit('queryClicked')">{{searchBtnConf.text||'查询'}}</el-button>
    </el-form-item>

    <slot name="afterBtnSearch"></slot>
  </el-form>
</template>
<script>
import Vue from "vue";

export default {
  data() {
    return {
      conditionLocal: {}
    };
  },
  props: {
    condition: {
      type: Object,
      default() {
        return {};
      }
    },
    config: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  components: {},
  computed: {
    formSettings() {
      return this.config.formSettings;
    },
    conditions() {
      return this.config.conditions;
    },
    searchBtnConf() {
      return this.config.searchBtnConf;
    },
    noSearchBtn() {
      return this.config.noSearchBtn;
    }
  },
  methods: {
    updateCondition() {
      this.$emit("update:condition", this.conditionLocal);
    },
    queryClicked(){
      
    }
  },
  filters: {},
  watch: {
    condition: {
      deep: true,
      immediate: true,
      handler(value) {
        this.conditionLocal = { ...this.conditionLocal, ...value };
      }
    }
    // conditionLocal: {
    //   deep: true,
    //   // immediate: true,
    //   handler(value) {
    //     debugger;
    //     this.$emit("update:condition", value);
    //   }
    // }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  activated() {},
  deactivated() {},
  beforeDestory() {},
  destoryed() {},
  errorCaptured() {}
};
</script>
<style scoped lang="scss">
</style>
<documentation>
</documentation>