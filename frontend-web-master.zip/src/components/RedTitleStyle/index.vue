<template>
    <div class="red-title-class">
      <section class="red-title-title">
        <span class="title-class">{{title}}</span>
        <div class="button-wrap">
          <slot name="button-slot"></slot>
          <el-button size="mini" @click="clickChange">{{changeText}}</el-button>
        </div>
      </section>
      <section v-show="showCon" class="red-title-main">
        <slot></slot>
      </section>
    </div>
</template>

<script>
    export default {
      name: "index",
      props:{
          title:{
            type:String,
            required: true
          }
      },
      data(){
        return{
          showCon:true,
          changeText:'收起'
        }
      },
      methods:{
        clickChange(){
          this.showCon = !this.showCon;
          if(this.changeText == '收起'){
            this.changeText = '展开';
          }else{
            this.changeText = '收起';
          }
        }
      }
    }
</script>

<style scoped lang="scss">
  .red-title-class{
    /*padding:0 30px;*/
  }
  .red-title-title{
    height:44px;
    display:flex;
    justify-content: space-between;
    align-items:center;
    .title-class{
      padding-left:10px;
      font-weight:bold;
      border-left:2px solid #E10807;
    }
 }
</style>
