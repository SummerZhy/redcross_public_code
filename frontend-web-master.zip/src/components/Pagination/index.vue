<template>
  <el-pagination
    @size-change="handleSizeChange"
    @current-change="handleCurrentChange"
    :current-page="queryData.currentPage"
    :page-size="queryData.limit"
    :total="totalNum"
    :page-sizes="[10, 20, 50, 100]"
    layout="total, sizes, prev, pager, next, jumper">
  </el-pagination>
</template>

<script>
  export default {
    name: "Pagination",
    props: {
      queryData: {
        type: Object,
        required: true,
      },
      totalNum: {
        type: Number,
        default: 0,
      },
      getList: Function,
    },
    methods: {
      handleSizeChange(val) {
        //改变每页数量
        this.queryData.limit = val
        this.getList();
      },
      handleCurrentChange(val) {
        //改变页码
        this.queryData.currentPage = val
        this.getList();
        console.log(this.queryData.currentPage);
      },
    },
  }
</script>

<style scoped>

</style>
