<template>
  <div>
    <el-breadcrumb class="app-breadcrumb" separator="/">
      <transition-group name="breadcrumb">
        <el-breadcrumb-item v-for="(item,index)  in levelList" :key="item.path" v-if="item.meta.title">
          <span v-if="item.redirect==='noredirect'||index==levelList.length-1"
                class="no-redirect">{{item.meta.title}}</span>
          <router-link v-else :to="item.redirect||item.path">{{item.meta.title}}</router-link>
        </el-breadcrumb-item>
      </transition-group>
    </el-breadcrumb>

    <div class="page-header">
      <el-page-header @back="goBack"></el-page-header>
    </div>
  </div>
</template>

<script>
  export default {
    created() {
      this.getBreadcrumb()
    },
    data() {
      return {
        levelList: null
      }
    },
    watch: {
      $route() {
        this.getBreadcrumb()
      }
    },
    methods: {
      getBreadcrumb() {
        let matched = this.$route.matched.filter(item => item.name)
        const first = matched[0]
        if (first && first.name !== '首页') {
          // matched = [{ path: '/home', meta: { title: '首页' }}].concat(matched)
        } else {
          matched = [{path: '/home', meta: {title: '首页'}}]
        }
        this.levelList = matched
      },
      goBack() {
        this.$router.go(-1)
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .app-breadcrumb.el-breadcrumb {
    display: inline-block;
    font-size: 14px;
    line-height: 50px;
    margin-left: 10px;

    .no-redirect {
      color: #97a8be;
      cursor: text;
    }
  }

  .el-breadcrumb__inner a:hover, .el-breadcrumb__inner.is-link:hover {
    color: #b7241e;
  }

  .page-header {
    margin-top: 10px;
    text-align: right;
    float: right;
  }
</style>
