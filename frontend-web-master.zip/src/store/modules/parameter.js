import {getToken, setToken, removeToken, removeUserInfo, getUserInfo} from '@/utils/auth'
import {Message} from "element-ui";
import apis from '@/api/api'

/**
 * 参数管理
 */

const parameter = {
  namespaced: true,
  state: {
    /**客户洗钱风险*/
    rulesRiskNatural: [],
    rulesRiskNonNatural: [],
    rulesRiskQualitative: [],
    /**……*/
  },
  getters: {
    /**客户洗钱风险*/
    rulesRiskNatural: state => state.rulesRiskNatural,
    rulesRiskNonNatural: state => state.rulesRiskNonNatural,
    rulesRiskQualitative: state => state.rulesRiskQualitative,
    /**……*/
  },
  mutations: {
    /**客户洗钱风险*/
    SET_RULES_RISK_NATURAL: (state, data) => {
      state.rulesRiskNatural = data
    },
    SET_RULES_RISK_NON_NATURAL: (state, data) => {
      state.rulesRiskNonNatural = data
    },
    SET_RULES_RISK_QUALITATIVE: (state, data) => {
      state.rulesRiskQualitative = data
    },
    /**……*/
  },
  actions: {
    /**客户洗钱风险查询/维护*/
    searchNaturalRules({commit}, payload) {
      apis.myApi.parameter.getNaturalRating(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    searchLegalRules({commit}, payload) {
      apis.myApi.parameter.getLegalRating(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NON_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NON_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    searchQualitativeRules({commit}, payload) {
      apis.myApi.parameter.getQualityRating(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_QUALITATIVE', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_QUALITATIVE', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    /**客户洗钱风险历史纪录*/
    searchNaturalRulesHistory({commit}, payload) {
      apis.myApi.parameter.getNaturalRatingHistory(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    searchLegalRulesHistory({commit}, payload) {
      apis.myApi.parameter.getLegalRatingHistory(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NON_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NON_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    searchQualitativeRulesHistory({commit}, payload) {
      apis.myApi.parameter.getQualityRatingHistory(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_QUALITATIVE', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_QUALITATIVE', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    /**客户洗钱风险审核*/
    checkNaturalRules({commit}, payload) {
      apis.myApi.parameter.getNaturalRatingCheck(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    checkLegalRules({commit}, payload) {
      apis.myApi.parameter.getLegalRatingCheck(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_NON_NATURAL', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_NON_NATURAL', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
    checkQualitativeRules({commit}, payload) {
      apis.myApi.parameter.getQualityRatingCheck(payload)
        .then(res => {
          if (res.retCode === '0') {
            commit('SET_RULES_RISK_QUALITATIVE', res.result.list || []);
          } else {
            commit('SET_RULES_RISK_QUALITATIVE', []);
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        }).catch(err => {
          console.log(err)
        })
    },
   
    /**……*/
  }
}
export default parameter
