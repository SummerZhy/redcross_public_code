import apis from '@/api/api'
import {Message, MessageBox} from 'element-ui'
//修改数据--CL
let deepChange= function(list,disabled){
  list.map(item=>{
    item.disabled =disabled;
    if(item.children&&item.children.length>0){
      deepChange(item.children ,disabled);
    }
  })
  return list
};
const permissionRole = {
  namespaced: true,
  state: {
    dataList: [],
    //详情FORM
    dataForm: {
      roleName: '',
      roleId: '',
      menuList: [],
      permissionList: []
    },
    data: [],
    menuData: [],
    permissionGroupList: [],
    totalNum: 0,
    loading: true
  },
  getters: {
    totalNum: state => state.totalNum,
    dataList: state => state.dataList,
    dataForm: state => state.dataForm,
    menuForm: state => state.menuForm,
    data: state => state.data,
    menuData: state => state.menuData,
    permissionGroupList: state => state.permissionGroupList,
    loading: state => state.loading
  },
  mutations: {
    SET_TOTAL_SIZE (state, payload) {
      state.totalNum = payload
    },
    SET_DATA_LIST (state, payload) {
      state.dataList = payload
    },
    SET_MENU_DATA (state, payload) {
      state.menuData = payload
    },
    SET_DATA (state, payload) {
      state.data = payload
    },
    SET_PERMISSION_LIST (state, payload) {
      state.permissionGroupList = payload
    },
    SET_DETAIL_LIST (state, payload) {
      state.dataForm.permissionList = payload
    },
    SET_DETAIL_MENU_LIST (state, payload) {
      state.dataForm.menuList = payload
    },
    RESET_DETAIL_LIST (state) {
      state.dataForm = {
        roleName: '',
        roleId: '',
        menuList: [],
        permissionList: []
      }
    },
    SET_LOADING_FALSE (state) {
      state.loading = false
    },
    SET_LOADING_TRUE (state) {
      state.loading = true
    },
  },
  actions: {
    //查询角色列表
    getDataList({commit},payload) {
      commit('SET_LOADING_TRUE')
      apis.myApi.getRole(payload)
        .then(res => {
          if (res.retCode == '0') {
            commit('SET_DATA_LIST',res.result.roleList)
            commit('SET_TOTAL_SIZE', res.result.totalNum)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询权限列表
    getPermissionList({commit},payload) {
      let tmpDisabled = payload.disabled ? true:false
      apis.myApi.getPermission(payload.data)
        .then(res => {
          if (res.retCode == '0') {
            let result = res.result.permissionGroupList;
            if(result.length>0){
              result= deepChange(result,tmpDisabled)
            }
            commit('SET_PERMISSION_LIST',result)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询全部菜单列表
    getMenuListAll({commit},payload) {
      let tmpDisAbled= payload.disabled ? true:false
      apis.myApi.getMenuAll(payload)
        .then(res => {
          if (res.retCode == '0') {
            const generateData = _ => {
              let menus = []
              let menuNames = []
              let menuIds = []
              for (let i = 0; i < res.result.menuList.length; i++) {
                menuNames.push(res.result.menuList[i].menuName)
                menuIds.push(res.result.menuList[i].menuId)
              }
              menuNames.forEach((menu, index) => {
                menus.push({
                  label: menu,
                  key: menuIds[index],
                  pinyin: menuNames[index],
                  disabled:tmpDisAbled
                })
              })
              return menus
            }
            //this.data = generateData()
            commit('SET_MENU_DATA',generateData())
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询全部权限列表
    getPermissionListAll({commit},payload) {
      let tmpDisAbled= payload.disabled ? true:false
      apis.myApi.getPermissionAll(payload)
        .then(res => {
          if (res.retCode == '0') {
            const generateData = _ => {
              let permissions = []
              let permissionNames = []
              let permissionIds = []
              for (let i = 0; i < res.result.permissionList.length; i++) {
                permissionNames.push(res.result.permissionList[i].permissionName)
                permissionIds.push(res.result.permissionList[i].permissionId)
              }
              permissionNames.forEach((permission, index) => {
                permissions.push({
                  label: permission,
                  key: permissionIds[index],
                  pinyin: permissionNames[index],
                  disabled:tmpDisAbled
                })
              })
              return permissions
            }
            //this.data = generateData()
            commit('SET_DATA',generateData())
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询角色详情列表
    getDetailPermissionList({commit},payload) {
      apis.myApi.getPermissionDetail(payload.data)
        .then(res => {
          if (res.retCode == '0') {
            let permissionList = []
            for(let i=0; i<res.result.permissionList.length; i++) {
              permissionList.push(res.result.permissionList[i].permissionId)
            }
            /*commit('SET_DETAIL_LIST',res.result.roleList)*/
            commit('SET_DETAIL_LIST',permissionList)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询菜单详情列表
    getDetailMenuList({commit},payload) {
      apis.myApi.getMenuDetail(payload.data)
        .then(res => {
          if (res.retCode == '0') {
            let menuList = []
            for(let i=0; i<res.result.menuList.length; i++) {
              menuList.push(res.result.menuList[i].menuId)
            }
            /*commit('SET_DETAIL_LIST',res.result.roleList)*/
            commit('SET_DETAIL_MENU_LIST',menuList)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //重置详情页
    resetDetailList({commit}) {
      commit('RESET_DETAIL_LIST')
    },
  }
}
export default permissionRole
