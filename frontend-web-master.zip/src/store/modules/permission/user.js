import apis from '@/api/api'
import {Message, MessageBox} from 'element-ui'

const userRole = {
  namespaced: true,
  state: {
    dataList: [],
    //详情FORM
    dataForm: {
      roleName: '',
      roleId: '',
      roleList: []
    },
    totalNum: 0,
    loading: true,
    data: [],
    mydata: []
  },
  getters: {
    totalNum: state => state.totalNum,
    dataList: state => state.dataList,
    dataForm: state => state.dataForm,
    data: state => state.data,
    mydata: state => state.mydata,
    loading: state => state.loading
  },
  mutations: {
    SET_TOTAL_SIZE (state, payload) {
      state.totalNum = payload
    },
    SET_DATA (state, payload) {
      state.data = payload
    },
    SET_MY_DATA (state, payload) {
      state.mydata = payload
    },
    SET_DATA_LIST (state, payload) {
      state.dataList = payload
    },
    SET_DETAIL_LIST (state, payload) {
      state.dataForm.roleList = payload
    },
    RESET_DETAIL_LIST (state) {
      state.dataForm = {
        userId: '',
        data: [],
        roleList: []
      }
    },
    SET_LOADING_FALSE (state) {
      state.loading = false
    },
    SET_LOADING_TRUE (state) {
      state.loading = true
    },
  },
  actions: {
    //查询角色列表
    getDataList({commit},payload) {
      commit('SET_LOADING_TRUE')
      apis.myApi.getUser(payload)
        .then(res => {
          if (res.retCode == '0') {
            commit('SET_DATA_LIST',res.result.userList)
            commit('SET_TOTAL_SIZE', res.result.totalNum)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //查询角色详情列表
    getDetailList({commit},payload) {
      apis.myApi.getUserDetail(payload)
        .then(res => {
          if (res.retCode == '0') {
            let roleList = []
            for(let i=0; i<res.result.roleList.length; i++) {
              roleList.push(res.result.roleList[i].roleId)
            }
            /*commit('SET_DETAIL_LIST',res.result.roleList)*/
            commit('SET_DETAIL_LIST',roleList)
            commit('SET_LOADING_FALSE')
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
            commit('SET_LOADING_FALSE')
          }
        })
        .catch(err => {
          console.log(err)
          commit('SET_LOADING_FALSE')
        })
    },
    //获取可选用户角色
    getRoleList({commit},payload) {
      apis.myApi.getUserRole(payload)
        .then((res) => {
          if (res.retCode == '0') {
            const generateData = _ => {
              let roles = []
              let roleNames = []
              let roleIds = []
              for (let i = 0; i < res.result.roleList.length; i++) {
                roleNames.push(res.result.roleList[i].roleName)
                roleIds.push(res.result.roleList[i].roleId)
              }
              roleNames.forEach((role, index) => {
                roles.push({
                  label: role,
                  key: roleIds[index],
                  pinyin: roleNames[index]
                })
              })
              return roles
            }
            //this.data = generateData()
            commit('SET_DATA',generateData())
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        })
    },
    //获取全部用户角色
    getRoleAllList({commit},payload) {
      let tmpDisAbled= payload.disabled ? true:false
      apis.myApi.getUserRoleAll(payload.data)
        .then((res) => {
          if (res.retCode == '0') {
            const generateData = _ => {
              let roles = []
              let roleNames = []
              let roleIds = []
              for (let i = 0; i < res.result.roleList.length; i++) {
                roleNames.push(res.result.roleList[i].roleName)
                roleIds.push(res.result.roleList[i].roleId)
              }
              roleNames.forEach((role, index) => {
                roles.push({
                  label: role,
                  key: roleIds[index],
                  pinyin: roleNames[index],
                  disabled:tmpDisAbled
                })
              })
              return roles
            }
            //this.data = generateData()
            commit('SET_DATA',generateData())
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        })
    },
    //获取已有用户角色
    getMyRoleAll({commit},payload) {
      apis.myApi.getUserDetail(payload)
        .then((res) => {
          if (res.retCode == '0') {
            const generateData = _ => {
              let roles = []
              let roleNames = []
              let roleIds = []
              for (let i = 0; i < res.result.roleList.length; i++) {
                roleNames.push(res.result.roleList[i].roleName)
                roleIds.push(res.result.roleList[i].roleId)
              }
              roleNames.forEach((role, index) => {
                roles.push({
                  label: role,
                  key: roleIds[index],
                  pinyin: roleNames[index]
                })
              })
              return roles
            }
            commit('SET_MY_DATA',generateData())
          } else {
            Message({
              message: res.retMsg,
              type: 'error',
              duration: 3 * 1000
            })
          }
        })
    },
    //重置详情页
    resetDetailList({commit}) {
      commit('RESET_DETAIL_LIST')
    },
  }
}
export default userRole
