import {getToken, setToken, removeToken, removeUserInfo, getUserInfo} from '@/utils/auth'
import {Message} from "element-ui";
import apis from '@/api/api'

/**
 * 字典管理
 */

const dictionary = {
  namespaced: true,
  state: {
    dicInfo: {},
    clientBranchTree: [],
    nationListData: [], //国籍
    occuListData: [], //职业
    industryListData: [], //行业
  },
  getters: {
    /** 红会项目中的字典值-start */
    //善款来源
    fundsSources() {
      return [
        {paramId: "101", paramName: "网银转账",},
        {paramId: "102", paramName: "微信支付",},
        {paramId: "103", paramName: "支付宝支付",},
        {paramId: "104", paramName: "现金捐款",}
      ]
    },
    //审核状态
    checkValus() {
      return [
        {paramId: "00", paramName: "待审核",},
        {paramId: "01", paramName: "审核完成",},
        {paramId: "02", paramName: "退回",}
      ]
    },
    //处理状态
    manageState() {
      return [
        {paramId: "00", paramName: "待处理",},
        {paramId: "01", paramName: "处理中",},
        {paramId: "02", paramName: "处理完成",}
      ]
    },
    //捐赠意愿
    donateAspiration() {
      return [
        {paramId: "00", paramName: "定向",},
        {paramId: "01", paramName: "非定向",}
      ]
    },
     //善款用途
     donationPurpose() {
      return [
        {paramId: "201", paramName: "助学",},
        {paramId: "202", paramName: "助困",},
        {paramId: "203", paramName: "助老",},
        {paramId: "204", paramName: "助残",},
        {paramId: "205", paramName: "救灾",},
        {paramId: "206", paramName: "大病",},
        {paramId: "207", paramName: "其他",}
      ]
    },
    //使用状态
    fundState() {
      return [
        {paramId: "00", paramName: "未使用",},
        {paramId: "01", paramName: "部分使用",},
        {paramId: "02", paramName: "全部使用",}
      ]
    },
    //身份信息
    identityInfo() {
      return [
        {paramId: "301", paramName: "企业",},
        {paramId: "302", paramName: "个人",},
        {paramId: "303", paramName: "单位",}
      ]
    },
    //身份信息详情
    identityInfoDetail() {
      return [
        {paramId: "401", paramName: "党政事业单位职工",},
        {paramId: "402", paramName: "个体工商户",},
        {paramId: "403", paramName: "企业职工",},
        {paramId: "404", paramName: "学生",},
        {paramId: "405", paramName: "离退休人员",},
        {paramId: "406", paramName: "自由职业者",},
        {paramId: "407", paramName: "其他",}
      ]
    },
    //审核事项
    checkItem() {
      return [
        {paramId: "00", paramName: "款项公示",},
        {paramId: "01", paramName: "评论公示",},
        {paramId: "02", paramName: "感谢公示",}
      ]
    },
    //生效模式设置
    effectiveModeSet() {
      return [
        {paramId: "01", paramName: "立即生效",},
        {paramId: "02", paramName: "审核生效",}
      ]
    },
    /** 红会项目中的字典值-start */

    /** 用户所属机构树 */
    clientBranchTree: state => state.clientBranchTree,
    /** 用户所属部门 */
    department: state => state.department,
    /** 国籍 */
    nationListData: state => state.nationListData,
    /** 职业 */
    occuListData: state => state.occuListData,
    /** 行业 */
    industryListData: state => state.industryListData,
    /** 通过类型代号直接获取某个类型的选项，获取不到会返回一个空数组 */
    getByType: (state) => (type) => {
      return state.dicInfo[type] || [];
    },
    /** 通过父级id和类型代号获取某个类型的选项，获取不到会返回一个空数组 */
    getByParentId: (state) => (type, parentId) => {
      let paramList = state.dicInfo[type] || [];
      let data = []
      paramList.forEach(item => {
        if (item.parentId === parentId) {
          data.push(item)
        }
      })
      return data;
    },
    /** 报告来源 （批量生成 手工生成）*/
    reportSource(state, getters) {
      return getters.getByType("1");
      // return [{
      //   "paramId": 1,
      //   "paramType": "1",
      //   "paramName": "系统预警",
      // },
      //   {
      //     "paramId": 2,
      //     "paramType": "1",
      //     "paramName": "手工新增",
      //   },
      // ]
    },
    /** 报告类型 （个人 团伙）*/
    reportType(state, getters) {
      return getters.getByType("2");
    },
    /** 报告状态 （新建 否决）*/
    reportStatus(state, getters) {
      return getters.getByType("3");
    },
    /** 原始 修改*/
    message(state, getters) {
      return getters.getByType("4");
    },
    /** 报文下载状态 （未下载 已下载）*/
    messageStatus(state, getters) {
      return getters.getByType("5");
    },
    /** 报文状态 （待报送 通过） */
    messageType(state, getters) {
      return getters.getByType("6");
    },
    /**报告类型（可疑交易 大额交易） */
    messageSuspicious(state, getters) {
      return getters.getByType("7");
    },
    /** 回执状态（正确回执 错误回执 补正回执）*/
    messageReceipt(state, getters) {
      return getters.getByType("8");
    },
    /** 团伙成员来源（系统生成 手工新增）*/
    sourceOfGang(state, getters) {
      return getters.getByType("9");
    },
    /** 操作角色（初审岗 复审岗 审定岗）*/
    roles(state, getters) {
      return getters.getByType("10");
    },
    /** 处理结果（可疑 不可疑）*/
    processingResult(state, getters) {
      return getters.getByType("11");
    },
    /** 团伙类型（团伙主体 团伙成员）*/
    source(state, getters) {
      return getters.getByType("12");
    },
    /** 可疑交易报告紧急程度(非常紧急 特别紧急) */
    urgency(state, getters) {
      return getters.getByType("13");
    },
    /** 是否是接续性报告(是 不是) */
    continuityReport(state, getters) {
      return getters.getByType("14");
    },
    /** 客户身份证件/证明文件类型*/
    idType(state, getters) {
      return getters.getByType("15");
      /*return [{
        "paramId": "110001",
        "paramType": "15",
        "paramName": "身份证",
      },
        {
          "paramId": "110003",
          "paramType": "15",
          "paramName": "临时居民身份证",
        },
        {
          "paramId": "110005",
          "paramType": "15",
          "paramName": "户口簿",
        },
      ]*/
    },
    /** 资金进出方向（收  付） */
    capital(state, getters) {
      return getters.getByType("16");
    },
    /** 资金进出方式（现金 转账 其他） */
    capitalStatus(state, getters) {
      return getters.getByType("17");
    },
    /** 报送方向（报告中国反洗钱监测分析中心） */
    reportingDirection(state, getters) {
      return getters.getByType("18");
    },
    /** 非柜台交易方式的设备代码 */
    deviceCode(state, getters) {
      return getters.getByType("19");
    },
    /** 非柜台交易方式 (网上交易 通过POS机交易)*/
    transactionMode(state, getters) {
      return getters.getByType("21");
    },
    /** 交易种类(股票 权证 债券)*/
    transactionType(state, getters) {
      return getters.getByType("33");
    },
    /** 可疑交易报告触发点(模型筛选)*/
    suspiciousTransaction(state, getters) {
      return getters.getByType("34");
    },
    /** 特殊经济区类型(中国大陆地区保税区)*/
    specialEconomyType(state, getters) {
      return getters.getByType("35");
    },
    /** 账户类型(个人账户 组织账户)*/
    accountType(state, getters) {
      return getters.getByType("36");
    },
    /** 个人账户(活期存储账户 活期结算账户)*/
    individualAccount(state, getters) {
      return getters.getByType("37");
    },
    /** 组织账户(组织基本账户 组织一般账户)*/
    organizationalAccount(state, getters) {
      return getters.getByType("38");
    },
    /** 首付款方匹配号类型(通过大小额支付系统和超级网银清算的交易)*/
    receivingPartyType(state, getters) {
      return getters.getByType("39");
    },
    /* /!** 涉罪类型(毒品犯罪 黑社会性质的组织犯罪)*!/
     crimeType(state, getters) {
       return getters.getByType("40");
     },
     /!** 涉罪可疑交易行为(涉嫌与毒品犯罪相关的可疑交易行为)*!/
     criminalTransaction(state, getters) {
       return getters.getByType("41");
     },*/
    /** 交易方式(人民币业务 外币业务)*/
    transaction(state, getters) {
      return getters.getByType("42");
    },
    /** 人民币业务(现金交易 非现金交易)*/
    rmbBusiness(state, getters) {
      return getters.getByType("43");
    },
    /** 支付或结算方式(银行汇票 银行承兑汇票)*/
    paymentType(state, getters) {
      return getters.getByType("44");
    },
    /** 外币业务(现金 现金结售汇)*/
    foreignCurrencyBusiness(state, getters) {
      return getters.getByType("45");
    },
    /** 全部代理国际汇款公司业务(代理西联国际汇款（现金业务）)*/
    agentRemittance(state, getters) {
      return getters.getByType("46");
    },
    /** 子级代理国际汇款公司业务(代理西联国际汇款（现金业务）)*/
    subAgentRemittance(state, getters, parentId) {
      return getters.getByParentId("46", parentId);
    },
    /** 名单状态(活跃 不活跃)*/
    listStatus(state, getters) {
      return getters.getByType("47");
    },
    /** 名单来源(外部数据库导入 自定义名单维护)*/
    listSources(state, getters) {
      return getters.getByType("48");
    },
    /** 名单类型(个人 公司 船只 其他)*/
    listType(state, getters) {
      return getters.getByType("49");
    },
    /** 黑名单匹配客户状态(个人 公司 船只 其他)*/
    blackListMatching(state, getters) {
      return getters.getByType("50");
    },
    /** 自定义黑名单类型1*/
    blackListType1(state, getters) {
      return getters.getByType("51");
      /*return [{
        "paramId": "01",
        "paramName": "红通",
      },
        {
          "paramId": "02",
          "paramName": "恐怖",
        },
        {
          "paramId": "03",
          "paramName": "失信",
        },]*/
    },
    /** 子任务名称*/
    jobSubname(state, getters) {
      return getters.getByType("52");
    },
    /** 非现金支付或结算方式*/
    nonCaskPayment(state, getters) {
      return getters.getByType("53");
    },
    /** 客户留存地址核实情况 */
    addressVerifyResult(state, getters) {
      return getters.getByType("58");
    },
    /** 客户留存电话核实情况 */
    phoneVerifyResult(state, getters) {
      return getters.getByType("59");
    },
    /** 证件核实情况 */
    IdCardVerifyResult(state, getters) {
      return getters.getByType("60");
    },
    /** 客户配合情况 */
    cooperationInfo(state, getters) {
      return getters.getByType("61");
    },
    /** 身份证件状态 */
    nonatIdStatus(state, getters) {
      return getters.getByType("62");
    },
    /** 客户经营场所异常情况 */
    nonatAbnormalCondition(state, getters) {
      return getters.getByType("65");
    },
    /** 负面信息情况 */
    negativeInfo(state, getters) {
      return getters.getByType("66");
    },
    /** 身份信息核实是否存在不符情况 */
    nonatIdentityTruth(state, getters) {
      return getters.getByType("67");
    },
    /** 国籍3位*/
    nation(state, getters) {
      let data = getters.getByType("72");
      console.log(data)
      let nationData = data.sort(
        function compareFunction(param1, param2) {
          return param1.paramName.localeCompare(param2.paramName, 'zh');
        }
      )
      nationData.forEach(function (item, index) {
        if (item.paramName == "中国") {
          nationData.splice(index, 1);
          nationData.unshift(item)
        }
      })
      return nationData;
      /*return [{
        paramId: "01",
        paramName: "中国",
      }, {
        paramId: "02",
        paramName: "俄罗斯",
      },]*/
    },
    /** 国籍数字*/
    nationNum(state, getters) {
      return getters.getByType("73");
      /*return [{
        paramId: "01",
        paramName: "中国",
      }, {
        paramId: "02",
        paramName: "俄罗斯",
      },]*/
    },
    /** 国籍2位*/
    nationTwo(state, getters) {
      return getters.getByType("74");
      /*return [{
        paramId: "01",
        paramName: "中国",
      }, {
        paramId: "02",
        paramName: "俄罗斯",
      },]*/
    },
    /** 职业 */
    career(state, getters) {
      return getters.getByType("75");
    },
    /** 币种 */
    currency(state, getters) {
      return getters.getByType("76");
    },
    /** 行业 */
    industry(state, getters) {
      return getters.getByType("77");
    },
    /** 客户类型（自然人、非自然人） */
    clientType() {
      return [
        {
          paramId: 1,
          paramName: "自然人",
          paramType: "2",
          parentId: null
        },
        {
          paramId: 2,
          paramName: "非自然人",
          paramType: "2",
          parentId: null
        },
      ]
    },
    // 性别
    gender() {
      return [
        {paramId: "1", paramName: "男",},
        {paramId: "0", paramName: "女",}
      ]
    },
    // 性别2
    sex() {
      return [
        {paramId: "0", paramName: "男",},
        {paramId: "1", paramName: "女",}
      ]
    },
    /** 客户洗钱风险等级 （高 中 低） */
    riskLevel() {
      return [
        {paramId: 1, paramName: '低'},
        {paramId: 2, paramName: '中'},
        {paramId: 3, paramName: '高'},
      ]
    },
    /** 客户洗钱风险复评状态*/
    confirmStatus() {
      return [
        {paramId: '2', paramName: '系统待复评'},
        {paramId: '5', paramName: '手工调整待复评'},
        {paramId: '6', paramName: '复评中'},
      ]
    },
    /** 异常交易检测标准查询 分类*/
    classiflcation(state, getters) {
      return getters.getByType("88");
    },
    /** 异常交易检测标准查询 启用标志*/
    stopStatus(state, getters) {
      return getters.getByType("90");
    },
    //高风险名单类型
    riskType(state, getters) {
      return getters.getByType("95");
    },
    /** 客户重新识别措施*/
    replayClient(state, getters) {
      return getters.getByType("98");
    },
    /** 内部协查报告状态*/
    investigationStatus(state, getters) {
      return getters.getByType("100");
    },

  },
  mutations: {
    SET_DIC_INFO: (state, data) => {
      state.dicInfo = data
    },
    SET_CLIENT_BRANCH_TREE: (state, data) => {
      state.clientBranchTree = data
    },
    SET_DEPARTMENT: (state, data) => {
      state.department = data
    },
    SET_NATION_LIST_DATA: (state, data) => {
      state.nationListData = data;
    },
    SET_OCCU_LIST_DATA: (state, data) => {
      state.occuListData = data;
    },
    SET_INDUSTRY_LIST_DATA: (state, data) => {
      state.industryListData = data;
    }
  },
  actions: {
    getDicList({commit}) {
      apis.myApi.getDicListApi().then((res) => {
        if (res.retCode === '0') {
          let paramData = {}
          res.result.list.forEach(item => {
            paramData[item.paramType] = paramData[item.paramType] || []
            if (!item.paramName) {
              item.paramName = ''
            }
            if (!item.parentId) {
              item.parentId = ''
            }
            paramData[item.paramType].push(item)
          })
          commit('SET_DIC_INFO', paramData)
          localStorage.setItem("dictionary", JSON.stringify(paramData));
        } else {
          this.clean();
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    clean({commit}) {
      localStorage.removeItem("dictionary");
      commit("SET_DIC_INFO", {});
    },
    initDic({commit, dispatch, state}) {
      let result = {};
      let success = false;
      const dataStr = localStorage.getItem("dictionary");
      if (dataStr) {
        try {
          result = JSON.parse(dataStr);
          success = true;
        } catch (error) {
          // localStorage中的数据无法转换成JSON对象 考虑是否需要请求获取
        }
      }
      if (success) {
        commit('SET_DIC_INFO', result);
      } else {
        dispatch("getDicList");
      }
    },
    getClientBranchTree({commit}) {
      apis.myApi.getClientBranchTree().then((res) => {
        if (res.retCode === '0' && res.result.list) {
          let list = res.result.list
          let branchTree = []
          for (let i = 0; i < list.length; i++) {
            let item = list[i];
            let children = [];
            if (!item.parentId || item.parentId === '') {
              for (let j = 0; j < list.length; j++) {
                if (list[j].parentId === item.branchId && list[j].branchType === '2') {
                  children.push({
                    label: list[j].branchName,
                    value: list[j].branchId,
                  })
                }
              }
              branchTree.push({
                label: item.branchName,
                value: item.branchId,
                children: children
              })
            }
            console.log(JSON.stringify(branchTree))
            commit('SET_CLIENT_BRANCH_TREE', branchTree)
          }
        } else {
          commit('SET_CLIENT_BRANCH_TREE', [])
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    getDepartment({commit}) {
      apis.myApi.getDepartmentApi().then((res) => {
        if (res.retCode === '0') {
          commit('SET_DEPARTMENT', res.result.list)
        } else {
          commit('SET_CLIENT_BRANCH_TREE', [])
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err)
      })
    },
    //国籍查询
    getNationList({commit}) {
      apis.myApi.nationListGet().then((res) => {
        if (res.retCode === '0' && res.result.list) {
          commit('SET_NATION_LIST_DATA', res.result.list);
        } else {
          commit('SET_NATION_LIST_DATA', [])
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err);
      })
    },
    //职业查询
    getOccuList({commit}) {
      apis.myApi.occuListGet().then((res) => {
        if (res.retCode === '0' && res.result.list) {
          commit('SET_OCCU_LIST_DATA', res.result.list);
        } else {
          commit('SET_OCCU_LIST_DATA', [])
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err);
      })
    },
    //行业查询
    getIndustryList({commit}) {
      apis.myApi.industryListGet().then((res) => {
        if (res.retCode === '0' && res.result.list) {
          commit('SET_INDUSTRY_LIST_DATA', res.result.list);
        } else {
          commit('SET_INDUSTRY_LIST_DATA', [])
          Message({
            message: res.retMsg,
            type: 'error',
            duration: 3 * 1000
          })
        }
      }).catch(err => {
        console.log(err);
      })
    },
  }
}
export default dictionary
