import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
  /**
   * 接口含义：待办事项列表查询
   */
  todoList: function (param) {
    return get('/todo/list', param)
  },
  /**
   * 接口含义：用户角色快捷菜单查询
   */
  fastMenu: function (param) {
    return get('/fast-munu/info', param)
  },
  /**
   * 接口含义：角色管理查询
   */
  roleList: function (param) {
    return get('/role/info', param)
  },
  /**
   * 接口含义：用户角色快捷菜单修改
   */
  meuPut: function (param) {
    return put('/fast-munu/info', param)
  },

}
