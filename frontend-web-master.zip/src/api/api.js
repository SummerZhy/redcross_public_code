import {
  get,
  getResponse,
  post,
  postResponse,
  put,
  patch,
  del
} from '@/utils/http'

import activityManage from './activityManage.js'
import memberManage from './memberManage.js'
import signUp from './signUp.js'
import unionActivity from './unionActivity.js'
import permission from '@/api/permission'
import paramApi from '@/api/param-api'
import role from '@/api/role'
import home from '@/api/home'
import moneyHandling from '@/api/moneyHandling'

import statistics from '@/api/statistics'
import promulgate from '@/api/promulgate'
import fundRetrospect from '@/api/fundRetrospect' //资金追溯
import checkDispose from '@/api/checkDispose' //审核处理


let myApi = {
  /**
   * 接口含义：用户登陆   */
  login: function (param) {
    console.log('--进入登陆请求---')
    return post1('/login/auth', param)
  },
  /**
   * 接口含义：获取用户信息   */
  getInfo: function (param) {
    return get('/login/resources', param)
  },
  /**
   * 接口含义：获取盐值   */
  getSalt: function (param) {
    return get('/login/salt', param)
  },
  /**
   * 接口含义：用户注册  */
  register: function (param) {
    return post('/register/user', param)
  },
  /**
   * 接口含义：修改密码  */
  codeModify: function (param) {
    return put('/user/code', param)
  },
  // 用户信息查询
  getUserList: function (param) {
    return get('/user/basic-info', param)
  },
  //用户信息修改
  changeUser: function (param) {
    return put ('/user/basic-info', param)
  },
  /**
   * 接口含义：找回密码   */
  codeBack: function (param) {
    return put('/user/retrieve', param)
  },
  /**
   * 接口含义：获取验证码
   * 参数：0：手机，1：邮箱  */
  getConfirmCode: function (param) {
    return post('/verifycode/sending', param)
  },
  /**
   * 接口含义：用户用户登出   */
  logout: function (param) {
    return post('/logout', param)
  },
  /**
   * token刷新
   */
  getNewToken: function (param) {
    return get1('/token/refresh', param)
  },
  /////////////////////////////////////////////////
  /**
   * 接口含义：权限管理   */
  //角色管理
  //角色列表查询
  getRole: function (param) {
    return get('/role/list', param)
  },
  //全部权限查询
  getPermissionAll: function (param) {
    return get('/permission/list', param)
  },
  //已拥有权限查询
  getPermissionDetail: function (param) {
    return get('/role/permission/list', param)
  },
  //全部菜单查询
  getMenuAll: function (param) {
    return get('/menu/all', param)
  },
  //已拥有菜单查询
  getMenuDetail: function (param) {
    return get('/role/menu/list', param)
  },
  //角色新增
  roleAdd: function (param) {
    return post('/role/info', param)
  },
  //角色修改
  roleModify: function (param) {
    return put('/role/info', param)
  },
  //角色删除
  roleDel: function (param) {
    return del('/role/info', param)
  },

  //用户管理
  //用户查询
  getUser: function (param) {
    return get('/user/list', param)
  },
  //用户全部角色查询
  getUserRoleAll: function (param) {
    return get('/role/list/', param)
  },
  //用户角色详情
  getUserDetail: function (param) {
    return get('/user/role/list', param)
  },
  //用户角色修改
  userUpdate: function (param) {
    return put('/user/role/list', param)
  },
  //用户解锁
  userUnlock: function (param) {
    return put('/user/unlock', param)
  },
  //字典值查询
  getDicListApi: function (param) {
    return get('/dic/list', param)
  },
  //查询部门
  getDepartmentApi: function (param) {
    return get('/dic/department', param)
  },
  /**
   * 客户所属机构树查询
   */
  getClientBranchTree: function (param) {
    return get('/branch-tree/list', param)
  },
  /**
   * 国籍（字典值）查询
   */
  nationListGet: function (param) {
    return get('/dic/nation/list', param)
  },
  /**
   * 职业（字典值）查询
   */
  occuListGet: function (param) {
    return get('/dic/occu/list', param)
  },
  /**
   * 行业（字典值）查询
   */
  industryListGet: function (param) {
    return get('dic/industry/list', param)
  },
  activityManage,
  memberManage,
  signUp,
  unionActivity,
  fundRetrospect,
  checkDispose
}
myApi.permission = permission;
myApi.paramApi = paramApi;
myApi.role = role;
myApi.home = home;
myApi.moneyHandling = moneyHandling;
myApi.statistics = statistics;
myApi.promulgate = promulgate;
export default {
  myApi
}
