import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
  /**
   * 接口含义：资金接收公示统计查询
   */
  getInStaInfo: function (param) {
    return get('/capital/inflow/statistics/info', param)
  },
  /**
   * 接口含义：资金接收公示列表查询
   */
  getInStaList: function (param) {
    return get('/capital/inflow/statistics/list', param)
  },
  /**
   * 接口含义：捐赠公示统计查询
   */
  getOutStaInfo: function (param) {
    return get('/capital/outflow/statistics/info', param)
  },
  /**
   * 接口含义：捐赠公示列表查询
   */
  getOutStaList: function (param) {
    return get('/capital/outflow/statistics/list', param)
  },


}
