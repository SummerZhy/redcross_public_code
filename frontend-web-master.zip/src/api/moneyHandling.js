import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
    /**
     * 接口含义：善款列表查詢
     */
    getMoneyList: function (param) {
        return get('/capital/inflow/list', param)
    },
   /**
     * 接口含义：善款入账详情
     */
    getMoneyDetail: function (param) {
        return get('/capital/inflow/info', param)
    },
    /**
     * 接口含义：审核退回处理列表查询
     */
    auditList: function (param) {
        return get('/capital/inflow/audit/list', param)
    },
     /**
     * 接口含义：资金接收补录--审核退回处理补录
     */
     inflowPut: function (param) {
        return put('/capital/inflow/info', param)
    },


     /**
     * 资金使用接口
     */
    /**
     * 接口含义：资金出账上传
     */
    outflowUploadPost: function (param) {
        return post('/capital/outflow/upload', param)
    },
    /**
     * 接口含义：资金出账列表
     */
    outflowListGet: function (param) {
        return get('/capital/outflow/list', param)
    },
    /**
     * 接口含义：资金出账增加
     */
    outflowInfoPost: function (param) {
        return post('/capital/outflow/info', param)
    },
    /**
     * 接口含义：资金出账导入
     */
    outflowImportPost: function (param) {
        return post('/capital/outflow/import', param)
    },
    /**
     * 接口含义：资金出账详情
     */
    outflowInfoGet: function (param) {
        return get('/capital/outflow/info', param)
    },
    /**
     * 接口含义：资金出账列表_智能匹配
     */
    intelligentListGet: function (param) {
        return get('/capital/outflow/intelligent/list', param)
    },
    /**
     * 接口含义：资金出账列表_智能匹配_分页
     */
    intelligentListPageGet: function (param) {
        return get('/capital/outflow/intelligent/list/page', param)
    },
    /**
     * 接口含义：资金出账修改选中状态
     */
    statusPut: function (param) {
        return put('/capital/outflow/status', param)
    },
    /**
     * 接口含义：资金出账修改金额
     */
    moneyPut: function (param) {
        return put('/capital/outflow/money', param)
    },
    /**
     * 接口含义：资金出账-智能匹配-增加
     */
    intelligentInfoPost: function (param) {
        return post('/capital/outflow/intelligent/info', param)
    },

   /* /!**
     * 接口含义：用户管理查询
     *!/
    userInfoGet: function (param) {
        return get('/user/info', param)
    },
     /**
     * 接口含义：资金审核提交
     */
    auditInfoPut: function (param) {
        return put('/capital/inflow/audit/info', param)
    },
    /**
     * 接口含义：捐赠人评价审核列表查询
     */
    donorListGet: function (param) {
        return get('/capital/inflow/comment/list', param)
    },
    /**
     * 接口含义：捐赠人评价审核
     */
    donorListPut: function (param) {
        return put('/capital/inflow/comment/info', param)
    },
    /**
     * 接口含义：捐赠人评价审核
     */
    userCodeReset: function (param) {
        return put('/user/code/reset', param)
    },
    /**
     * 接口含义：系统公示设置
     */
    paramInfoPut: function (param) {
        return put('/capital/inflow/param/info', param)
    },
    /**
     * 接口含义：善款列表下载
     */
    getExport: function (param) {
        return get('/capital/inflow/list/export', param)
    },
    /**
     * 接口含义：系统公示设置请求默认
     */
    paramInfoGet: function (param) {
        return get('/capital/inflow/param/info', param)
    },
   /* /!**
     * 接口含义：机构管理列表删除
     *!/
    getMechanismListDelete: function (param) {
        return del('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表新增
     *!/
    getMechanismListAdd: function (param) {
        return post('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表搜索
     *!/
    getMechanismSearch: function (param) {
        return get('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表修改
     *!/
    getMechanismEdit: function (param) {
        return put('/branch/info', param)
    },
    /!**
     * 接口含义：操作日志查询
     *!/
    getLogList: function (param) {
        return get('/log/list', param)
    },
    /!**
     * 接口含义：操作日志下载
     *!/
    getLogExport: function (param) {
        return get('/log/export', param)
    },
    /!**
     * 接口含义：机构
     *!/
    getBranchTree: function (param) {
        return get('/branch-tree/list', param)
    },
    /!**
     * 接口含义：操作日志下载部分
     *!/
    getLogExportPart: function (param) {
        return put('/log/export-part', param)
    },*/
}
