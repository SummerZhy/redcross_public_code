import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default {
    /**
     * 接口含义：善款列表查詢
     */
    getMoneyList: function (param) {
        return get('/capital/inflow/list', param)
    },
   /**
     * 接口含义：善款入账详情
     */
    getMoneyDetail: function (param) {
        return get('/capital/inflow/info', param)
    },
    /**
     * 接口含义：审核退回处理列表查询
     */
    auditList: function (param) {
        return get('/capital/inflow/audit/list', param)
    },
     /**
     * 接口含义：资金接收补录--审核退回处理补录
     */
     inflowPut: function (param) {
        return put('/capital/inflow/info', param)
    },



     /**
     * 资金使用接口
     */
    /**
     * 接口含义：资金出账上传
     */
    outflowUploadPost: function (param) {
        return post('/capital/outflow/upload', param)
    },
    /**
     * 接口含义：资金出账列表
     */
    outflowListGet: function (param) {
        return get('/capital/outflow/list', param)
    },
    /**
     * 接口含义：资金出账增加
     */
    outflowInfoPost: function (param) {
        return post('/capital/outflow/info', param)
    },
    /**
     * 接口含义：资金出账导入
     */
    outflowImportPost: function (param) {
        return post('/capital/outflow/import', param)
    },
    /**
     * 接口含义：资金出账详情
     */
    outflowInfoGet: function (param) {
        return get('/capital/outflow/info', param)
    },

   /* /!**
     * 接口含义：用户管理查询
     *!/
    userInfoGet: function (param) {
        return get('/user/info', param)
    },
    /!**
     * 接口含义：用户管理修改
     *!/
    userInfoPut: function (param) {
        return put('/user/info', param)
    },
    /!**
     * 接口含义：用户管理删除
     *!/
    userInfoDel: function (param) {
        return del('/user/info', param)
    },
    /!**
     * 接口含义：用户管理状态维护
     *!/
    userStatusPut: function (param) {
        return put('/user/status', param)
    },
    /!**
     * 接口含义：用户管理密码重置
     *!/
    userCodeReset: function (param) {
        return put('/user/code/reset', param)
    },
    /!**
     * 接口含义：机构管理列表初始
     *!/
    getMechanismList: function (param) {
        return get('/branch/list', param)
    },
    /!**
     * 接口含义：机构管理列表删除
     *!/
    getMechanismListDelete: function (param) {
        return del('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表新增
     *!/
    getMechanismListAdd: function (param) {
        return post('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表搜索
     *!/
    getMechanismSearch: function (param) {
        return get('/branch/info', param)
    },
    /!**
     * 接口含义：机构管理列表修改
     *!/
    getMechanismEdit: function (param) {
        return put('/branch/info', param)
    },
    /!**
     * 接口含义：操作日志查询
     *!/
    getLogList: function (param) {
        return get('/log/list', param)
    },
    /!**
     * 接口含义：操作日志下载
     *!/
    getLogExport: function (param) {
        return get('/log/export', param)
    },
    /!**
     * 接口含义：机构
     *!/
    getBranchTree: function (param) {
        return get('/branch-tree/list', param)
    },
    /!**
     * 接口含义：操作日志下载部分
     *!/
    getLogExportPart: function (param) {
        return put('/log/export-part', param)
    },*/
}
