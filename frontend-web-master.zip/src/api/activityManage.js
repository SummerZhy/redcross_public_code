import {
    get,
    getResponse,
    post,
    postResponse,
    put,
    patch,
    del
  } from '@/utils/http'
  
  export default {
    //查询社团活动列表
    getClubActivityList:function(param){
        return get('/clubActivity/list', param)
    },
    //新增社团活动
    addClubActivity:function(param){
      return post('/clubActivity/add', param)
    },
    //修改社团活动
    editClubActivity:function(param){
      return put('/clubActivity/edit', param)
    },
    //删除社团活动
    delClubActivity:function(param){
      return del('/clubActivity/delete', param)
    },
    //查看社团活动详情
    getClubActivityDetail:function(param){
      return get('/clubActivity/detail', param)
    },
  }