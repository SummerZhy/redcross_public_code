import {
    get,
    getResponse,
    post,
    postResponse,
    put,
    patch,
    del
  } from '@/utils/http'
  
  export default {
    //报名人员名单列表
    getSignUpList:function(param){
        return get('/clubActivity/participants/list', param)
    },
    //社团活动管理-报名人员名单列表-导出
    exportApplicants:function(param){
        return post('/clubActivity/participants/export', param,{headers:{
          'Content-Type':'application/json'
        }
      })
    },
    //社团活动管理-参加人员名单列表
    getSignInList:function(param){
      return get('/clubActivity/signIn/list', param)
    },
    //社团活动管理-参加人员名单列表-导出
    exportSignIn:function(param){
      return post('/clubActivity/signIn/export', param,{headers:{
        'Content-Type':'application/json'
      }
    })
    }
  }