import {
    get,
    getResponse,
    post,
    postResponse,
    put,
    patch,
    del
  } from '@/utils/http'
  
  export default {
    //查询工会会员列表
    getMemberManageList:function(param){
        return get('/memberManage/list', param)
    },
  }