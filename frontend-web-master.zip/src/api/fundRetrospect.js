import {get,get1,post,post1,put,patch,del} from '@/utils/http'
//资金追溯
export default{
  /**
   * 接口含义：资金追溯-捐赠列表查询
   */
  getDonorList: function (param) {
    return get('/capital/inflow/retrospect/list', param)
  },
  /**
   * 接口含义：资金追溯-捐赠详情列表查询
   */
  getDonorDetailList: function (param) {
    return get('/capital/inflow/retrospect/infolist', param)
  },
  /**
   * 接口含义：资金追溯-捐赠评价
   */
  putEvaluate: function (param) {
    return put('/capital/inflow/retrospect/info', param)
  },
  /**
   * 接口含义：资金追溯-受赠列表查询
   */
  getOutflowList: function (param) {
    return get('/capital/outflow/retrospect/list', param)
  },
  /**
   * 接口含义：资金追溯-受赠确认
   */
  outflowAffirminfo: function (param) {
    return put('/capital/outflow/retrospect/affirminfo', param)
  },
  /**
   * 接口含义：资金追溯-受赠评价
   */
  outflowEvaluate: function (param) {
    return put('/capital/outflow/retrospect/info', param)
  },
}
