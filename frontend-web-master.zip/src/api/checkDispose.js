import {get,get1,post,post1,put,patch,del} from '@/utils/http'
//审核处理
export default{
  /**
   * 接口含义：受赠人评价审核列表查询
   */
  outflowCommentList: function (param) {
    return get('/capital/outflow/comment/list', param)
  },
  /**
   * 接口含义：受赠人评价审核
   */
  putOutflowCommentInfo: function (param) {
    return put('/capital/outflow/comment/info', param)
  },
}
