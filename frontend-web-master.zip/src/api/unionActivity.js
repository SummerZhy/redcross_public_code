import {
    get,
    getResponse,
    post,
    postResponse,
    put,
    patch,
    del
  } from '@/utils/http'
  
  export default {
    //查询工会活动列表
    getUnionActivityList:function(param){
        return get('/unionActivity/list', param)
    },
    //新增工会活动
    addUnionActivity:function(param){
      return post('/unionActivity/add', param)
    },
    //修改工会活动
    editUnionActivity:function(param){
      return put('/unionActivity/edit', param)
    },
    //删除工会活动
    delUnionActivity:function(param){
      return del('/unionActivity/delete', param)
    },
    //查看工会活动详情
    getUnionActivityDetail:function(param){
      return get('/unionActivity/detail', param)
    },
  }