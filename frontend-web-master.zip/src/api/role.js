import {get,get1,post,post1,put,patch,del} from '@/utils/http'

export default{
  /**
   * 接口含义：角色管理列表查询
   */
  getRoleList: function (param) {
    return get('/role/list', param)
  },
  /**
   * 接口含义：全部菜单查询
   */
  menuAll: function (param) {
    return get('/menu/all', param)
  },
  /**
   * 接口含义：角色管理新增
   */
  roleInfoPost: function (param) {
    return post('/role/info', param)
  },
  /**
   * 接口含义：角色管理修改
   */
  roleInfoPut: function (param) {
    return put('/role/info', param)
  },
  /**
   * 接口含义：角色管理查询
   */
  roleInfoGet: function (param) {
    return get('/role/info', param)
  },
  /**
   * 接口含义：角色管理删除
   */
  roleInfoDel: function (param) {
    return del('/role/info', param)
  },
}
