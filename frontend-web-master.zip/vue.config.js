const path = require('path')
const merge = require('webpack-merge')
const CopyWebpackPlugin = require('copy-webpack-plugin')

function resolve(dir) {
    return path.join(__dirname, '..', dir)
}

module.exports = {
    //publicPath: '/api',
    productionSourceMap: true,
    lintOnSave: false,
    configureWebpack: {
        performance: {
            hints: 'warning',
            //入口起点的最大体积(整数类型，以字节为单位)
            maxEntrypointSize: 50000000,
            //生成文件的最大体积
            maxAssetSize: 30000000,
            //只给出js文件和css文件的性能提示
            assetFilter: function (assetFileName) {
                return assetFileName.endsWith('.js') || assetFileName.endsWith('.css')
            }
        },
        //static生成静态文件
        plugins: [
            new CopyWebpackPlugin(
                [{
                    from: path.resolve(__dirname, './static'),
                    to: path.resolve(__dirname, './dist/static'),
                    ignore: ['.*']
                }]
            )
        ]
    },
    chainWebpack: config => {
        if (process.env.NODE_ENV === 'production') {
            //生产环境去掉console
            /* config.optimization.minimizer[0].options.terserOptions.compress.warning = false
            config.optimization.minimizer[0].options.terserOptions.compress.drop_console = true
            config.optimization.minimizer[0].options.terserOptions.compress.drop_debugger = true */
        }

        //加载SVG文件
        const svgRule = config.module.rule('svg');
        svgRule.uses.clear();
        config.module.rule('svg')
            .set('include', [resolve('src/assets/icons')])
            .use('svg-sprite-loader')
            .loader('svg-sprite-loader')
            .options({
                symbolId: 'icon-[name]'
            })
    },
    css: {
        //是否使用css分离插件ExtracTextPlugin
        extract: true,
    },
    devServer: {
        port: 9080,
        host: 'localhost',
        open: true,
        proxy: {
            '/api': {
                // target: 'http://lu.tech.dccnet.com.cn:8090/mock/11/api/',
                target: 'http://lu.tech.dccnet.com.cn:8090/mock/15/',
                // target: 'http://39.99.188.76:3000/mock/17/',
                changeOrigin: true,
                pathRewrite: {
                    '^/api': '/'
                }
            }
        }
    }
}