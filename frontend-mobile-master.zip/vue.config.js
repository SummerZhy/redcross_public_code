module.exports = {
  chainWebpack: config => {
    config.module
      .rule('css')
        .test(/\.css$/)
        .oneOf('vue')
        .resourceQuery(/\?vue/)
        .use('px2rem')
          .loader('px2rem-loader')
          .options({
            remUnit: 75
          })
  },
  devServer: {
    port: 9080,
    host: 'localhost',
    open: true,
    proxy: {
      '/api': {
        target: 'http://lu.tech.dccnet.com.cn:8090/mock/15/api/',
        changeOrigin: true,
        pathRewrite: {
          '^/api': '/'
        }
      }
    }
  }
}
