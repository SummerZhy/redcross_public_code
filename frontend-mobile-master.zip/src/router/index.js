import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/home/index1'
import Detail from '../views/home/detail'
import associationList from '../views/home/association/list'
import associationDetail from '../views/home/association/detail'
import my from '../views/my/MyHome' // 我的——主页
import donneLogin from '../views/login/DonneLogin'
import donateLogin from '../views/login/donateLogin'
import homePage from '../views/home/homePage'
import donneList from '../views/donne/donneList'
import donneInfo from '../views/donne/donneInfo'
import donateList from '../views/donate/donateList'

//公示
import donation from '../views/promulgate/donation'
import use from '../views/promulgate/use'
import promulgate from '../views/promulgate/promulgate'

import donateInfo from '../views/donate/donateInfo'
import commitSuccess from '../views/public/commitSuccess'


Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        redirect: '/home/homePage'
    }, {
        path: '/home',
        name: 'home',
        component: Home
    }, {
        path: '/detail',
        name: 'detail',
        component: Detail
    }, {
        path: '/my',
        name: 'my',
        component: my
    }, {
        path: '/home/associationList',
        name: 'associationList',
        component: associationList
    }, {
        path: '/home/associationDetail',
        name: 'associationDetail',
        component: associationDetail
    }, {
        path: '/login/donneLogin',
        name: 'donneLogin',
        component: donneLogin
    }, {
        path: '/login/donateLogin',
        name: 'donateLogin',
        component: donateLogin
    }, {
        path: '/home/homePage',
        name: 'homePage',
        component: homePage
    }, {
        path: '/donne/donneList',
        name: 'donneList',
        component: donneList
    }, {
        path: '/donate/donateList',
        name: 'donateList',
        component: donateList
    }, {
        path: '/donate/donateInfo',
        name: 'donateInfo',
        component: donateInfo
    }, {
        path: '/donne/donneInfo',
        name: 'donneInfo',
        component: donneInfo
    }, {

        path: '/home/promulgate',
        name: 'promulgate',
        component: promulgate
    }, {
        path: '/home/donation',
        name: 'donation',
        component: donation
    }, {
        path: '/home/use',
        name: 'use',
        component: use
    }, {
        path: '/public/commitSuccess',
        name: 'commitSuccess',
        component: commitSuccess
    }
]

const router = new VueRouter({
    mode: 'hash',
    base: process.env.BASE_URL,
    routes
})

export default router
