<template>
  <div class="header">
      <div class="header_left">
        <div 
          class="left_img"
          @click="goBack()"
        ></div>
      </div>
      <div class="header_title">
        {{ title }}
      </div>
      <div 
        class="header_right"
      >
      </div>
  </div>

</template>

<script>
export default {
  name: 'Header',
  props: {
    title: {
      type: String,
      default: 'foo'
    },
    showCancel: {
      type: Boolean,
      default: false
    },
    showConfirm: {
      type: Boolean,
      default: false
    },
    finshColor: {
      type: String,
      default: '#393939'
    }
  },
  methods: {
    goBack() {
      this.$router.back()
    },
    completeSelect() {
      this.$emit('completeSelect')
    },
    cancelSelect() {
      this.$emit('cancelSelect')
    }
  }
};
</script>

<style scoped>
.header {
  background: #fff;
  position: fixed;
  width: 100%;
  height: 88px;
  font-size: 28px;
  border-bottom: 1px solid #ddd;
  z-index: 100;
  text-align: center;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center
}
.left_img {
  height: 34px;
  width: 34px;
  margin-left: 30px;
  background: url("../../assets/img/close.png") no-repeat center;
  background-size:cover;
}
.header_title{
font-family: PingFang-SC-Medium;
font-size: 32px;
text-align: center;
color: #121212;
letter-spacing: 0;
}
.header_right {
  height: 44px;
  right: 30px;
}
</style>
