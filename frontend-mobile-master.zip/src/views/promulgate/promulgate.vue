<template>
    <div class="container">
        <div>
            <Header title="捐款信息公示"></Header>
        </div>
        <div class="body">
            <div class="bonnerImg"></div>
            <!-- <div class="choose"><span class="span1">2020.01.21-2020.02.21</span><span class="span2" @click="turn()">筛选&gt;</span></div> -->
            <van-tabs v-model="active">
                <van-tab title="捐赠筹款">
                    <!-- for循环 -->
                    <div class="tab1" v-for="(value,index) in donationList" :key="index">
                        <p><span class="span1">{{value.dEntryDate}}</span><span class="span2">共&nbsp;<b>&yen;{{value.totalAmount}}</b></span></p>
                        <!-- 再循环 -->
                        <div v-for="(v,i) in value.dataList" :key="i">
                            <p class="p1"><span class="span1">{{v.cDonerName}}</span><span class="span2">{{v.cDonateDirection}}</span><span class="span3">&yen;{{v.nTotalAmount}}</span></p>
                            <!-- <p class="p2"><span class="span1"></span><span class="span2"></span></p> -->
                            <p class="p3"><span class="span1">{{v.time}}</span><span class="span2" @click="getInformation(v.cfundCode)" v-if="v.cFundState=='01'||v.cFundState=='02'">查看受赠信息</span></p>
                        </div>
                    </div>
                </van-tab>
                <van-tab title="资金使用">
                    <!-- for循环 -->
                    <div class="tab2" v-for="(value,index) in useList" :key="index">
                        <p><span class="span1">{{value.date}}</span><span class="span2">共&nbsp;<b>&yen;{{value.amount}}</b></span></p>
                        <!-- 再循环 -->
                        <div v-for="(v,i) in value.todayList" :key="i">
                            <p class="p1"><span class="span1">{{v.doneeName}}</span><span class="span2">{{v.direction}}</span><span class="span3">&yen;{{v.amount}}</span></p>
                            <!-- <p class="p2"><span class="span1">{{v.dateTime}}</span><span class="span2">口罩100箱，消毒水1吨</span></p> -->
                            <p class="p3"><span class="span1">{{v.dateTime}}</span><span class="span2" @click="getPingjia(v)" v-if="v.isEvaluate=='01'">查看评价</span></p>
                        </div>
                    </div>
                </van-tab>
              </van-tabs>
        </div>
        <!-- 查看受赠信息 -->
        <van-popup
            v-model="flag"
            closeable
            position="bottom"
            :style="{ height: '60%' }">
            <header>受赠信息</header>
            <!-- 循环 -->
            <div class="tab1" v-for="(value,index) in donationInfo" :key="index">
                <div>
                    <p class="p1"><span class="span2" style="margin-left: 0;border: 1px solid #9DBAE3;color: #9DBAE3;background-color: #F0F4FA;">受赠</span><span class="span1">{{value.cdDoneeName}}</span></p>
                    <p class="p2"><span class="span1">{{value.dDate}}</span><span class="span2">{{value.cDonateAmount}}</span></p>
                    <!-- <p class="p3"><span class="span1">12:28:02</span></p> -->
                </div>
            </div>
        </van-popup>
        <!-- 查看评价 -->
        <van-popup
            v-model="show"
            closeable
            position="bottom"
            :style="{ height: '60%' }">
            <header>评价</header>
            <div class="tab1">
                <div>
                    <p class="p1"><span class="span1">{{Pingjia.doneeName}}</span><span style="color: red;float: right;margin-right: 10px;">{{Pingjia.evaluateDate}} {{Pingjia.evaluateTime}}</span></p>
                    <p class="p2"><span class="span1">{{Pingjia.evaluator}}</span><span class="span2">
                       <van-rate v-model="Pingjia.star" color="red" />
                    </span></p>
                    <p style="line-height:20px;font-size:12px；text-align:left;background:#fff;margin-bottom:10px;height: auto;">{{Pingjia.comments}}</p>
                    <!-- <div style="width: 94%;height:100px;margin-left: 3%;overflow-y: hidden;display: flex;">
                        <img src=".././././../assets/img/logo.png" style="width: 100px;height: 100px;">
                        <img src=".././././../assets/img/logo.png" style="width: 100px;height: 100px;">
                        <img src=".././././../assets/img/logo.png" style="width: 100px;height: 100px;">
                        <img src=".././././../assets/img/logo.png" style="width: 100px;height: 100px;">
                    </div> -->
                </div>
            </div>
        </van-popup>
            
    </div>
</template>

<script>
import Header from '@/components/common/Header'
    export default {
        name: "promulgate",
        components: {
            Header
            },
        data(){
            return{
                active: 0,
                flag:false,
                show:false,
                donationList:[],
                donationInfo:[],
                useList:[],
                Pingjia:{},
            }
        },
        created(){
            this.active=this.$route.query.type;
            this.getDonationList();
            this.getUseList();
        },
        methods:{
            getInformation(id){
                this.flag=true;
                this.$api.myApi.getInfo({cfundCode:id})
                .then((res) => {
                    if (res.retCode === '0') {
                        this.donation=res.result.list;
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            },
            getPingjia(v){
                this.show=true;
                this.Pingjia=v;
            },
            getDonationList(){
                this.$api.myApi.getDonationList()
                .then((res) => {
                    if (res.retCode === '0') {
                        this.donationList=res.result.list;
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            },
            getUseList(){
                this.$api.myApi.getUseList()
                .then((res) => {
                    if (res.retCode === '0') {
                        this.useList=res.result.list;
                        console.log(res.result.list)
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            },
            //筛选页面
            turn(){
                if(this.active==0){
                    this.$router.push(
                        {
                            path:'/home/donation'
                        }
                    )
                }else{
                    this.$router.push(
                        {
                            path:'/home/use'
                        }
                    )
                }
            }
        }
    }
</script>

<style lang="less" scoped>
.container{
    color:#000;
    background-color: #ffffff;
    .body{
        .bonnerImg{
            height: 127px;
            width: 100%;
            background-image:url("../../assets/img/banner_home_2.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
        }
        .choose{
            background-color: #F4F4F4;
            width: 100%;
            height: 40px;
            line-height:40px;
            font-size:12px;
            color: #333;
            .span1{
                margin-left: 10px;
                float: left;
                font-size:13px;
            }
            .span2{
                float: right;
                margin-right: 10px;
            }
        }
    }
    .van-popup{
        width: 92%;
        margin-left: 4%;
        margin-bottom: 30%;
        overflow-Y: hidden;
        border-radius: 5px;
        header{
            width: 100%;
            line-height: 34px;
            border-bottom:1px solid #c8c9cc;
            font-size:12px;
            font-weight:600;
        }
    }
    .van-popup /deep/ .van-icon{
        font-size: 14px;
        top: 10px;
    }
}
.body /deep/ .van-tab__text{
    font-size: 14px;
}
.body /deep/ .van-tab--active{
        color:#E80000;
}
/* tab1 */
.tab1,.tab2{
    background-color: #ffffff;
    p{
        background-color: #F4F4F4;
        width: 100%;
        height: 30px;
        line-height:30px;
        font-size:12px;
        .span1{
            color:#919191;
            float: left;
            margin-left:10px;
            height: 30px;
            line-height:30px;
        }
        .span2{
            font-weight: 600;
            float: right;
            margin-right: 10px;
            b{
                color: #E80000;
            }
        }
    }
    div{
        background-color: #fff;
        width: 100%;
        height: 62px;
        border-bottom: 1px solid #F2F2F2;
        padding-left: 5%;
        box-sizing: border-box;
        .p1{
            background-color: #ffffff;
            .span1{
                margin-left: 0;
                float: left;
                font-weight: 600;
                color: #000;
            }
            .span2{
                box-sizing: border-box;
                float: left;
                margin-left: 10px;
                display: inline;
                color: #F37979;
                border: 1px solid #F37979;
                background-color: #FEF2F2;
                margin-top: 7px;
                line-height: 16px;
                font-size: 10px;
                padding: 0 5px;
                border-radius: 3px;
            }
            .span3{
                color: #000;
                float: right;
                margin-right: 10px;
            }
        }
        .p2{
            background-color: #ffffff;
            .span1{
                width: 50%;
                margin-left: 0;
                overflow-X: hidden;
                text-align:left;
            }
            .span2{
                overflow-X: hidden;
                width: 40%;
                height: 30px;
                color:#919191;
                font-weight: 400;
                text-align: right;
            }
        }
        .p3{
            background-color: #ffffff;
            .span1{
                margin-left: 0;
            }
            .span2{
                color: #437CC9;
            }
        }
    }
}
/* 弹框 */
.dialog{
    width: 90%;
    height: 70%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    background-color: #ffffff;
    border-radius: 5px;
    header{
        border-bottom: 1px solid #eee;
        line-height:30px;
        font-size:12px;
        font-weight:600;
        span{
            float: right;
            margin-right: 10px;
            font-size: 16px;
            font-weight: 400;
        }
    }
}
.star /deep/ .van-icon-star,.star /deep/ .van-icon,.star /deep/ .van-rate__icon,.star /deep/ .van-rate__icon--full{
}
</style>