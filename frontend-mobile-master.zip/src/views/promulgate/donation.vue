<template>
    <div>
        <header>筛选<span @click="goBack">取消</span></header>
        <div style="width: 96%;margin: auto;">
            <p style="line-height: 30px;font-size: 14px;text-align: left;">捐款事件</p>
            <div class="div1" style="display: flex;justify-content: space-between;align-content: space-between;width: 100%;height: 70px;">
                <div>全部</div>
                <div>近1个月</div>
                <div>近3个月</div>
                <div>近半年</div>
                <div>近1年</div>
                <div>1年前</div>
            </div>
        </div>
        <div style="width: 96%;margin: auto;">
            <p style="line-height: 30px;font-size: 14px;text-align: left;">捐款金额</p>
            <div class="div1" style="display: flex;justify-content: space-between;align-content: space-between;width: 100%;height: 70px;">
                <div>全部</div>
                <div>小于100</div>
                <div>100-500</div>
                <div>500-1万</div>
                <div>1万-10万</div>
                <div>大于10万</div>
            </div>
        </div>
        <div style="width: 96%;margin: auto;">
            <p style="line-height: 30px;font-size: 14px;text-align: left;">受赠情况</p>
            <div class="div1" style="display: flex;justify-content: space-between;align-content: space-between;width: 100%;height: 30px;">
                <div>全部</div>
                <div>已使用03</div>
                <div>未使用00</div>
            </div>
        </div>
        <div style="width: 96%;margin: auto;">
            <p style="line-height: 30px;font-size: 14px;text-align: left;">捐款方向</p>
            <div class="div1" style="display: flex;justify-content: space-between;align-content: space-between;width: 100%;height: 110px;">
                <div>全部</div>
                <div>助学</div>
                <div>助困</div>
                <div>助老</div>
                <div>助残</div>
                <div>大病</div>
                <div>大病</div>
                <div>大病</div>
            </div>
        </div>
        <footer><button>重置</button><button class="button2">确定</button></footer>
    </div>
</template>
<script>
    export default{
        name:'donation',
        data(){
            return{

            }
        },
        created(){
            this.choose()
        },
        methods:{
            goBack(){
                this.$router.push({path:'/home/promulgate',query:{type:0}})
            },
            choose(){
                console.log(document.getElementsByClassName('div1'))

            }
        }
    }
</script>
<style lang="less" scoped>
    header{
        border: 1px solid;
        line-height: 30px;
        font-size: 14px;
        font-weight: 600;
        span{
            float: right;
            margin-right:10px;
            font-size:12px;
            font-weight:400;
        }
    }
    .div1{
        flex-direction: row ;
        flex-wrap: wrap;
    }
    .div1>div{
        width: 30%;
        height: 30px;
        background-color: #eaeaea;
        line-height: 30px;
        font-size: 12px;
    }
    footer{
        position: fixed;
        bottom: 10px;
        width: 96%;
        margin-left: 2%;
        button{
            width: 30%;
            line-height:40px;
            border:none;
            float: left;
            color:#000;
        }
        .button2{
            background-color: red;
            float: right;
            width: 60%;
            color: #fff;
        }
    }
</style>