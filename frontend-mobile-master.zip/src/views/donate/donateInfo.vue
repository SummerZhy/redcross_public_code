<template>
    <div class="container">
        <div>
        <Header title="评价"></Header>
        </div>
        <div class="body">
            <div class="bonnerImg"></div>
            <div class="tipClass">
                请您确认以下信息，并对本次捐赠进行评价
            </div>
            <div class="btnLoc">
                <div class="cardInfo">
                    <div class="cardList"><div class="textLeft">捐赠信息</div></div>
                    <div v-for="(item,index) in dataList" :key=index>
                        <div class="cardList">
                            <div class="text2Left">{{item.name}}</div>
                            <div class="text2Right">{{item.value}}</div>
                        </div>
                        <div style="margin-left:15px;height:0.5px;width:315;background: #DCDCDC;"></div>
                    </div>
                </div>
            </div>
            <div style="margin-left:20px;margin-top:20px;font-family: PingFang-SC-Regular;font-size: 18px;color: #0E131A;letter-spacing: 0;">信息反馈</div>
            <div class="itemList">
                <div class="starClass">评价星级</div>
                <div class="starClass"><van-rate size="25" color="#F42D2D" v-model=value bind change="onchange"></van-rate></div>
            </div>
            <div style="background: #FFFFFF;height:1px;width:359px;margin-left:15px"></div>
            <div>
                <div class="starClass">留言</div>
                <textarea id="textarea" contenteditable="true"> </textarea>
            </div>
            <div class="btnLoc">
                <div class="btnClass" @click="ensureComm()">确认评价</div>
            </div>
        </div>
    </div>
</template>

<script>
import { Dialog,Rate } from 'vant';
import Header from '@/components/common/Header';
import { close } from 'fs';
    export default {
        name: "mayHome",
        components: {
            Header
            },
        data(){
            return{
                value:3,
                donneData:{
                    entryCode:'RE876443',
                    receiveAmount:"3000",
                    receiveName:"张先生",
                    address:'',
                    saveReason:'医疗',
                    receiveTimeStr:'2020-02-22'
                },
                nameList:["资金编码","捐赠金额","受助者","单位/地址","救助原因","日期"],
                dataList:[]
            }
        },
        created(){
            this.getInfo();
        },
        methods:{
            onChange(event){
                this.setData({
                    value:event.detail
                })
            },
            ensureComm(){
                let param={
                    cfundCode:this.donneData.entryCode,
                    cscore:this.value,
                    cevaluation:document.getElementById("textarea").value,
                    cdonorPhone:sessionStorage.getItem("mobilePhone")}
                Dialog.alert({
                    title:'提示',
                    message:'是否确认并提交评价？',
                    showCancelButton:true
                }).then(()=>{
                    this.$api.myApi.commitComment(param)
                    .then((res) => {
                        if (res.retCode === '0') {
                            this.$router.push({path:'/public/commitSuccess',query:{type:2}})
                        } else {
                            this.$toast.warnToast(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
                }).catch(()=>{
                    done()
                }
                )
            },
            goDonateLogin(){
                this.$router.push({path:'/login/donneLogin'})
            },
            goDonneLogin(){
                this.$router.push({path:'/login/donateLogin'})
            },
            getVerifyCode(){
            },
            getInfo() {
                this.dataList = [];
                this.dataList.push({name:"资金编码",value:this.$store.state.donateInfo.entryCode})
                this.dataList.push({name:"捐赠金额",value:this.$store.state.donateInfo.captialAmount})
                this.dataList.push({name:"捐赠人姓名",value:this.$store.state.donateInfo.captialUserName})
                this.dataList.push({name:"单位/地址",value:this.$store.state.donateInfo.entryCode})
                this.dataList.push({name:"联系电话",value:sessionStorage.getItem('mobilePhone')})
                this.dataList.push({name:"捐赠方向",value:this.$store.state.donateInfo.captialDirection})
                this.dataList.push({name:"捐赠时间",value:this.$store.state.donateInfo.entryCode})
                // this.$api.myApi.getInfo()
                //     .then((res) => {
                //         if (res.retCode === '0') {
                //            this.name = res.name;
                //            this.oA = res.oA
                //         } else {
                //             console.log(res.retMsg)
                //         }
                //     })
                //     .catch(err => {
                //         console.log(err)
                //     })
            }
        }
    }
</script>

<style lang="less" scoped>
.container{
    background-color: #ffffff;
    .body{
        text-align: left;
        .bonnerImg{
            height: 127px;
            width: 100%;
            background-image:url("../../assets/img/banner_home_2.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
        }
        .cardInfo{
            background: #F8F8F8;
            border-radius: 8px;
            border-radius: 8px;
            width: 87%;
            .cardList{
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                padding: 10px
            }
        }
        .starClass{
            margin-left:20px;
            margin-top:20px;
            font-family: PingFangSC-Regular;
            font-size: 16px;
            color: #484848;
            letter-spacing: 0;
            line-height: 16px;            
        }
        .btnClass{
           background-image: linear-gradient(135deg, #FF6834 0%, #F42D2D 100%);
            border-radius: 4px;
            border-radius: 4px;
            height: 45px;
            width: 345px; 
            font-family: PingFangSC-Medium;
            font-size: 16px;
            color: #FFFFFF;
            letter-spacing: 0.5px;
            text-align: center;
            line-height: 45px;
        }
        .tipClass{
            height: 48px;
            width: 100%;
            font-family: PingFang-SC-Regular;
            font-size: 15px;
            color: #919191;
            text-align: left;
            margin-left: 20px;
            line-height: 48px;            
        }
        .detailClass{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }
        .itemList{
            display: flex;
            flex-direction: row;
            align-items: center;
        }
        .btnLoc{
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
        }
    }
}
.listItem{
    display:flex;
    flex-direction:row; 
    justify-content: space-between;
    align-items: center;
    margin-top:10px    
}
.text1{
    font-family: PingFang-SC-Medium;
    font-size: 16px;
    color: #393939;
    letter-spacing: 0;
}
.text2Left{
 margin-left:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #0E131A;letter-spacing: 0;}
.text2Right{
margin-right:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #0E131A;letter-spacing: 0;
}
.textLeft{
font-family: PingFang-SC-Medium;margin-left:20px;font-size: 16px;color: #393939;letter-spacing: 0;    
}
.textRight{
font-family: PingFang-SC-Medium;margin-right:20px;font-size: 16px;color: #393939;letter-spacing: 0;    

}
#textarea{
    width: 80%;
    border: none;
    min-height: 20px;
    max-height: 80px;
    overflow: auto;
    font-size: 14px;
    outline: none;
    margin-left:30px;
    font-family: PingFangSC-Regular;
    font-size: 15px;
    color: #919191;
    letter-spacing: 0;
    text-align: justify;
    line-height: 60px;    
}
div{
font-family: PingFang-SC-Regular;
font-size: 14px;
color: #0E131A;
letter-spacing: 0;
}
</style>