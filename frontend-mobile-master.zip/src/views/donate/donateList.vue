<template>
    <div class="container">
        <div>
        <Header title="捐赠追查"></Header>
        </div>
        <div class="body">
            <div class="bonnerImg">
                <div class="titleClass">{{capitalSum.captialUserName}}的捐赠</div>
                <div class="infoClass">
                    <div style="margin-right:62px">
                        <div style="font-family: PingFang-SC-Regular;font-size: 14px;color: #FFFFFF;letter-spacing: 0;text-align: center;">捐赠金额</div>
                        <div style="margin-top:10px;font-family: SourceHanSansCN-Heavy;font-size: 16px;color: #FFFFFF;letter-spacing: 0;text-align: center;">￥{{capitalSum.captialAmount}}</div>
                    </div>
                    <div style="background: #FFFFFF;width:1px;height:25px"></div>
                    <div style="margin-left:62px">
                        <div style="font-family: PingFang-SC-Regular;font-size: 14px;color: #FFFFFF;letter-spacing: 0;text-align: center;">捐赠次数</div>
                        <div style="margin-top:10px;font-family: SourceHanSansCN-Heavy;font-size: 16px;color: #FFFFFF;letter-spacing: 0;text-align: center;">{{capitalSum.captialCount}}</div>
                    </div>
                </div>
            </div>
            <van-pull-refresh v-model="isDownLoading" @refresh="onDownRefresh">
              <van-list v-model="isUpLoading" :finished="upFinished" :immediate-check="false" :offset="10" finished-text="" @load="onLoadList">
            <div class="donneList" v-for="(item,index) in dayList" :key="index">
                <div class="listTitle">
                    <div style="margin-left:20px">{{item.capitalTimeStr}}</div>
                    <div style="margin-right:20px">捐赠￥<p style="color:red;">{{item.captialAmount}}</p> 使用￥<p style="color:red;">{{item.useAmount}}</p></div>
                </div>
                <div class="list" v-for="(item1,index1) in item.donateList" :key="index1">
                    <div style="display:flex;flex-direction:row;margin-top:15px; justify-content: space-between"> 
                        <div class="textLeft">{{item1.captialUserName}}</div>
                        <div class="textRight">金额￥{{item1.captialAmount}}</div>
                    </div>
                    <div class="listItem">
                        <div class="text2Left">{{item1.captialDirection}}</div>
                    </div>
                    <div class="listItem">
                        <div style="margin-left:20px;font-family: PingFang-SC-Regular;font-size: 14px;color: #3B76C7;letter-spacing: 0;">捐赠使用情况</div>
                        <div class="btnClass" @click="sureGet(item1)">马上评价</div>
                    </div>
                    <div class="centerClass">
                        <div class="listCard">
                            <div style="margin-top:15px" v-for="(item2,index2) in item1.donateInfoList" :key="index2">
                                <div class="listItem"><div class="textLeft" style="margin-top:7.5px">{{item2.projectName}}</div></div>
                                <div class="listItem">
                                    <div class="text2Left">{{item2.rescueReason}}</div>
                                    <div class="textRight">{{item2.captialAmount}}</div>
                                </div>
                                <div class="listItem">
                                    <div class="text2Left">{{item2.captialTimeStr}}</div>
                                    <div class="text2Right">查看受赠人评价</div>
                                </div>
                                <div style="background: #DCDCDC;width:315px;height:0.5px;margin-left: 15px; margin-top: 7.5px;"></div>
                            </div>
                        </div>
                    </div>
                   <div style="margin-top:10px;background:#DCDCDC;height:1px;width:100%;"></div>
                </div>
            </div>
              </van-list>
            </van-pull-refresh>

        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
import Header from '@/components/common/Header'
    export default {
        name: "mayHome",
        components: {
            Header
            },
        data(){
            return{
                capitalSum:{
                    captialAmount:'1,000,00',
                    captialCount:'25',
                    captialUserName:'张先生'
                },
                dayList:[{
                    captialAmount:'1000',
                    useAmount:'230',
                    capitalTimeStr:'2020-02-01',
                    donateList:[
                        {
                                captialUserName:'张先生',
                                donateInfoList:[{
                                    projectName:'武汉红十字会医院',
                                    captialTimeStr:'2020-02-21',
                                    rescueReason:'jiewof',
                                    captialAmount:'3000',
                                    isSure:''
                                },
                                {
                                    projectName:'武汉红十字会医院',
                                    captialTimeStr:'2020-02-21',
                                    rescueReason:'jiewof',
                                    capitalAmount:'3000',
                                    isSure:''
                                }
                                ],
                                isSure:'0',
                                captialAmount:'234324',
                                captialDirection:'医疗',
                                captialCode:'',
                        },
                        {
                                captialUserName:'张先生',
                                donateInfoList:[{
                                    projectName:'武汉红十字会医院',
                                    captialTimeStr:'2020-02-21',
                                    rescueReason:'jiewof',
                                    captialAmount:'3000',
                                    isSure:''
                                },
                                {
                                    projectName:'武汉红十字会医院',
                                    captialTimeStr:'2020-02-21',
                                    rescueReason:'jiewof',
                                    capitalAmount:'3000',
                                    isSure:''
                                }
                                ],
                                isSure:'0',
                                captialAmount:'234324',
                                captialDirection:'医疗',
                                captialCode:'',                                
                        },
                    ]
                }],
                img:'',
                name:'张三',
                oA:'1001123251',
                border:true,
                currentPage:1,
                limit:6,
                isDownLoading:false,//下拉刷新
                isUpLoading:false,//上拉加载
                upFinished:false,//上拉加载完毕
                offset:100//滚动条与底部小于offset时触发
                }
        },
        created(){
            this.getDonateList()
        },
        methods:{
            getDonateList() {
                const _self = this
                let param={
                mobilePhone:sessionStorage.getItem('mobilePhone'),
                currentPage:this.currentPage,
                limit:this.limit}
                this.$api.myApi.queryDonateList(param)
                    .then((res) => {
                        if (res.retCode === '0') {
                            this.capitalSum = res.result.capitalSum;
                            _self.isDownLoading = false;
                            // if(this.result == null || this.result == ""){
                            // _self.upFinished = true
                            // return
                            // }
                            if(this.dayList.length<this.limit){
                                _self.upFinished = true
                            }
                            if(this.currentPage == 1){
                                _self.dayList = res.result.dayList;
                            }else{
                                _self.dayList = _self.dayList.concat(res.result.dayList);
                            }
                        } else {
                            this.$toast.warnToast("请填写留言")
                        }
                    })
                    .catch(err => {
                        this.$message({
                            type:'error',
                            message:'获取资源异常'
                        })
                    })
            },
        onDownRefresh(){
            this.currentPage = 1;
            this.upFinished = false;
            this.getDonateList();
        },
        onLoadList(){
            this.currentPage++
            this.getDonateList();
        },
            goDonnePage(){
                this.$router.push({path:'/donne/donneList'})
            },
            goDonatePage(){
                this.$router.push({path:'/donate/donateList'})
            },
            getVerifyCode(){
            },
            sureGet(index){
                this.$store.state.donateInfo=index
                // console.log(this.$store.state.donateInfo)
                this.$router.push({path:'/donate/donateInfo'})
            }
        }
    }
</script>

<style lang="less" scoped>
.container{
    background-color: #ffffff;
    .body{
        .bonnerImg{
            height: 127px;
            width: 100%;
            background-image:url("../../assets/img/banner_user.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            .titleClass{
                font-family: PingFang-SC-Semibold;
                font-size: 18px;
                color: #FFFFFF;
                letter-spacing: 0;
                margin-top: 20px;
                text-align: center;
            }
            .infoClass{
                margin-top: 25px;
                display: flex;
                flex-direction: row;
                justify-content: center;
                align-items: center;  
            }
        }
        .donneList{
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            .listTitle{
                background: #F4F4F4;
                height: 40px;
                width: 100%;
                display: flex;
                flex-direction: row;
                align-items: center;
                justify-content: space-between;
            }
            .list{
                width: 100%;
                background: #FFFFFF;
               .btnClass{
                   background-image: linear-gradient(135deg, #FF6834 0%, #F42D2D 100%);
                   border-radius: 4px;
                   border-radius: 4px;
                   width: 74px;
                   height: 30px;
                    font-family: PingFangSC-Regular;
                    font-size: 14px;
                    color: #FFFFFF;
                    letter-spacing: 0;
                    text-align: center;
                    line-height: 30px;
                    margin-right: 20px;                   
               }
                .listCard{
                    background: #F8F8F8;
                    border-radius: 8px;
                    border-radius: 8px; 
                    width: 87%;
        }

            }
        }
        .centerClass{
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            margin-top: 15px;
        }
    }
}
.listItem{
    display:flex;
    flex-direction:row; 
    justify-content: 
    space-between;margin-top:10px    
}
.text1{
    font-family: PingFang-SC-Medium;
    font-size: 16px;
    color: #393939;
    letter-spacing: 0;
}
.text2Left{
 margin-left:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #919191;letter-spacing: 0;}
.text2Right{
margin-right:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #919191;letter-spacing: 0;
}
.textLeft{
font-family: PingFang-SC-Medium;margin-left:20px;font-size: 16px;color: #393939;letter-spacing: 0;    
}
.textRight{
font-family: PingFang-SC-Medium;margin-right:20px;font-size: 16px;color: #393939;letter-spacing: 0;    

}
p{
    padding: 0px;
    margin: 0px;
    display: inline;
}
input{
   -webkit-appearance: none;
   -moz-appearance: none;
   border: none; 
}
input::-webkit-input-placeholder{
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #919191;
    letter-spacing: 0;
}
</style>