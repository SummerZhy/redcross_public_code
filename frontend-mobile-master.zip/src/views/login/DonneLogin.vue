<template>
    <div class="container">
        <div>
            <Header title="身份认证"></Header>
        </div>
        <div class="body">
            <div class="tipClass"><p class="text">我是受赠人</p></div>
            <div class="titleD">
                <p class="text1">立即追踪，实时查询捐赠状态</p>
            </div>
            <div class="inputPhone">
                <input v-model="info.mobilePhone" class="inputClass" id="mobilePhone" placeholder="请输入手机号码"/>
            </div>
            <div style="background: #DCDCDC;height:1px;"></div>
            <div class="verifyCode">
                <div><input v-model="info.verfiCode" placeholder="请输入短信验证码" id="verfiCode"/></div>
                <div style="background: #DCDCDC;height:20px;width:1px;"></div>
                <div style="margin-left: 30pt;">
                    <button id="getCode" class="getCode" @click="getVerifyCode()" :disabled="!disableBtn"><p
                            class="text2">{{getCodeText}}</p></button>
                </div>
            </div>
            <div style="background: #DCDCDC;height:1px;"></div>
            <van-button class="buttonClass" @click="login()" :disabled="!disableLogin"><p class="btnText">立即追踪</p>
            </van-button>
        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
import {
  getToken,
  removeToken,
  setToken,
  setUserInfo,
  getUserInfo,
  removeUserInfo
} from "@/utils/auth";
import Header from '@/components/common/Header'
import { setTimeout } from 'timers';
import { Toast,Dialog } from 'vant';
    export default {
        name: "DonneLogin",
        components: {
            Header
        },
        data() {
            return {
                disableBtn: true,
                getCodeText: '获取验证码',
                img: '',
                name: '张三',
                oA: '1001123251',
                border: true,
                info: {
                    mobilePhone: '',
                    verfiCode: '',
                }
            }
        },
        created() {
            // this.getInfo()
        },
        computed: {
            disableLogin: function () {
                if (this.info.mobilePhone !== '' && this.info.verfiCode.length === 6) {
                    return true;
                } else {
                    return false;
                }
            },
        },
        methods: {
            countDown(time) {
                if (time === 0) {
                    this.disableBtn = true;
                    this.getCodeText = '获取验证码';
                    return
                } else {
                    this.disableBtn = false;
                    this.getCodeText = '重新发送(' + time + ')'
                    time = time - 1;
                }
                setTimeout(() => {
                    this.countDown(time)
                }, 1000)
            },
            getVerifyCode() {
                // alert(document.getElementById("mobilePhone").value);
                let mobilePhone = document.getElementById("mobilePhone").value;
                let param = {'mobilePhone': mobilePhone}
                this.$api.myApi.getCode(param).then((res) => {
                    if (res.retCode === '0') {
                        this.countDown(60)
                    Dialog.confirm({
                        title: '验证码获取成功',
                        message: '您获取的验证码是'+res.result.verifyCode
                    }).then(() => {
                        done()
                    }).catch(() => {
                        // on cancel
                    });
                    }
                })
            },
            login() {
                let mobilePhone = document.getElementById("mobilePhone").value;
                let verifiCode = document.getElementById("verfiCode").value;
                let param={phoneNum:mobilePhone,verifiCode:verifiCode,loginRole:'2'}
                this.$api.myApi.userLogin(param).then((res)=>{
                    if(res.data.retCode==='0'){
                        // console.log(res)
                        setToken(res.headers.authorization);
                this.$router.push({path:'/donne/donneList'})
                sessionStorage.setItem('mobilePhone',mobilePhone)

                    }else{
                this.$toast.warnToast(res.data.retMsg)
                    }
                })
            },
            getInfo() {
                this.$api.myApi.getInfo()
                    .then((res) => {
                        if (res.retCode === '0') {
                            this.name = res.name;
                            this.oA = res.oA
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            }
        }
    }
</script>

<style lang="less" scoped>
    .container {
        background-color: #ffffff;

        .body {
            margin-top: 43px;
            margin-left: 15pt;
            margin-right: 15pt;
            height: 100vh;

            .tipClass {
                height: 28px;
                width: 78px;
                background-image: linear-gradient(135deg, #FFA25C 0%, #FF6834 100%);
                border-radius: 32.5px;
                text-align: center;

                .text {
                    font-family: PingFang-SC-Regular;
                    line-height: 28px;
                    font-size: 12px;
                    color: #FFFFFF;
                    letter-spacing: 0;
                }
            }

            .titleD {
                margin-top: 20px;
                width: 243px;
                height: 16px;

                .text1 {
                    font-family: PingFang-SC-Medium;
                    font-size: 18px;
                    color: #FF9800;
                    line-height: 16px;
                }
            }

            .inputPhone {
                margin-top: 20px;
                height: 61px;
                width: 375px;
            }

            .verifyCode {
                display: flex;
                flex-direction: row;
                align-items: center;
                height: 61px;
                width: 375px;

                .getCode {
                    /*line-height: 61px;*/
                    line-height: 14px;
                    margin-right: 30px;
                    border: none;
                    background-color: #fff;

                    .text2 {
                        font-family: PingFangSC-Regular;
                        font-size: 14px;
                        color: #E80000;
                        letter-spacing: 0;
                    }
                }
            }

            .inputClass {
                width: 375px;
                height: 61px;
            }

            .buttonClass {
                background-image: linear-gradient(135deg, #FFA25C 0%, #FF6834 100%);
                /*background: rgba(232,0,0,0.16);*/
                /*width: 345px;*/
                width: 100%;
                height: 45px;
                border-radius: 4px;
                border: none;
                margin-top: 30px;

                .btnText {
                    font-family: PingFangSC-Medium;
                    font-size: 16px;
                    color: #FFFFFF;
                    letter-spacing: 0.5px;
                    text-align: center;
                    line-height: 45px
                }
            }
        }
    }

    input {
        -webkit-appearance: none;
        -moz-appearance: none;
        border: none;
    }

    input::-webkit-input-placeholder {
        font-family: PingFangSC-Regular;
        font-size: 16px;
        color: #919191;
        letter-spacing: 0;
    }
</style>