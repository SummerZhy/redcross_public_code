<template>
    <div class="container">
        <div>
        <Header title="受赠追查"></Header>
        </div>
        <div class="body">
            <div class="bonnerImg">
                <div class="titleClass">{{donneData.receiveUserName}}的受赠</div>
                <div class="infoClass">
                    <div style="margin-right:62px">
                        <div style="font-family: PingFang-SC-Regular;font-size: 14px;color: #FFFFFF;letter-spacing: 0;text-align: center;">受赠金额</div>
                        <div style="margin-top:10px;font-family: SourceHanSansCN-Heavy;font-size: 16px;color: #FFFFFF;letter-spacing: 0;text-align: center;">￥{{donneData.receiveAmount}}</div>
                    </div>
                    <div style="background: #FFFFFF;width:1px;height:25px"></div>
                    <div style="margin-left:62px">
                        <div style="font-family: PingFang-SC-Regular;font-size: 14px;color: #FFFFFF;letter-spacing: 0;text-align: center;">受赠次数</div>
                        <div style="margin-top:10px;font-family: SourceHanSansCN-Heavy;font-size: 16px;color: #FFFFFF;letter-spacing: 0;text-align: center;">{{donneData.receiveTimes}}</div>
                    </div>
                </div>
            </div>
            <van-pull-refresh v-model="isDownLoading" @refresh="onDownRefresh">
              <van-list v-model="isUpLoading" :finished="upFinished" :immediate-check="false" :offset="10" finished-text="" @load="onLoadList">
            <div class="donneList" v-for="(item,index) in donneData.receiveList" :key="index">
                <div class="listTitle">
                    <div style="margin-left:20px">{{item.receiveTimeStr}}</div>
                    <div style="margin-right:20px">受赠￥<p style="color:red;">{{item.receiveAmount}}</p></div>
                </div>
                <div class="list" v-for="(item1,index1) in item.listDetail" :key="index1">
                    <div style="display:flex;flex-direction:row;margin-top:15px; justify-content: space-between"> 
                        <div style="font-family: PingFang-SC-Medium;margin-left:20px;font-size: 16px;color: #393939;letter-spacing: 0;">{{item1.entryCode}}</div>
                        <div style="font-family: PingFang-SC-Medium;margin-right:20px;font-size: 16px;color: #484848;letter-spacing: 0;">金额￥{{item1.receiveAmount}}</div>
                    </div>
                    <div style="display:flex;flex-direction:row; justify-content: space-between;margin-top:10px">
                        <div style="margin-left:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #919191;letter-spacing: 0;">{{item1.saveReason}}</div>
                    </div>
                    <div style="margin-top:10px;display:flex;flex-direction:row; justify-content: space-between">
                        <div style="margin-left:20px">{{item1.receiveTimeStr}}</div>
                        <div class="btnClass" @click="sureGet(item1)">确认收货</div>
                    </div>
                <div style="margin-top:10px;background:#DCDCDC;height:1px;width:100%;margin-left:20px"></div>
                </div>
            </div>
              </van-list>
            </van-pull-refresh>
        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
import Header from '@/components/common/Header'
    export default {
        name: "mayHome",
        components: {
            Header
            },
        data(){
            return{
                donneData:{
                    receiveTimes:'5',
                    receiveAmount:'10000',
                    receiveUserName:'山东红十字会医院',
                    receiveList:[
                        {
                                receiveAmount:'2000',
                                receiveTimeStr:'2020-01-03',
                                isSure:'0',
                                listDetail:[
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'},
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'}
                                ]
                        },
                        {
                                receiveAmount:'2000',
                                receiveTimeStr:'2020-01-03',
                                isSure:'5',
                                listDetail:[
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'},
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'}
                                ]
                        },
                        {
                                receiveAmount:'2000',
                                receiveTimeStr:'2020-01-03',
                                isSure:'10',
                                listDetail:[
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'},
                                    {entryCode:'BJ5218',receiveAmount:'42000',receiveTimeStr:'18:00:00',saveReason:'病毒防治',receiveTimeStr:'2020-01-03'}
                                ]
                        }
                    ]
                },
                img:'',
                name:'张三',
                oA:'1001123251',
                border:true,
                currentPage:1,
                limit:6,
                isDownLoading:false,//下拉刷新
                isUpLoading:false,//上拉加载
                upFinished:false,//上拉加载完毕
                offset:100//滚动条与底部小于offset时触发

            }
        },
        created(){
            this.getInfo()
        },
        methods:{
        onDownRefresh(){
            this.currentPage = 1;
            this.upFinished = false;
            this.getInfo();
        },
        onLoadList(){
            this.currentPage++
            this.getInfo();
        },
            goDonnePage(){
                this.$router.push({path:'/donne/donneList'})
            },
            goDonatePage(){
                this.$router.push({path:'/donate/donateList'})
            },
            getVerifyCode(){
            },
            sureGet(index){
                this.$store.state.donneInfo=index
                // console.log(this.$store.state.donneInfo)
                this.$router.push({path:'/donne/donneInfo'})
            },
            getInfo() {
                let param={
                mobilePhone:sessionStorage.getItem('mobilePhone'),
                currentPage:this.currentPage,
                limit:this.limit}
                this.$api.myApi.getDonneList(param)
                    .then((res) => {
                        if (res.retCode === '0') {
                            this.donneData = res.result
                            console.log(res.result)
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            }
        }
    }
</script>

<style lang="less" scoped>
.container{
    background-color: #ffffff;
    .body{
        .bonnerImg{
            height: 127px;
            width: 100%;
            background-image:url("../../assets/img/banner_user.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            .titleClass{
                font-family: PingFang-SC-Semibold;
                font-size: 18px;
                color: #FFFFFF;
                letter-spacing: 0;
                margin-top: 20px;
                text-align: center;
            }
            .infoClass{
                margin-top: 25px;
                display: flex;
                flex-direction: row;
                justify-content: center;
                align-items: center;  
            }
        }
        .donneList{
            display: flex;
            flex-direction: column;
            .listTitle{
                background: #F4F4F4;
                height: 40px;
                width: 100%;
                display: flex;
                flex-direction: row;
                align-items: center;
                justify-content: space-between;
            }
            .list{
                width: 100%;
                background: #FFFFFF;
               .btnClass{
                   background-image: linear-gradient(135deg, #FF6834 0%, #F42D2D 100%);
                   border-radius: 4px;
                   border-radius: 4px;
                   width: 74px;
                   height: 30px;
                    font-family: PingFangSC-Regular;
                    font-size: 14px;
                    color: #FFFFFF;
                    letter-spacing: 0;
                    text-align: center;
                    line-height: 30px;
                    margin-right: 20px;                   
               }
            }
        }
    }
}
p{
    padding: 0px;
    margin: 0px;
    display: inline;
}
input{
   -webkit-appearance: none;
   -moz-appearance: none;
   border: none; 
}
input::-webkit-input-placeholder{
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #919191;
    letter-spacing: 0;
}
</style>