<template>
    <div class="container">
            <Header title="评价完成"></Header>
        <div class="body">
            <div class="backImg"></div>
            <div class="textSucc">评价成功</div>
            <div style="margin-top:20px;height:64px;font-family: PingFang-SC-Regular;font-size: 15px;color: #919191;letter-spacing: 0;text-align: center;">您已评价,欢迎关注东营红十字会</div>
            <div class="btnClass" style="margin-top:20px" @click="showMany()">查看更多捐赠情况</div>
        </div>
    </div>
</template>

<script>
import { Dialog } from 'vant';
import Header from '@/components/common/Header';
    export default {
        name: "mayHome",
        components: {
            Header,
            },
        data(){
            return{
            }
        },
        created(){
        },
        methods:{
            ensureComm(){
                Dialog.alert({
                    title:'提示',
                    message:'是否确认收货并提交评价？'
                }).then(()=>{
                    this.$router.push({path:'/public/commitSuccess'})
                }
                )
            },
            showMany(){
                if(this.$route.query.type===1){
                this.$router.push({path:'/donne/donneList'})
                }else{
                this.$router.push({path:'/donate/donateList'})

                }
            },
            getVerifyCode(){
            },
        }
    }
</script>

<style lang="less" scoped>
.container{
    background-color: #ffffff;
    .header{
        text-align: right;
    }
    .body{
        text-align: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        .backImg{
            margin-top: 35px;
            height: 64px;
            width: 64px;
            background-image:url("../../assets/img/icons_succeed.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
        }
        .textSucc{
            margin-top: 30px;
            font-family: PingFangSC-Semibold;
            font-size: 18px;
            color: #484848;
            letter-spacing: 0;
            text-align: center;
            line-height: 18px;
        }
        .btnClass{
           background-image: linear-gradient(135deg, #FF6834 0%, #F42D2D 100%);
            border-radius: 4px;
            border-radius: 4px;
            height: 45px;
            width: 345px; 
            font-family: PingFangSC-Medium;
            font-size: 16px;
            color: #FFFFFF;
            letter-spacing: 0.5px;
            text-align: center;
            line-height: 45px;
        }
    }
}
.listItem{
    display:flex;
    flex-direction:row; 
    justify-content: space-between;
    align-items: center;
    margin-top:10px    
}
.text1{
    font-family: PingFang-SC-Medium;
    font-size: 16px;
    color: #393939;
    letter-spacing: 0;
}
.text2Left{
 margin-left:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #0E131A;letter-spacing: 0;}
.text2Right{
margin-right:25px;font-family: PingFang-SC-Regular;font-size: 14px;color: #0E131A;letter-spacing: 0;
}
.textLeft{
font-family: PingFang-SC-Medium;margin-left:20px;font-size: 16px;color: #393939;letter-spacing: 0;    
}
.textRight{
font-family: PingFang-SC-Medium;margin-right:20px;font-size: 16px;color: #393939;letter-spacing: 0;    

}div{
    font-family: PingFang-SC-Regular;
font-size: 14px;
color: #0E131A;
letter-spacing: 0;
}
</style>