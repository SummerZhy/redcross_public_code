<template>
    <div class="box">
        <HeaderLogo></HeaderLogo>
    </div>
</template>

<script>
    import HeaderLogo from '@/components/common/HeaderLogo'
    import Vue from 'vue';
    import { Lazyload } from 'vant';

    Vue.use(Lazyload);
    
    export default {
        name: "mayHome",
        components: {
            HeaderLogo,
        },
        data(){
            return{

            }
         },
        created(){
        },
        methods:{
            //banner
            getBanner() {
                // this.$api.myApi.getBanner()
                //     .then((res) => {
                //         if (res.retCode === '0') {
                //            this.bannerList = res.result.list;
                //         } else {
                //             console.log(res.retMsg)
                //         }
                //     })
                //     .catch(err => {
                //         console.log(err)
                //     })
            }
        }
    }
</script>

<style lang="less" scoped>
    .box{
        background:#fff;
    }
    .swipe{
        width:90%;
        height:112px;
        overflow:hidden;
        margin-left:5%;
        border:1px solid #000;
        border-radius:10px;
        margin-bottom:10px;
    }
    .sidebar{
        margin-left:5%;
        width:90%;
        height:30px;
    }
    .sidebar /deep/ .van-sidebar-item{
        width:80px;
        line-height:30px;
        padding:0px;
        float:left;
    }
    .sidebar >span{
        float:right;
        color:#999;
        line-height:30px; 
        font-size:12px;
    }
    .union{
        background:#fff;
        display: flex;
        flex: row wrap;
        flex-flow: row;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        padding:5%;
    }
    .left{
        width:30%;
    }
    .left img{
        width:100%;
    }
    .right{
        width:65%;
    }
    .union h4{
        text-align:left;
        line-height:30px;
        font-weight: 400;
        font-style: normal;
        font-size: 14px;
    }
    .union p{
        width:60px;
        line-height:20px;
        border:1px solid #00CC99;
        border-radius:5px;
        text-align:center;
        font-weight: 400;
        font-style: normal;
        font-size: 10px;
        color: #00CC99
    }
    .union span{
        font-weight: 400;
        font-style: normal;
        font-size: 10px;
        float:left;
        line-height:30px;
    }
</style>