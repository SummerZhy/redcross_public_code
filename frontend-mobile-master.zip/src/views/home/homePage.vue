<template>
    <div class="container">
        <div>
        <Header title="爱心捐赠"></Header>
        </div>
        <div class="body">
            <div class="bonnerImg"></div>
            <div class="title1">
                <div style="background:#CC3400;height:16px;width:3px"></div>
                <div class="titleClass">捐赠信息公示</div>
            </div>
            <div class="part1">
                <div class="part1-1" @click="goDonateListPage()">
                    <div class="rowClass">
                        <div style="margin-left:15px">捐赠筹款</div>
                        <div style="margin-left:10px"><img src="../../assets/img/icon_arrow.png"/></div>
                    </div>
                    <div class="rowClass">
                        <p style="margin-left:15px;font-family: PingFang-SC-Regular;font-size: 12px;color: #FFFFFF;letter-spacing: 0;">汇聚爱心</p>
                    </div>
                </div>
                <div class="part1-2" @click="goDonneListPage()">
                    <div class="rowClass">
                        <div style="margin-left:15px">资金使用</div>
                        <div style="margin-left:10px"><img src="../../assets/img/icon_arrow.png"/></div>
                    </div>
                    <div class="rowClass">
                        <p style="margin-left:15px;font-family: PingFang-SC-Regular;font-size: 12px;color: #FFFFFF;letter-spacing: 0;">实时追踪</p>
                    </div>
                </div>
            </div>
            <div class="title1">
                <div style="background:#CC3400;height:16px;width:3px"></div>
                <div class="titleClass">查询及评价</div>
            </div>
            <div class="part2">
                <div class="part2-1" @click="goDonateLogin()">
                    <div class="tipClass1"><p class="text">我是捐赠人</p></div>
                    <div style="margin-left:10px;font-family: PingFang-SC-Regular;font-size: 14px;color: #484848;letter-spacing: 0;">立即追踪，实时查询捐赠状态</div>
                </div>
                <div class="part2-2" @click="goDonneLogin()">
                    <div class="tipClass2"><p class="text">我是受赠人</p></div>
                    <div style="margin-left:10px;font-family: PingFang-SC-Regular;font-size: 14px;color: #484848;letter-spacing: 0;">确认收货，实时反馈受赠信息</div>
                </div>
            </div>
            <!-- <div class="title1">
                <div style="background:#CC3400;height:16px;width:3px"></div>
                <div class="titleClass">评价反馈</div>
            </div> -->
        </div>
        <div class="footer"></div>
    </div>
</template>

<script>
import Header from '@/components/common/Header'
    export default {
        name: "mayHome",
        components: {
            Header
            },
        data(){
            return{
                img:'',
                name:'张三',
                oA:'1001123251',
                border:true
            }
        },
        created(){
            // this.getInfo()
        },
        methods:{
            goDonateLogin(){
                this.$router.push({path:'/login/donateLogin'})
            },
            goDonneLogin(){
                this.$router.push({path:'/login/donneLogin'})
            },
            getVerifyCode(){
            },
            getInfo() {
                this.$api.myApi.getInfo()
                    .then((res) => {
                        if (res.retCode === '0') {
                           this.name = res.name;
                           this.oA = res.oA
                        } else {
                            console.log(res.retMsg)
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            },
            //跳转公示页面
            goDonateListPage(){
                this.$router.push({path:'/home/promulgate',query:{type:0}})
            },
            goDonneListPage(){
                this.$router.push({path:'/home/promulgate',query:{type:1}})

            }
        }
    }
</script>

<style lang="less" scoped>
.container{
    background-color: #ffffff;
    height: 100vh;
    .rowClass{
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: flex-start;
    }
    .body{
        .bonnerImg{
            height: 127px;
            width: 100%;
            background-image:url("../../assets/img/banner_home_2.png") ;
            background-repeat: no-repeat;
            background-size: 100%,100%;
        }
        .title1{
            margin-left: 15px;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: flex-start;
            margin-top: 20px;
            width: 375px;
            height: 20px;
            .titleClass{
                margin-left: 6px;
                font-family: SourceHanSerifSC-Heavy;
                font-size: 18px;
                color: #0E131A;
                letter-spacing: 0;
                text-align: center;
                line-height: 18px;             
            }
            }
        .part1{
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            height: 80px;
            width: 100%;
            margin-top: 25px;
            .part1-1{
                display:flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                background-image: url("../../assets/img/piece1.png");
                background-repeat: no-repeat;
                background-size: 100%,100%;
                margin-right: 7.5px;
                height: 78px;
                width: 165px;
                text-align: center;
                line-height: 78px;
                font-family: PingFang-SC-Medium;
                font-size: 16px;
                color: #FFFFFF;
                letter-spacing: 0;                
            }
            .part1-2{
                display:flex;
                flex-direction: column;
                align-items: flex-start;
                justify-content: center;
                background-image: url("../../assets/img/piece2.png");
                background-repeat: no-repeat;
                background-size: 100%,100%;
                margin-left: 7.5px;
                height: 78px;
                width: 165px;
                text-align: center;
                line-height: 78px;
                font-family: PingFang-SC-Medium;
                font-size: 16px;
                color: #FFFFFF;
                letter-spacing: 0;                
            }
        }
        .part2{
            height: 115px;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            .part2-1{
                display: flex;
                flex-direction: row;
                align-items: center;
                margin-top: 20px;
                height: 50px;
                width: 345px;
                background: #FDF6F4;
                border-radius: 4px;
                border-radius: 4px;
                .tipClass1{
                    margin-left: 15px;
                    background-image: linear-gradient(135deg, #FFA25C 0%, #FF6834 100%);
                    border-radius: 32.5px;
                    opacity: 1;
                    border-radius: 32.5px;
                    width: 78px;
                    height: 28px;
                    .text{
                        ont-family: PingFang-SC-Regular;
                        font-size: 12px;
                        line-height: 28px;
                        color: #FFFFFF;
                        letter-spacing: 0;
                        text-align: center;
                    }
                }
            }
            .part2-2{
                display: flex;
                flex-direction: row;
                align-items: center;
                background: #F4FAFF;
                margin-top: 15px;
                border-radius: 4px;
                border-radius: 4px;
                height: 50px;
                width: 345px;
                .tipClass2{
                    margin-left: 15px;
                    background-image: linear-gradient(135deg, #038FFD 0%, #49D4F9 100%);
                    border-radius: 32.5px;
                    border-radius: 32.5px;
                    width: 78px;
                    height: 28px;
                    .text{
                        ont-family: PingFang-SC-Regular;
                        font-size: 12px;
                        line-height: 28px;
                        color: #FFFFFF;
                        letter-spacing: 0;
                        text-align: center;
                    }
                }

            }

        }
        .inputPhone{
            margin-top: 20px;
            height: 61px;
            width: 375px;
        }
        .verifyCode{
            display: flex;
            flex-direction: row;
            align-items: center;
            height: 61px;
            width: 375px;
            .getCode{
                line-height: 61px;
                margin-right:30px; 
                .text2{
                font-family: PingFangSC-Regular;
                font-size: 14px;
                color: #E80000;
                letter-spacing: 0;
                }
            }
        }
        .inputClass{
            width: 375px;
            height: 61px;
        }
        .buttonClass{
            background: rgba(232,0,0,0.16);
            width: 345px;
            height: 45px;
            border-radius: 4px;
            border-radius: 4px;
            margin-top: 30px;
            .btnText{
                font-family: PingFangSC-Medium;
                font-size: 16px;
                color: #FFFFFF;
                letter-spacing: 0.5px;
                text-align: center;
                line-height: 45px
            }
        }
    }
}
input{
   -webkit-appearance: none;
   -moz-appearance: none;
   border: none; 
}
input::-webkit-input-placeholder{
    font-family: PingFangSC-Regular;
    font-size: 16px;
    color: #919191;
    letter-spacing: 0;
}
</style>