import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    navBarFlag:true,
    donateInfo:{

    },
    donneInfo:{

    }
  },
  mutations: {
    changeFoot(state,sta){
      state.navBarFlag=sta;
    },
    setDonateInfo(state,sta){
      state.donateInfo = sta;
    },
    setDonneInfo(state,sta){
      state.donneInfo = sta
    }
  },
  actions: {
    changeNavs(ctx,sta){
      ctx.commit("changeFoot",sta)
    },
    getDonateInfo(ctx,sta){
      ctx.commit("setDonateInfo",sta)
    },
    donneInfo(ctx,sta){
      ctx.commit("setDonneInfo",sta)
    }	
  },
})
